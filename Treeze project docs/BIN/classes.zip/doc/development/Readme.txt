PNG files of the icons have to be copied from folder ./icons to the folder .../.freemind/icons; 
Line "user_icons=chris,dimitry,dan" has to be added to your .../.freemind/auto.properties file

