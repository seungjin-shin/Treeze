<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#993300" CREATED="1124560950701" ID="ID_251547339" MODIFIED="1216187545281">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body width="">
    <p align="center">
      FreeMind<br /><small>- vabade m&#245;tete kaardistamise tarkvara -</small>&#160;
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="Dialog" SIZE="18"/>
<node CREATED="1124560950701" ID="ID_228039332" LINK="http://freemind.sourceforge.net/" MODIFIED="1216250158741" POSITION="left" TEXT="FreeMind-i koduleht">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1091417446" MODIFIED="1231887626533" POSITION="left" TEXT="Kiirklahvikombinatsioonid">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_908986002" MODIFIED="1231887612241">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Failik&#228;sud:
    </p>
    <p>
      ***********
    </p>
    <p>
      Uus kaart <b>CTRL+N</b>
    </p>
    <p>
      Ava kaart <b>CTRL+O</b>
    </p>
    <p>
      Salvesta kaart <b>CTRL+S</b>
    </p>
    <p>
      Salvesta kaart kui <b>CTRL+SHIFT+S</b>
    </p>
    <p>
      Tr&#252;ki <b>CTRL+P</b>
    </p>
    <p>
      Sulge <b>CTRL+W</b>
    </p>
    <p>
      V&#228;lju <b>CTRL+Q</b>
    </p>
    <p>
      Eelmine kaart <b>ALT+SHIFT+nool vasakule</b>
    </p>
    <p>
      J&#228;rgmine kaart<b>&#160;ALT+SHIFT+nool paremale</b>
    </p>
    <p>
      Ekspordi HTML-ina <b>CTRL+E</b>
    </p>
    <p>
      Ekspordi haru HTML-ina <b>CTRL+H</b>
    </p>
    <p>
      Ekspordi haru uude .mm faili <b>ALT+SHIFT+A</b>
    </p>
    <p>
      Ava esimene fail ajaloost <b>CTRL+SHIFT+W </b>
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      Muutmise k&#228;sud:
    </p>
    <p>
      ***************
    </p>
    <p>
      Otsi <b>CTRL+F</b>
    </p>
    <p>
      Otsi j&#228;rgmine <b>CTRL+G</b>
    </p>
    <p>
      L&#245;ika <b>CTRL+X</b>
    </p>
    <p>
      Vali k&#245;ik <b>CTRL+A</b>
    </p>
    <p>
      Vali haru <b>CTRL+SHIFT+A</b>
    </p>
    <p>
      Kopeeri <b>CTRL+C</b>
    </p>
    <p>
      Kopeeri &#252;ksik <b>CTRL+Y</b>
    </p>
    <p>
      Aseta <b>CTRL+V</b>
    </p>
    <p>
      V&#245;ta tagasi <b>CTRL+Z</b>
    </p>
    <p>
      Tee uuesti <b>CTRL+Y</b>
    </p>
    <p>
      Suurenda <b>ALT+nool alla</b>
    </p>
    <p>
      V&#228;henda <b>ALT + nool &#252;les</b>
    </p>
    <p>
      
    </p>
    <p>
      S&#245;lmede vormindamise k&#228;sud:
    </p>
    <p>
      ***************************
    </p>
    <p>
      Kaldkiri<b>&#160;CTRL+I</b>
    </p>
    <p>
      Rasvane kiri <b>CTRL+B</b>
    </p>
    <p>
      Allajoonitud kiri <b>CTRL+U</b>
    </p>
    <p>
      Pilv &#252;mber s&#245;lme <b>CTRL+SHIFT+B</b>
    </p>
    <p>
      S&#245;lme v&#228;rvi muutmine <b>ALT+C</b>
    </p>
    <p>
      S&#245;lme v&#228;rvi segamine <b>ALT+B</b>
    </p>
    <p>
      S&#245;lme serva v&#228;rvi muutmine <b>ALT+E</b>
    </p>
    <p>
      Suurenda s&#245;lme kirjakuju suurust <b>CTRL+L</b>
    </p>
    <p>
      V&#228;henda s&#245;lme kirjakuju suurust <b>CTRL+M</b>
    </p>
    <p>
      Suurenda s&#245;lmede haru kirjakuju suurust <b>CTRL+SHIFT+L</b>
    </p>
    <p>
      V&#228;henda s&#245;lmede haru kirjakuju suurust <b>CTRL+SHIFT+M</b>
    </p>
    <p>
      
    </p>
    <p>
      S&#245;lmede navigeerimise k&#228;sud:
    </p>
    <p>
      ****************************
    </p>
    <p>
      Mine juurs&#245;lme juurde <b>ESCAPE</b>
    </p>
    <p>
      Liigu &#252;les <b>nooleklahv &#252;les</b>
    </p>
    <p>
      Liigu alla <b>nooleklahv alla</b>
    </p>
    <p>
      Liigu vasakule <b>nooleklahv vasakule</b>
    </p>
    <p>
      Liigu paremale <b>nooleklahv paremale</b>
    </p>
    <p>
      Ava h&#252;perlink <b>CTRL+ENTER</b>
    </p>
    <p>
      V&#228;henda<b>&#160;ALT+NOOL &#220;LES</b>
    </p>
    <p>
      Suurenda <b>ALT+NOOL ALLA</b>
    </p>
    <p>
      
    </p>
    <p>
      Uue s&#245;lme k&#228;sud:
    </p>
    <p>
      ****************
    </p>
    <p>
      Uus s&#245;lm peas&#245;lme k&#252;lge <b>ENTER</b>
    </p>
    <p>
      Uus s&#245;lm olemasoleva alla <b>INSERT</b>
    </p>
    <p>
      Uus naabers&#245;lm <b>SHIFT+ENTER</b>
    </p>
    <p>
      
    </p>
    <p>
      S&#245;lme muutmise k&#228;sud:
    </p>
    <p>
      *********************
    </p>
    <p>
      Muuda valitud s&#245;lme <b>F2</b>
    </p>
    <p>
      Muuda h&#252;pikaknas koos lisav&#245;imalustega <b>ALT+ENTER</b>
    </p>
    <p>
      &#220;henda s&#245;lmed <b>CTRL+J</b>
    </p>
    <p>
      L&#252;lita s&#245;lmede voltimist <b>T&#220;HIK</b>
    </p>
    <p>
      L&#252;lita alams&#245;lmede voltimist <b>CTRL+T&#220;HIK</b>
    </p>
    <p>
      Lisa viide lehitsemisakna kaudu <b>CTRL+SHIFT+K</b>
    </p>
    <p>
      Lisa viide k&#228;sitsi aadressi sisestades <b>CTRL+K</b>
    </p>
    <p>
      Lisa pilt lehitsemisakna kaudu&#160; <b>ALT+K</b>
    </p>
    <p>
      Liiguta s&#245;lme &#252;lespoole <b>CTRL+nooleklahv &#252;les</b>
    </p>
    <p>
      Liiguta s&#245;lme allapoole <b>CTRL+nooleklahv alla</b>
    </p>
    <p>
      Liiguta s&#245;lme vasakule <b>CTRL+nooleklahv vasakule</b>
    </p>
    <p>
      Liiguta s&#245;lme paremale <b>CTRL+nooleklahv paremale</b>
    </p>
    <p>
      Kustuta s&#245;lm <b>DELETE</b>
    </p>
  </body>
</html>
</richcontent>
<font NAME="Courier New" SIZE="12"/>
</node>
</node>
<node COLOR="#006633" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_904501221" MODIFIED="1231888280460" POSITION="left" TEXT="Paigaldamine">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" ID="_Freemind_Link_1911559485" MODIFIED="1231887087175" TEXT="Viited">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_568439776" LINK="http://java.sun.com/javase/downloads/index.jsp" MODIFIED="1216187545266" TEXT="Laadi alla Java Runtime Environment (v&#xe4;hemalt JRE1.4 v&#xf5;i uuem)">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1612101865" LINK="http://freemind.sourceforge.net/wiki/index.php/Download#Download" MODIFIED="1216187545266" TEXT="Laadi alla programm FreeMind">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_139664576" MODIFIED="1216187545266">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind-i paigaldamiseks MS Windows-is paigalda esmalt Sun-i Java Runtime Environment (JRE) ning seej&#228;rel FreeMind kasutades &quot;installer&quot; versiooni.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1380352758" MODIFIED="1231887295628">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind-i paigaldamiseks Linuxis, paigalda esmalt Sun-i Java Runtime Environment (JRE) ning siis peale lahtipakkimist k&#228;ivita FreeMind failist freemind.sh. N&#228;iteks kui pakkisid selle lahti kausta <i>/home/kasutaja/freemind/</i>&#160; siis <b>sh /home/kasutaja/freemind/freemind.sh</b>
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1808511462" MODIFIED="1216187545266">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      MS Windows-is ning Mac OS X-s v&#245;ib FreeMind-i k&#228;ivitamiseks teha ka topeltkl&#245;ps failil freemind.jar, mis asub kataloogis lib.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1231887803083" FOLDED="true" ID="ID_1057290431" MODIFIED="1231891977891" POSITION="left" TEXT="Re&#x17e;iimid">
<node COLOR="#407000" CREATED="1124560950701" ID="_Freemind_Link_353522063" MODIFIED="1231887870403" TEXT="Failide lehitsemine arvutist">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_649040499" MODIFIED="1231888473392">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Failide lehitsemiseks oma arvutist l&#252;litu &#252;mber failire&#382;iimile, valides rippmen&#252;&#252;st
    </p>
    <p>
      <b>M&#245;ttekaardid &gt; Failire&#382;iim</b>
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1036346569" MODIFIED="1216187545265" TEXT="Sa lehitsed failipuud nagu see oleks m&#xf5;ttekaart.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1489978112" MODIFIED="1231888592986" TEXT="Kataloogi m&#xe4;&#xe4;ramiseks keskele peas&#xf5;lmeks, vali s&#xf5;lme h&#xfc;pikmen&#xfc;&#xfc;st Keskele.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1505912742" MODIFIED="1216187545265" TEXT="Faili vaatamiseks, muutmiseks v&#xf5;i k&#xe4;ivitamiseks j&#xe4;rgi s&#xf5;lmes olevat viidet.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_279880616" MODIFIED="1216187545265">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Faili re&#382;iim ei ole hetkel eriti kasutusel. See on demonstratsioon, et andmete importimine puukujuliseks struktuuriks mujalt allikast kui m&#245;ttekaart, on lihtne. Ei ole &#252;htki t&#245;endit, et inimesed reaalselt ka seda re&#382;iimi kasutaksid.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" ID="_Freemind_Link_1530607683" MODIFIED="1231888620622" TEXT="M&#xf5;ttekaartide lehitsemine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_904930134" MODIFIED="1231888673026">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      M&#245;ttekaartide lehitsemiseks (mitte muutmiseks) l&#252;litu lehitsemise re&#382;iimi, valides rippmen&#252;&#252;st <b>M&#245;ttekaardid &gt; Failire&#382;iim</b>. Kuniks ei kasutata FreeMind-i appletit, on see funktsioon kasutu.
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_747061558" MODIFIED="1216187545264">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Eraldi lehitsemiste re&#382;iimide omamine on tehniline k&#252;simus. Lehitsemine on ainus asi, mida FreeMind-i appletis kodulehel teha saab. &#220;ldiselt ei kasutata lehitsemise re&#382;iimi FreeMind-is.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" ID="_Freemind_Link_1136088046" MODIFIED="1231888622816" TEXT="Erinevad re&#x17e;iimid">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_1713057526" MODIFIED="1216187545264">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kuigi FreeMind on algselt m&#245;eldud m&#245;ttekaartide redigeerimiseks, on see siiski loodud ka arvestades teisi v&#245;imalikke andmeallikaid. Spetsiifilise andmeallika k&#228;ttesaadavaks tegemisel peab programmeerija tekitama niinimetatud re&#382;iimi selle konkreetse andmeallika jaoks. Faili re&#382;iim on &#252;heks selliseks n&#228;iteks. Me ei tea, et &#252;htki teist re&#382;iimi oleks v&#228;lja arendatud. Ei ole p&#228;ris selge, kas keegi seda &#252;ldse kasutab kuid ta on siin olemas uurimiseks kui keegi seda soovib.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_700085988" MODIFIED="1216187545264">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      On veel olemas skeemide kood, mis on peaaegu valmis ja v&#245;imaldab muuta programmide skeeme. J&#228;llegi - kasutuse vajalikkus on selgusetu. Vastupidiselt m&#245;ttekaardi re&#382;iimile on teised re&#382;iimid rohkem demonstratsiooniks, mida k&#245;ike on v&#245;imalik FreeMind-i abil teha.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1525986009" MODIFIED="1231887753096" POSITION="left" TEXT="FreeMind-i appleti paigaldamine kodulehele">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#000000" CREATED="1124560950701" ID="ID_833832653" MODIFIED="1216187545263" TEXT="Sa v&#xf5;id paigaldada appleti oma veebilehele nii, et teised kasutajad saavad lehitseda Sinu m&#xf5;ttekaarte.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node COLOR="#338800" CREATED="1124560950701" ID="ID_506676757" LINK="http://sourceforge.net/project/showfiles.php?group_id=7118" MODIFIED="1216187545263" TEXT="Laadi applet alla - selle nimi on freemind-browser.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_19242684" MODIFIED="1216187545263">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Allalaaditud arhiiv sisaldab faile freemindbrowser.jar ja freemindbrowser.html. Oma kodulehel loo viide failile freemindbrowser.html ja selle faili sees muuda vastav viide selliselt, et see viitaks Sinu m&#245;ttekaardi failile.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1604975759" MODIFIED="1216187545263">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Appleti *.jar fail peab asuma samas serveris kus ka m&#245;ttekaart ise ja seda java turvalisuse p&#228;rast. Sa pead laadima nii FreeMind-i appleti *.jar faili kui ka oma m&#245;ttekaardi oma kodulehele.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1083756111" MODIFIED="1231887769268" POSITION="left" TEXT="FreeMind appleti kasutamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_514864900" MODIFIED="1216187545262">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind-i appletis saad Sa kasutada vaid lehitsemise re&#382;iimi; Sa ei saa muuta serveris asuvaid m&#245;ttekaarte. Kl&#245;psa s&#245;lmel, et l&#252;litada &#252;mber voltimisre&#382;iimi v&#245;i j&#228;rgneda veebiviitele. Haara ja lohista tausta, et liigutada m&#245;ttekaarti. Otsimiseks kasuta m&#245;ttekaardi kiirmen&#252;&#252;d.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1976458022" MODIFIED="1216201160405" POSITION="left" TEXT="Kasutajaliidese muudatused alates versioonist 0.6.5">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_717349033" MODIFIED="1216187545262">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      M&#245;ned klaviatuuriseaded on uuesti m&#228;&#228;ratud, et oleks kasutusel ka mujal programmides levinud intuitiivsed klahvikombinatsioonid. M&#245;ned uued kiirklahvid p&#228;rinevad Microsofti toodetest. Uued kiirklahvid sisaldavad ka n&#228;iteks ENTER-i abil uue m&#245;tte lisamine peas&#245;lmele, INSERT-klahvi abil m&#245;tte lisamine olemasoleva m&#245;tte alla, F2 s&#245;lme sisu muutmiseks - siin ongi Microsofti m&#245;ju kuna tegelikult ei ole mingit p&#245;hjust omada F2 kiirklahvi s&#245;lme sisu muutmiseks. Kuid kui oled neid kiirklahve teistes programmides kasutanud, soovid neid ka FreeMind-i.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1179893656" MODIFIED="1216187545262" TEXT="Klaviatuuri seadeid saab muuta rippmen&#xfc;&#xfc;st T&#xf6;&#xf6;riistad &gt; Eelistused.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_784043927" MODIFIED="1231892658922" POSITION="left" TEXT="T&#xe4;nud">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" ID="Freemind_Link_415458128" MODIFIED="1231892420616" TEXT="Autorid">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1896457660" MODIFIED="1231892007981" TEXT="Joerg Mueller">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" ID="ID_1354886892" LINK="mailto:ponders@t-online.de" MODIFIED="1216187545261" TEXT="ponders@t-online.de">
<font NAME="Dialog" SIZE="10"/>
</node>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1757468410" MODIFIED="1216187545261" TEXT="Freiburgi &#xdc;likool, Saksamaa">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_984984595" LINK="http://danpolansky.blogspot.com/" MODIFIED="1216272339951" TEXT="Daniel Polansky">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_459203293" MODIFIED="1216187545261" TEXT="Petr Novak">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_875814410" MODIFIED="1231892011782" TEXT="Christian Foltin">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" ID="ID_326360391" LINK="mailto:christian.foltin@gmx.de" MODIFIED="1216187545261" TEXT="christian.foltin@gmx.de">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1415293905" MODIFIED="1216187545261" TEXT="Dimitri Polivaev">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1225908784937" ID="ID_1518099786" MODIFIED="1225908813653" STYLE="fork" TEXT="Eric Lavarde">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<node COLOR="#558000" CREATED="1225908790680" ID="ID_300895949" MODIFIED="1231892088078" STYLE="fork" TEXT="Linuxi versiooni pakendamine">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_816166020" MODIFIED="1231892397710" TEXT="V&#xe4;iksemad panustajad">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950701" ID="ID_1613097663" MODIFIED="1216272349630" TEXT="Andrew Iggleden">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1149301468" MODIFIED="1216187545261" TEXT="Windows-i paigaldaja">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1096673251" MODIFIED="1216272351336" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_617977736" MODIFIED="1216187545261" TEXT="Eclipse &#xf5;petus">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1024053399" MODIFIED="1216272352345" TEXT="David Butt">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_49661074" MODIFIED="1216187545261" TEXT="Flash-i &#xf5;petus">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="ID_1167712813" MODIFIED="1216272353298" TEXT="David Low">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_356164606" MODIFIED="1216187545261" TEXT="Abitekstid">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_360501151" LINK="http://freemind.sourceforge.net/wiki/index.php/Translation" MODIFIED="1231892656995" TEXT="T&#xf5;lkijad">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124561374999" ID="ID_180090574" MODIFIED="1216272357942" TEXT="Edmund Laugasson">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124561377702" ID="ID_537083851" MODIFIED="1216187545260" TEXT="Eesti keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_807977431" MODIFIED="1216272359692" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1392047072" MODIFIED="1216187545260" TEXT="Itaalia keele t&#xf5;lge">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1853214917" MODIFIED="1216272361218" TEXT="Knud Riish&#xf8;jg&#xe5;rd">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_572926838" MODIFIED="1216187545260" TEXT="Taani keele t&#xf5;lge">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_1676529317" MODIFIED="1216272362282" TEXT="Takeshi Kakeda">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_763739856" MODIFIED="1216187545260" TEXT="Jaapani keele t&#xf5;lge">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562983644" ID="Freemind_Link_1172193026" MODIFIED="1216272363189" TEXT="Kohichi Aoki">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_919845662" MODIFIED="1216187545260" TEXT="Jaapani keele t&#xf5;lge">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="ID_1810700717" MODIFIED="1216272364055" TEXT="Alex Dukal">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1990388249" MODIFIED="1216187545260" TEXT="Hispaania keele t&#xf5;lge">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562998159" ID="Freemind_Link_757563697" MODIFIED="1216272364816" TEXT="Hugo Gayosso">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1783275246" MODIFIED="1216187545260" TEXT="Hispaania keele t&#xf5;lge">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="Freemind_Link_929540960" MODIFIED="1216272365516" TEXT="Sylvain Gamel">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_665552197" MODIFIED="1216187545260" TEXT="Prantsuse keele t&#xf5;lge">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561242082" ID="Freemind_Link_946171164" MODIFIED="1216272366270" TEXT="Koen Roggemans">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124561245957" ID="Freemind_Link_1819881845" MODIFIED="1216187545260" TEXT="Hollandi keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561242082" ID="ID_682397068" LINK="http://fromtw.blogspot.com/" MODIFIED="1231892299891" TEXT="William Chen">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124561245957" ID="ID_1903817938" MODIFIED="1231892279699" TEXT="Hiina keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561374999" ID="Freemind_Link_235962981" MODIFIED="1216272366953" TEXT="Rafal Kraik">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124561377702" ID="Freemind_Link_459079511" MODIFIED="1216187545260" TEXT="Poola keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561969717" ID="Freemind_Link_653284985" MODIFIED="1216272367703" TEXT="Goliath">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124561438294" ID="Freemind_Link_1387213811" MODIFIED="1216187545259" TEXT="Korea keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561753254" ID="Freemind_Link_35211963" MODIFIED="1216272369174" TEXT="Martin Srebotnjak (h&#xfc;&#xfc;dnimi: Miles a.k.a. filmsi)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124561491886" ID="Freemind_Link_835144271" MODIFIED="1216187545258" TEXT="Sloveenia keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561374999" ID="ID_726223734" MODIFIED="1231892372937" TEXT="Matti Lassila">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124561377702" ID="ID_195296251" MODIFIED="1231892357948" TEXT="Soome keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561374999" ID="ID_198480280" MODIFIED="1231892438643" TEXT="Christian Foltin">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124561377702" ID="ID_1189589576" MODIFIED="1231892415159" TEXT="Saksa keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561814721" ID="Freemind_Link_1008886206" MODIFIED="1216272380101" TEXT="William Chen">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124561497308" ID="Freemind_Link_1960552629" MODIFIED="1216187545258" TEXT="Hiina keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561823877" ID="Freemind_Link_1650138043" MODIFIED="1216272379451" TEXT="Radek &#x160;varc">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124561515761" ID="Freemind_Link_768227373" MODIFIED="1216187545257" TEXT="T&#x161;ehhi keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562250475" ID="Freemind_Link_901975324" LINK="http://documan.sourceforge.net/" MODIFIED="1231892557284" TEXT="Bal&#xe1;zs M&#xe1;rton (documan)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124562252585" ID="Freemind_Link_557911120" MODIFIED="1216187545257" TEXT="Ungari keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562948942" ID="Freemind_Link_290351026" MODIFIED="1216272381633" TEXT="Luis Ferreira ">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124562956332" ID="Freemind_Link_6081004" MODIFIED="1216187545257" TEXT="Portugali keele t&#xf5;lge">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124563066204" ID="Freemind_Link_23652566" MODIFIED="1216187545257">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      T&#245;lkijate nimekiri ei pruugi olla l&#245;plik. Kui me oleme Sind unustanud - palun anna sellest meile teada! K&#245;ik inimesed, kes on isegi poolikuid t&#245;lkeid edastanud, on siin nimekirjas toodud.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="ID_296319773" MODIFIED="1216187545251" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Otsimiseks vajuta CTRL + F. J&#228;rgmise otsimiseks vajuta CTRL + G. Et muuta otsing globaalseks, vajuta ESC enne otsimise alustamist.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="ID_1243305843" MODIFIED="1216187545242" POSITION="right" TEXT="Vajuta parempoolset nooleklahvi, et avada (lahti voltida) tekstikast.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1596161299" MODIFIED="1216201160406" POSITION="right" TEXT="Tutvustus">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1477669657" MODIFIED="1216187545242">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind v&#245;imaldab luua niinimetatud m&#245;ttekaarte. Samas kasutavad paljud inimesed seda kui m&#228;rkmikku v&#245;i lihtsalt isikliku info haldamiseks.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1859704500" MODIFIED="1216187545242">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Infot hoitakse tekstikastides, mida nimetatakse s&#245;lmedeks. S&#245;lmed on omavahel &#252;henduses, kasutades jooni.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_163671273" MODIFIED="1216187545242">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      See on FreeMind 0.9.0 dokumentatsioon. Kiirklahvid ja funktsioonide asukohad men&#252;&#252;des v&#245;ivad tulevikus muutuda.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_706084071" MODIFIED="1216201160408" POSITION="right" TEXT="M&#xf5;nede v&#xf5;imaluste demonstratsioon">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_735193624" MODIFIED="1216200835993" TEXT="V&#xe4;limus">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="ID_887863172" MODIFIED="1216187545241" TEXT="S&#xf5;lmed v&#xf5;ivad olla erinevat v&#xe4;rvi.">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1124560950701" ID="ID_1474945370" MODIFIED="1216187545241" TEXT="Punane">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#009900" CREATED="1124560950701" ID="ID_1005177880" MODIFIED="1216187545241" TEXT="Roheline">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0000cc" CREATED="1124560950701" ID="ID_304992602" MODIFIED="1216187545241" TEXT="Sinine">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_" MODIFIED="1216187545241" TEXT="S&#xf5;lmedel v&#xf5;ivad olla erinevad taustav&#xe4;rvid">
<font NAME="SansSerif" SIZE="12"/>
<node BACKGROUND_COLOR="#77a86f" CREATED="1124560950701" ID="_Freemind_Link_1358611533" MODIFIED="1216187545241" TEXT="N&#xe4;iteks selline"/>
<node BACKGROUND_COLOR="#d3d9f4" CREATED="1124560950701" ID="_Freemind_Link_1317973766" MODIFIED="1216187545241" TEXT="Ja veel ka selline"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_754589044" MODIFIED="1216187545241" TEXT="S&#xf5;lmedel v&#xf5;ivad olla erinevad fontide stiilid">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1966890106" MODIFIED="1216187545241" TEXT="Rasvane kiri">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1134315926" MODIFIED="1216187545241" TEXT="Kaldkiri">
<font ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1038960675" MODIFIED="1216187545241" TEXT="Rasvane ja kaldkiri">
<font BOLD="true" ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_357603252" MODIFIED="1216187545241" TEXT="S&#xf5;lmede fondid v&#xf5;ivad olla erinevate suurustega">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1612985143" MODIFIED="1216187545241" TEXT="V&#xe4;ike">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node CREATED="1124560950701" ID="ID_99178057" MODIFIED="1216187545241" TEXT="Normaalne">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node CREATED="1124560950701" ID="ID_421241675" MODIFIED="1216187545241" TEXT="Suurem">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_590940671" MODIFIED="1216187545240" TEXT="Suur">
<font NAME="SansSerif" SIZE="20"/>
<node CREATED="1124560950701" ID="ID_223617365" MODIFIED="1216187545240" TEXT="OOh">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_1960916074" MODIFIED="1216187545240" TEXT="Erinevaid fonte saab kasutada">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1360641359" MODIFIED="1216187545240" TEXT="Selline">
<font NAME="Times New Roman" SIZE="16"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1568731425" MODIFIED="1216187545240" TEXT="V&#xf5;i see">
<font NAME="Verdana" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_539001457" MODIFIED="1216187545240" TEXT="V&#xf5;i hoopis see">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1193071041" MODIFIED="1216187545240" TEXT="Erinevaid s&#xf5;lmede stiile saab kasutada">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1979277285" MODIFIED="1216187545240" TEXT="Kahvel">
<node CREATED="1124560950701" ID="_Freemind_Link_89124429" MODIFIED="1216187545240" TEXT="Kahvel"/>
<node CREATED="1124560950701" ID="_Freemind_Link_173850525" MODIFIED="1216187545240" TEXT="Kahvel"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1001811541" MODIFIED="1216187545240" STYLE="bubble" TEXT="Mullitatud">
<node CREATED="1124560950701" ID="_Freemind_Link_1677737286" MODIFIED="1216187545240" STYLE="bubble" TEXT="Mullitatud"/>
<node CREATED="1124560950701" ID="_Freemind_Link_978246353" MODIFIED="1216187545240" STYLE="bubble" TEXT="Mullitatud"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="ID_738265772" MODIFIED="1216200835993" TEXT="S&#xf5;lmi saab kokku/lahti voltida">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_307016912" MODIFIED="1216187545240" TEXT="S&#xf5;lm">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_295225504" MODIFIED="1216187545240" TEXT="Peidetud">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1488567837" MODIFIED="1216187545240" TEXT="Puu">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_734334377" MODIFIED="1216187545240" TEXT="Tamm">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1388126257" MODIFIED="1216187545240" TEXT="P&#xf6;&#xf6;k">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_292365900" MODIFIED="1216187545240" TEXT="Jalakas">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="ID_1596510922" MODIFIED="1216200835994" TEXT="S&#xf5;lmed v&#xf5;ivad sisaldada j&#xe4;rgitavaid viiteid ... ">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_1913017247" MODIFIED="1216187545239" TEXT="Veebilehtedele">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_350611440" LINK="http://www.google.ee/" MODIFIED="1216187545239" TEXT="http://www.google.ee/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_646857774" LINK="www.google.ee" MODIFIED="1216187545239" TEXT="www.google.ee">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1117649418" MODIFIED="1216187545239" TEXT="Freemind arvab, et see on k&#xe4;ivitatav fail :)">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_715165450" MODIFIED="1216187545239" TEXT="Kohalikele kaustadele">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_469314055" LINK="C:/Program%20Files/" MODIFIED="1216187545239" TEXT="C:/Program Files/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_534319083" LINK="/home/" MODIFIED="1216187545239" TEXT="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_1939211284" MODIFIED="1216187545239" TEXT="K&#xe4;ivitatavatele failidele">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="ID_1645120569" LINK="%SystemRoot%\regedit.exe" MODIFIED="1216187545239" TEXT="%SystemRoot%\regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006600" CREATED="1124560950701" ID="ID_1388267403" MODIFIED="1216187545239" TEXT="Siit on n&#xe4;ha, et s&#xf5;lmel on k&#xe4;ivitatava faili ikoon ees.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_1573618660" MODIFIED="1216187545239" TEXT="Suvaline dokument Sinu arvutis v&#xf5;i Sinu ettev&#xf5;tte v&#xf5;rgus">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_839677176" MODIFIED="1216200835994" TEXT="Mitmerealised s&#xf5;lmed">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1423568963" MODIFIED="1216187545239">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Sa v&#245;id n&#228;ha mitmerealisi s&#245;lmi eraldi tekstil&#245;iguna v&#245;i mitme tekstil&#245;iguna. Kui oled ehitamas teadmista baasi FreeMind-i abil, siis ilmselt ei saa l&#245;ikude kasutamist v&#228;ltida. Selle asemel, et omada lihtsalt tavalist tekstifaili m&#228;rkmetega, v&#245;id Sa hoopis omada s&#245;lmedest koosnevat jada, mis on omavahel &#252;hendatud ja saab j&#228;rk-j&#228;rgult lahti harutada.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1686184172" MODIFIED="1216187545239">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &quot;Teadus on fakt; just nagu majad tehakse kividest, nii ka teadus koosneb faktidest; kuid kivihunnik ei ole veel maja ja faktikogum ei pruugi veel teadus olla.&quot; --Henri Poincar&#233;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="ID_1384103247" MODIFIED="1216200835994" TEXT="L&#xfc;hikeserealised s&#xf5;lmed koos uute ridadega">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1957797574" MODIFIED="1216187545239">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Rida,
    </p>
    <p>
      ja teinegi,
    </p>
    <p>
      
    </p>
    <p>
      ja veel &#252;ks rida,
    </p>
    <p>
      mida arvad sellest?
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="ID_1747782018" MODIFIED="1216200835994" TEXT="Sa v&#xf5;id emuleerida sildistatud jooni">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1812254377" MODIFIED="1216187545239" TEXT="Puu">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="ID_1357589453" MODIFIED="1216200828922" TEXT="on">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_1843885197" MODIFIED="1216187545239" TEXT="Tamm">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="ID_1175801663" MODIFIED="1216200828922" TEXT="on">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_956172504" MODIFIED="1216187545239" TEXT="P&#xf6;&#xf6;k">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="ID_647529529" MODIFIED="1216200828922" TEXT="on">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_1045593899" MODIFIED="1216187545239" TEXT="Jalakas">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1721974835" MODIFIED="1216187545238" TEXT="Puu">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="ID_300230898" MODIFIED="1216187545238" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_1149978961" MODIFIED="1216187545238" TEXT="Leht">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="ID_329904317" MODIFIED="1216187545238" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_1518758203" MODIFIED="1216187545238" TEXT="T&#xfc;vi">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="ID_46511860" MODIFIED="1216187545238" TEXT="Sa v&#xf5;id ikoone lisada s&#xf5;lmedesse">
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_318937820" MODIFIED="1216200835996" TEXT="Sa v&#xf5;id teha pilvi">
<cloud/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1236643816" MODIFIED="1216187545238" TEXT="Endavalitud v&#xe4;rvidega">
<cloud COLOR="#f1ede6"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1750585847" MODIFIED="1216200835996" TEXT="Sa v&#xf5;id teha graafilisi viiteid">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1212380407" MODIFIED="1216187545238" TEXT="&#xdc;hendada s&#xf5;lme">
<arrowlink DESTINATION="_Freemind_Link_1249400461" ENDARROW="Default" ENDINCLINATION="41;0;" ID="Arrow_ID_790768865" STARTARROW="None" STARTINCLINATION="41;0;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1249400461" MODIFIED="1216187545238" TEXT="Teisega">
<arrowlink COLOR="#6600ff" DESTINATION="_Freemind_Link_880551392" ENDARROW="Default" ENDINCLINATION="47;0;" ID="Freemind_Arrow_Link_85185909" STARTARROW="None" STARTINCLINATION="47;0;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_880551392" MODIFIED="1216187545238" TEXT="Erinevates v&#xe4;rvides">
<arrowlink DESTINATION="_Freemind_Link_1789233193" ENDARROW="Default" ENDINCLINATION="82;44;" ID="Freemind_Arrow_Link_1672464612" STARTARROW="None" STARTINCLINATION="82;44;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1789233193" MODIFIED="1216187545238" TEXT="Ja erineva kujuga">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_127668276" MODIFIED="1216200835996" TEXT="S&#xf5;lmi saab vabalt &#xfc;mber paigutada">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_894936766" MODIFIED="1216187545238" TEXT="&#xdc;ks">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1942481455" MODIFIED="1216187545237" TEXT="Teine">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1709752669" MODIFIED="1216201160409" POSITION="right" TEXT="S&#xf5;lmede loomine ja kustutamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1080456719" MODIFIED="1216187545237" TEXT="Alams&#xf5;lme tekitamiseks aktiivse s&#xf5;lme alla vajuta INSERT.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_745599378" MODIFIED="1216187545237">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Et luua uut alams&#245;lme samal ajal kui muudetakse teist s&#245;lme, vajuta muutmise ajal INSERT.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1624846736" MODIFIED="1216187545236">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      1. taseme alams&#245;lme loomiseks peas&#245;lme alla vajuta ENTER.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_987299998" MODIFIED="1216187545234">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      1. taseme alams&#245;lme loomiseks peas&#245;lme alla aktiivse s&#245;lme kohale, vajuta SHIFT + ENTER.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_461300770" MODIFIED="1216187545234" TEXT="S&#xf5;lme kustutamiseks vajuta DELETE">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1332647159" MODIFIED="1216187545234">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Aktiivse s&#245;lme l&#245;ikamiseks vajuta CTRL + X
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_308911082" MODIFIED="1216187545234">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      K&#245;iki tegevusi saab teha ka hiire paremklahvi alt avanevat men&#252;&#252;d kasutades.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1700974092" MODIFIED="1216201160410" POSITION="right" TEXT="S&#xf5;lme teksti muutmine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_519923426" MODIFIED="1216187545234">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme muutmiseks vajuta F2, HOME v&#245;i END klahvi, v&#245;i s&#245;lme kiirmen&#252;&#252;s vali Redigeeri s&#245;lme. S&#245;lme redigeerimise l&#245;petamiseks, vajuta ENTER nupule.
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="_Freemind_Link_519923426" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_1179992477" STARTARROW="None" STARTINCLINATION="0;0;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_522935321" MODIFIED="1216187545233">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lmes oleva teksti asendamiseks uuega lihtsalt alusta tippimist.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_645044942" MODIFIED="1216187545233">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Et sundida l&#252;hikese sisuga s&#245;lme muutmist avanema eraldi h&#252;pikaknas, vajuta ALT + ENTER.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_683234865" MODIFIED="1216187545233">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pika sisuga s&#245;lme poolitamiseks kasuta nuppu Poolita s&#245;lme redaktori akna allosas v&#245;i vajuta ALT + S.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1426930299" MODIFIED="1216187545233">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Uue rea lisamiseks s&#245;lme redigeerimise aknas, vajuta CTRL + ENTER. Kui s&#245;lme redigeeritakse kohapeal ilma redaktori aknata siis uue rea lisamine ei ole v&#245;imalik.
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="_Freemind_Link_1445647544" ENDARROW="Default" ENDINCLINATION="118;0;" ID="Freemind_Arrow_Link_1628309717" STARTARROW="None" STARTINCLINATION="118;0;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_496995972" MODIFIED="1216187545233">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Et kopeerida valikut l&#245;ikepuhvrisse samal ajal kui toimub s&#245;lme teksti muutmine eraldi aknas, vajuta hiire paremklahvi ning vali sealt Kopeeri.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_372247337" MODIFIED="1216187545233">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Et lisada eris&#252;mboleid nagu n&#228;iteks &#169;, lisa see k&#245;igepealt oma lemmiktekstiredaktoris nagu n&#228;iteks OpenOffice.org Writer v&#245;i MS Word, ja siis kopeeri see FreeMind-i.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1445647544" MODIFIED="1216187545233">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Vaikimisi ENTER l&#245;petab s&#245;lme redigeerimise ja CTRL+ENTER lisab uue rea. M&#228;rkeruudu &quot;Enter kinnitab&quot; m&#228;rkimise eemaldamisega saad Sa muuta eeltoodud klahvikombinatsioonide m&#245;ju vastupidiseks, n&#228;iteks ENTER lisab uue rea ja CTRL+ENTER l&#245;petab redigeerimise. Sa v&#245;id muuta vaikimisi v&#228;&#228;rtust sellel m&#228;rkeruudul eelistustest. Veelgi enam - selle m&#228;rkeruudu v&#228;&#228;rtus salvestatakse ja hakkab kehtima ka siis kui FreeMind-i vahepeal ei sulge.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1377326758" MODIFIED="1216187545233">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind toetab t&#228;ielikult unicode-i. Seet&#245;ttu v&#245;id kasutada skripte oma suva j&#228;rgi.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1660149394" MODIFIED="1216201160410" POSITION="right" TEXT="S&#xf5;lme kujundamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1886238915" MODIFIED="1216187545232" TEXT="S&#xf5;lme teksti rasvaseks muutmiseks vajuta CTRL + B.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_999781422" MODIFIED="1216187545232" TEXT="S&#xf5;lme teksti kaldu muutmiseks vajuta CTRL + I.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_939014888" MODIFIED="1216187545232" TEXT="S&#xf5;lme teksti v&#xe4;rvi muutmiseks vajuta Alt + C.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1116928608" MODIFIED="1216187545232">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme taustav&#228;rvi muutmiseks vali s&#245;lme kiirmen&#252;&#252;st Vormindus -&gt; S&#245;lme taustav&#228;rv
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1517052690" MODIFIED="1216187545232">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme kirja suuruse suurendamiseks vajuta CTRL + <font size="4">+ </font><font size="3">(mitte see + numbriklahvide juurest)</font>.
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1300105414" MODIFIED="1216187545232">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme kirja v&#228;hendamiseks vajuta CTRL + <font size="4">-</font> (mitte see - numbriklahvide juurest).
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1712083026" MODIFIED="1216187545232">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kirjakuju muutmiseks vali vastav v&#228;li peamisel t&#246;&#246;riistaribal.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_488438696" MODIFIED="1216187545232">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme vorminduse kopeerimiseks vajuta Alt + C
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1757575811" MODIFIED="1216187545232" TEXT="Kujunduse asetamiseks To paste formats onto a node, press Alt + V.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_526328879" MODIFIED="1216201160411" POSITION="right" TEXT="F&#xfc;&#xfc;siliste stiilide kasutamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_529939824" MODIFIED="1216187545231">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      F&#252;&#252;silise stiili lisamiseks vali s&#245;lme kiirmen&#252;&#252;st F&#252;&#252;siline stiil -&gt;Stiil Sinu valikul. F&#252;&#252;siliste stiilide lisamise kiirendamiseks kasuta klaviatuuri kiirklahve nagu on sealsamas kiirmen&#252;&#252;s hiire parema klahvi all n&#228;idatud.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_472935372" MODIFIED="1216187545231">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Oma f&#252;&#252;silise stiili lisamine eeldab, et oled tehnilise p&#228;devusega kasutaja. Muuda neid faile &quot;patterns.xml&quot; failis, mis asub kataloogis &quot;.freemind&quot; Sinu kodukataloogis.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1514218661" MODIFIED="1216187545231">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      [See tekst on aegunud.] M&#228;rkused failist patterns.xml j&#228;rgnevad. F&#252;&#252;siline stiil kehtestub s&#245;lmedele kui seal on &lt;edge&gt; m&#228;rgend. &lt;node&gt; m&#228;rgend v&#245;ib omada alamm&#228;rgeneid. Uuri faili &quot;patterns.xml&quot;, mis on FreeMind-iga kaasa pandud.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1697687428" MODIFIED="1216201160411" POSITION="right" TEXT="S&#xf5;lmede esilet&#xf5;stmine pilvedega">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1187980137" MODIFIED="1216187545231">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pilvi kasutatakse mingi ala esilet&#245;stmiseks. Esile t&#245;stetakse nii s&#245;lm kui ka k&#245;ik selle all olevad s&#245;lmed.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1656028711" MODIFIED="1216187545231">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pilve lisamiseks vajuta CTRL + SHIFT + B v&#245;i vali s&#245;lme kiirmen&#252;&#252;st Lisamine -&gt; Pilv.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1229313572" MODIFIED="1216187545230">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme v&#228;rvi muutmiseks vali s&#245;lme kiirmen&#252;&#252;st Vormindus -&gt; Pilve v&#228;rv.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1967714751" MODIFIED="1216200835997">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pilvedel v&#245;ib olla erinevaid taustav&#228;rve, nt roheline ...
    </p>
  </body>
</html></richcontent>
<cloud COLOR="#e1f2e1"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_480742681" MODIFIED="1216187545230" TEXT="... v&#xf5;i pruun.">
<cloud COLOR="#ede5d5"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_203858515" MODIFIED="1216201160412" POSITION="right" TEXT="H&#xfc;perviidete lisamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1905021887" MODIFIED="1216187545230">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      H&#252;perviite lisamiseks s&#245;lmele vajuta CTRL + K v&#245;i vali s&#245;lme kiirmen&#252;&#252;st Lisamine -&gt; H&#252;perviide.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1725364546" MODIFIED="1216187545230">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      H&#252;perviite eemaldamiseks kustuta h&#252;perviide p&#228;rast CTRL + K vajutamist avanevast h&#252;pikaknast.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1115329778" MODIFIED="1216187545230">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Viite tegemiseks e-postiaadressile m&#228;&#228;ra h&#252;perviite tekstiks n&#228;iteks <i>mailto:eesnimi.perenimi@mail</i>.ee
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1492211565" MODIFIED="1216187545230">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Koos kirjateemaga e-postiaadressile viite tegemiseks m&#228;&#228;ra h&#252;perviite sisuks <i>mailto:eesnimi.perenimi@mail</i>.<i>ee?subject=Viimane telefonik&#245;ne</i>
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_75591401" MODIFIED="1216187545229">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      H&#252;perviiteid saab panna viitama veebilehtedele, kohalikele failidele v&#245;i e-postiaadressidele.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1044397139" MODIFIED="1216201160413" POSITION="right" TEXT="Ikoonide lisamine">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_530415806" MODIFIED="1216187545227" TEXT=" S&#xf5;lmes v&#xf5;ib olla mitu ikooni. ">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_552368878" MODIFIED="1216187545227">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ikooni lisamiseks s&#245;lme, vali s&#245;lm ja kl&#245;psa &#252;hel ikoonidest vasakul t&#246;&#246;riistaribal. Hiirekursori liigutamisel vasakul asuvale t&#246;&#246;riistaribale, hoia all ALT- v&#245;i CTRL-klahvi, et Sa ei kaotaks fookust.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1584241525" MODIFIED="1216187545227">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#220;he ikooni eemaldamiseks vajuta punast risti vasakpoolse t&#246;&#246;riistariba &#252;laosas.&#160;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_741996931" MODIFIED="1216187545226">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      K&#245;ikide ikoonide korraga eemaldamiseks vajuta pr&#252;gikasti kujutavat ikooni vasakpoolse t&#246;&#246;riistariba &#252;laosas.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1106300423" MODIFIED="1216187545226">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Uue ikooni s&#245;lme lisamiseks klaviatuuri abil vajuta ALT + I.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_5062099" MODIFIED="1216187545226">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Oma ikoonide kasutamise v&#245;imalus puudub; Sa saad valida ikoone &#252;ksnes FreeMind-iga kaasatulevate ikoonide hulgast.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_492956634" MODIFIED="1216187545226">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ikoonide t&#246;&#246;riistariba peitmiseks v&#245;i n&#228;itamiseks vasakul t&#246;&#246;riistaribal, vali taustal hiire kiirmen&#252;&#252;st L&#252;lita vasakut t&#246;&#246;riistariba. Ikoonide t&#246;&#246;riistariba kutsutakse seal: Teine t&#246;&#246;riistariba.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_228388619" MODIFIED="1216187545226">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kui ikoonid on lisatud nagu siin s&#245;lmel siis need pannakse kaasa ja enamgi veel.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1996597932" MODIFIED="1216201160413" POSITION="right" TEXT="Graafiliste viidete lisamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_706501552" MODIFIED="1216187545225">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Graafiliste viidete tegemiseks kahe s&#245;lme vahel haara &#252;hest s&#245;lmest ja kukuta see teisele s&#245;lmele, samal ajal SHIFT + CTRL klahve korraga all hoides. Vabasta hiireklahv ennem klaviatuuri klahve.
    </p>
  </body>
</html></richcontent>
<arrowlink COLOR="#b0b0b0" DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="289;0;" ID="Freemind_Arrow_Link_1428344028" STARTARROW="None" STARTINCLINATION="250;-7;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1666507871" MODIFIED="1216187545225">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Teine v&#245;imalus - m&#228;rgi CTRL-klahvi all hoides kaks s&#245;lme ja vajuta CTRL + L
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_208378337" MODIFIED="1216187545225">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Graafilise viite v&#228;rvi muutmiseks kasuta hiire kiirmen&#252;&#252;d, mis avaneb hiire paremklahvi alt kui sellel graafilisel viitel kl&#245;psata.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1484370636" MODIFIED="1216187545225">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Joone nooleotse muutmiseks kasuta taas kiirmen&#252;&#252;d (hiire paremklahviga kl&#245;ps graafilisel viitel).
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1015136152" MODIFIED="1216187545225">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Graafilise viite kustutamiseks kasuta graafilise viite kiirmen&#252;&#252;d (hiire paremklahvi alt vali: Kustuta graafiline viide).
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_266716332" MODIFIED="1216187545225">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Et kiiresti liikuda (fokusseerida vaade) graafilise viite algus- v&#245;i l&#245;pp-punkti, kasuta selle viite kiirmen&#252;&#252;d.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1015289745" MODIFIED="1216187545225">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Graafilise viite liigutamiseks ja asendi muutmiseks, haara hiire vasaku klahviga sellest kinni ja muuda noole asendit.
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="256;22;" ID="Freemind_Arrow_Link_1273596772" STARTARROW="None" STARTINCLINATION="244;32;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_315327090" MODIFIED="1216187545225" TEXT="Allj&#xe4;rgnevalt graafiliste viidete n&#xe4;ited.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_444873207" MODIFIED="1216200835997" TEXT="N&#xe4;idis">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1170112929" MODIFIED="1216187545225" TEXT="Viide teisele osale">
<arrowlink COLOR="#9999ff" DESTINATION="_Freemind_Link_1492563156" ENDARROW="Default" ENDINCLINATION="154;-5;" ID="Freemind_Arrow_Link_33407992" STARTARROW="Default" STARTINCLINATION="154;-6;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_210427206" MODIFIED="1216187545225">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lm koos kokkuvolditud alams&#245;lmega
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1492563156" MODIFIED="1216187545224" TEXT="Alams&#xf5;lm"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1370577235" MODIFIED="1216187545224" TEXT="Teine viide">
<arrowlink COLOR="#b0b0b0" DESTINATION="_Freemind_Link_1170112929" ENDARROW="Default" ENDINCLINATION="126;16;" ID="Freemind_Arrow_Link_1872050149" STARTARROW="None" STARTINCLINATION="28;1;"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_423038022" MODIFIED="1216201160414" POSITION="right" TEXT="Otsimine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_729626319" MODIFIED="1216187545224">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Teksti otsimiseks s&#245;lmest ja selle all olevatest s&#245;lmedest, vajuta CTRL + F v&#245;i rippmen&#252;&#252;st vali Redigeerimine -&gt; Otsi.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1108790262" MODIFIED="1216187545224">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      J&#228;rgmise vastavuse otsimiseks sama otsingus&#245;naga, vajuta CTRL + G v&#245;i rippmen&#252;&#252;st vali Redigeerimine -&gt; Otsi j&#228;rgmine.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1842831668" MODIFIED="1216187545223">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kogu kaardi ulatuses globaalse otsingu sooritamiseks tuleb eelnevalt ESC-klahvi abil peas&#245;lm aktiveerida ehk siis kaart algasendisse viia..
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1918000612" MODIFIED="1216187545223">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Otsingu laius s&#245;ltub sisestatud otsingus&#245;nast(-dest). See vastab ideele, et mida s&#252;gavam on s&#245;lm, seda parem on detail, mis on s&#245;lmes kirjeldatud.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1054705788" MODIFIED="1216187545223">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pea meeles, et mitte kogu kaarti ei otsita l&#228;bi vaid ainult konkreetne s&#245;lm ja selle all olevad s&#245;lmed.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_653540280" MODIFIED="1216201160415" POSITION="right" TEXT="Mitme s&#xf5;lme valimine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1989692981" MODIFIED="1216187545217">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Mitme s&#245;lme korraga valimiseks hoia hiire vasaku klahviga kl&#245;psamise ajal all kas CTRL- v&#245;i SHIFT-klahvi.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_139767984" MODIFIED="1216187545197">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Juba valitud s&#245;lmele alams&#245;lme lisamiseks, hoia hiire vasaku klahviga kl&#245;psamise ajal all CTRL-klahvi.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_108535754" MODIFIED="1216187545173">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      J&#228;rjestikku mitme s&#245;lme valimiseks hoia hiire vasaku klahviga kl&#245;psimise ajal v&#245;i siis nooleklahvide abil liikudes all SHIFT klahvi.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1610175580" MODIFIED="1216187545146">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kogu s&#245;lmepuu valimiseks vajuta CTRL + SHIFT + A v&#245;i hoia all SHIFT-klahvi kui nooleklahviga s&#245;lmepuus allapoole liigud.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1616941396" MODIFIED="1216187545118">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Mitme s&#245;lme m&#228;rkimise eemaldamiseks kl&#245;psa kaardi taustal v&#245;i valimata s&#245;lmel.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_227748526" MODIFIED="1216187545096">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      K&#245;ikide n&#228;htavate (ehk siis kogu kaardil olevate) s&#245;lmede m&#228;rkimiseks vali CTRL + A v&#245;i rippmen&#252;&#252;st Redigeerimine -&gt; Vali k&#245;ik n&#228;htav.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1024903226" MODIFIED="1216201160415" POSITION="right" TEXT="Haaramine ja lohistamine">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_250792124" MODIFIED="1216189240840">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Sa saad s&#245;lmi liigutada kui hiire vasaku klahviga neist kinni haarad ja uues kohas lahti lased.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1720133090" MODIFIED="1216189839238">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme liigutamiseks tuleb hiire vasaku klahviga haarata kinni selle ees olevast s&#245;&#245;rist, mis ilmub sinna hiirekursori liigutamisel.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1326060747" MODIFIED="1216189990967">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme viimiseks otse peas&#245;lme alla, haara lihtsalt hiire vasaku klahviga s&#245;lmest kinni ja lohista peas&#245;lme kohale.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1994214827" MODIFIED="1216190054560">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme kopeerimiseks (mitte liigutamiseks), hoia all CTRL-klahvi kui lohistad v&#245;i lohista hiire keskmist klahvi all hoides.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_489432369" MODIFIED="1216190811579">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Olemasoleva kaardi muutmiseks, lohista ja kukuta see FreeMind-i taustale. See t&#246;&#246;tab v&#228;hemalt MS Windowsi operatsioonis&#252;steemis.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_503769565" MODIFIED="1216190863653">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Graafilise viite loomiseks hoia all CTRL + SHIFT klahve ja siis haara ja kukuta &#252;ks s&#245;lm teise peale.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1640826119" MODIFIED="1216190918888">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kui mitu s&#245;lme on valitud siis neid k&#245;iki liigutatakse v&#245;i kopeeritakse.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1894344956" MODIFIED="1216190990203">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Sa v&#245;id kukutada infot v&#228;listest rakendustest, n&#228;iteks faile MS Windowsi operatsioonis&#252;steemis, v&#245;i m&#228;rgitud tekstijuppe MS Internet Explorerist.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_958781924" MODIFIED="1216201212458" POSITION="right" TEXT="Kopeerimine ja asetamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_577944755" MODIFIED="1216191126681">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Sa saad kopeerida ja asetada (mitut) s&#245;lme erinevate m&#245;ttekaartide vahel. Lisaks saad asetada tavalist teksti v&#245;i HTML-i teistest programmidest.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_257303524" MODIFIED="1216191297451">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kui asetad tavalist teksti siis eraldi ridadel olev tekst asetatakse eraldi s&#245;lmedena koos nende s&#252;gavustega, mis m&#228;&#228;ratakse kindlaks teksti m&#228;rkide arvuga. Allpool ka m&#245;ned n&#228;ited.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_931741001" MODIFIED="1216200835998">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Puu<br />&#160;&#160;&#160;&#160;&#160;Tamm<br />&#160;&#160;&#160;&#160;&#160;P&#246;&#246;k<br />&#160;&#160;&#160;&#160;&#160;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1174875076" MODIFIED="1216191388934" TEXT="asetatakse kui">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_630727847" MODIFIED="1216191387928" TEXT="Puu">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_10517981" MODIFIED="1216191366645" TEXT="Tamm">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_1473809424" MODIFIED="1216191371256" TEXT="P&#xf6;&#xf6;k">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_1117632907" MODIFIED="1216191656046">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kui asetad HTML-i siis asetatakse see kui paljas tekst. Lisaks asetatakse HTML-is olnud viited alams&#245;lmedena. Allpool ka m&#245;ned n&#228;ited.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1182968610" MODIFIED="1216200835998" TEXT="N&#xe4;idistulemus p&#xe4;rast asetamist:">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1854872512" MODIFIED="1216195174178" TEXT="Ostmine (120236)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1197617245" MODIFIED="1216195181063" TEXT="Linnaelu (19)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1425509419" MODIFIED="1216197300613" TEXT="Viited">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1869102188" LINK="http://directory.google.com/Top/Shopping/" MODIFIED="1216195187114" TEXT="Ostmine">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1972970821" LINK="http://directory.google.com/Top/Home/Urban_Living/" MODIFIED="1216195192339" TEXT="Linnaelu">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_479429594" MODIFIED="1216195518969">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kui asetad failide nimekirja MS Explorerist MS Windowsis siis see asetatakse viidetena neile failidele.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1680490246" MODIFIED="1216195773963">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kui Sa kopeerid FreeMind-is s&#245;lmede haru ja asetad selle lihtsasse tekstiredaktorisse siis s&#245;lmede puu struktuuri n&#228;idatakse taanetega. H&#252;perviited paigutatakse &lt;&gt; sulgude vahele vahele. Allpool ka m&#245;ned n&#228;ited.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_1454908790" MODIFIED="1216200835998" TEXT="Puu">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_633110419" MODIFIED="1216195798447" TEXT="Tamm">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_838560951" MODIFIED="1216200829358" TEXT="P&#xf6;&#xf6;k">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1676658451" MODIFIED="1216197295548" TEXT="asetatakse kui">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_1486548715" MODIFIED="1216195827676">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Puu<br />&#160;&#160;&#160;&#160;&#160;Tamm<br />&#160;&#160;&#160;&#160;&#160;P&#246;&#246;k<br />&#160;&#160;&#160;&#160;&#160;Google &lt;http://www.google.ee/&gt;<br />
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_1324389903" LINK="http://www.google.ee/" MODIFIED="1216195837675" TEXT="Google">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" ID="ID_1898109526" MODIFIED="1216196259445">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kui FreeMind-is kopeerida s&#245;lmede haru ja asetada see redaktorisse, mis m&#245;istab rikkalikku teksti vormindust siis see vormindus koos teksti v&#228;rvi ja kirjakujuga asetatakse samuti. H&#252;perviited asetatakse &lt;&gt; sulgudesse kui tavaline tekst. Redaktorid, mis m&#245;istavad rikkalikku teksti vormindamist: MS Word, MS Wordpad or MS Outlook, v&#245;i m&#245;ned kaartidega tekstiredaktorid Linuxis.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1853517240" MODIFIED="1216197263566">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme kopeerimiseks ilma alams&#245;lmedeta, vajuta CTRL + Y v&#245;i s&#245;lme kiirmen&#252;&#252;st kasuta valikut Kopeeri &#252;ksik.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="_Freemind_Link_1540212684" MODIFIED="1216201160416" POSITION="right" TEXT="Liigutamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1635291337" MODIFIED="1216200459000">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Tekstikursori liigutamiseks &#252;les, alla, vasakule v&#245;i paremale; kasuta nooleklahve.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1763373897" MODIFIED="1216200543444">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Hetkel eesoleva s&#245;lmede haru algusesse liikumiseks vajuta PageUp klahvile.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1810026836" MODIFIED="1216200571377">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Hetkel eesoleva s&#245;lmede haru l&#245;ppu liikumiseks vajuta PageDown klahvile.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1423109092" MODIFIED="1216200609283">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Keskele peas&#245;lme juurde liikumiseks vajuta ESC-klahvile.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="_Freemind_Link_97763226" MODIFIED="1216200695317">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme vabaks paigutamiseks kaardil lohista seda tema n&#228;htamatust s&#245;&#245;rist (asub s&#245;lme ees ja ilmub n&#228;htavale kui hiir selle kohale viia) kinni haarates.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_4727471" MODIFIED="1216201537122" POSITION="right" TEXT="S&#xf5;lmede kokku- ja lahtivoltimine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_993136713" MODIFIED="1216200802609">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme kokkuvoltimiseks vajuta t&#252;hikuklahvi v&#245;i s&#245;lme kiirmen&#252;&#252;st vali: L&#252;lita voltimist &#252;mber.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_635085497" MODIFIED="1216200820736">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lme lahtivoltimiseks vajuta t&#252;hikuklahvi v&#245;i s&#245;lme kiirmen&#252;&#252;st vali: L&#252;lita voltimist &#252;mber.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1966037322" MODIFIED="1216201147632">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Tasemete kokku/lahti voltimiseks hoia alla ALT-klahvi ja samal ajal keri hiireratast, v&#245;i vajuta ALT+PageUp v&#245;i ka ALT + PageDown. Suurte ja mahukate kaartide puhul on soovitav seda omadust ettevaatlikult kasutada kuna siin v&#245;ib tekkida probleeme (nt m&#228;lu j&#228;&#228;b v&#228;heks).
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_780574400" MODIFIED="1216201322323">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      K&#245;ikide s&#245;lmede korraga lahtivoltimiseks vajuta halli plussm&#228;rgiga nuppu t&#246;&#246;riistaribal v&#245;i kasuta rippmen&#252;&#252;d Liikumine -&gt; Voldi k&#245;ik lahti.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_150591996" MODIFIED="1216201375516">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      K&#245;ikide s&#245;lmede korraga kokkuvoltimiseks vajuta halli miinusm&#228;rgiga nuppu t&#246;&#246;riistaribal v&#245;i kasuta rippmen&#252;&#252;d Liikumine -&gt; Voldi k&#245;ik kokku.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1059424946" MODIFIED="1216201528954">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kokkuvolditud s&#245;lm on t&#228;histatud v&#228;ikese ringiga selle alumise parema nurga juures.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_467411537" MODIFIED="1216201656349" POSITION="right" TEXT="M&#xf5;ttekaartide kerimine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_109928081" MODIFIED="1216201653254">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kaardi kerimiseks lohista seda hiire vasaku klahviga taustast kinni v&#245;ttes v&#245;i lihtsalt hiire ratast kerides. Horisontaalselt hiire rattaga kerimiseks hoia samaegselt all SHIFT-klahvi v&#245;i m&#245;nda hiire klahvi.
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913137192" MODIFIED="1216201877888" POSITION="right" TEXT="Suurendamine/v&#xe4;hendamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_385482752" MODIFIED="1216201869456">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Suurenduse muutmiseks hoia samaaegselt all CTRL-klahvi ning keri hiireratast, v&#245;i hoia samaaegselt all ALT-klahvi ning kasuta &#252;les (v&#228;hendab) / alla (suurendab) nooleklahve. &#220;he v&#245;imalusena v&#245;ib kasutada ka suurenduse t&#246;&#246;riista peamisel t&#246;&#246;riistaribal.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1318678369" MODIFIED="1216202018927" POSITION="right" TEXT="Tegevuste tagasiv&#xf5;tmine ja taastamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_45554617" MODIFIED="1216201918241">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Tegevuse tagasiv&#245;tmiseks vajuta CTRL + Z v&#245;i kasuta rippmen&#252;&#252;d Redigeerimine -&gt; V&#245;ta tagasi.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_725481570" MODIFIED="1216201956499">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Tegevuse uuestitegemiseks vajuta CTRL + Y v&#245;i vali rippmen&#252;&#252;st Redigeerimine -&gt; Tee uuesti.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1106402597" MODIFIED="1216202013857">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Tagasiv&#245;tmise sammude arvu seadistamiseks kasuta rippmen&#252;&#252;d T&#246;&#246;riistad -&gt; Eelistused.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_22510332" MODIFIED="1216202445145" POSITION="right" TEXT="Eksportimine HTML-i">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1878904964" MODIFIED="1216202111782">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lmede haru HTML-i eksportimiseks vajuta CTRL + H. Eksporditud HTML-leht v&#245;ib toetada ka voltimise funktsionaalsust s&#245;ltuvalt sellest, mis oli m&#228;&#228;ratud programmi eelistustes.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_62201964" MODIFIED="1216202205806">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Et kasutada teist eksportimise funktsiooni, kasuta rippmen&#252;&#252; valikut Ekspordi -&gt; Kui XHTML (Javascript-i versioon).
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_83386080" MODIFIED="1216202417810">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Et eksportida koos &#252;levaatliku pildiga HTML-i, kasuta rippmen&#252;&#252;st valikut Ekspordi -&gt; Kui HTML (kl&#245;psatav kaart, pildiversioon).
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1908686168" MODIFIED="1216202912603" POSITION="right" TEXT="Eksportimine raster- v&#xf5;i vektorgraafiliseks pildiks">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1072927157" MODIFIED="1216202492752">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kaardi eksportimiseks PNG-pildiks, kasuta rippmen&#252;&#252; valikut Fail -&gt; Ekspordi -&gt; Kui PNG
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_491092630" MODIFIED="1216202523501" TEXT="Kaardi eksportimiseks JPG-pildiks, kasuta rippmen&#xfc;&#xfc; valikut Fail -&gt; Ekspordi -&gt; Kui JPEG">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_161038476" MODIFIED="1216202721190">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kaardi eksportimiseks SVG-pildiks, kasuta rippmen&#252;&#252; valikut Fail -&gt; Ekspordi -&gt; Kui SVG
    </p>
    <p>
      See funktsioon on saadaval vaid siis kui oled paigaldanud SVG-pistikprogrammi.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_329770204" MODIFIED="1216203705284" POSITION="right" TEXT="Teistesse XML-vormingutesse eksportimine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1487291576" MODIFIED="1216203273703">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kaardi eksportimiseks teise XML-p&#245;hisesse vormingusse, mille jaoks on eraldi XSLT vorm olemas, kasuta rippmen&#252;&#252; valikut Fail -&gt; Ekspordi -&gt; Kasutades XSLT-d
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_306816886" MODIFIED="1216203610047">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kaardi eksportimiseks OpenOffice.org Writer-i dokumendiks kasuta rippmen&#252;&#252;st valikut Fail -&gt; Ekspordi -&gt; OpenOffice.org Writer-i dokument.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1841136119" MODIFIED="1216217093567" POSITION="right" TEXT="Kataloogi struktuuri importimine">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1216211946553" ID="ID_1167782124" MODIFIED="1216217050308">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kataloogide struktuuri importimiseks vali rippmen&#252;&#252;st Fail -&gt; Impordi -&gt; Kataloogide struktuur
    </p>
    <p>
      Siis k&#252;sitakse kataloogi, mille struktuuri soovitakse importida. Kataloogistruktuuri all m&#245;eldakse kataloogidest ja nende sees olevatest alamkataloogidest ning failidest koosnevat puud. Allpool on toodud ka n&#228;idis.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="ID_1586593732" MODIFIED="1216217084661" TEXT="N&#xe4;idis">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="ID_946625728" MODIFIED="1216217082479" TEXT="Valitud kataloog">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_474941936" LINK="C:\Program%20Files\Microsoft%20Office\Office\Bitmaps" MODIFIED="1216187545041" TEXT="C:\Program Files\Microsoft Office\Office\Bitmaps">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="ID_1954366926" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/" MODIFIED="1216217073101" TEXT="Dbwiz">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_950167286" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ASSETS.GIF" MODIFIED="1216187545041" TEXT="ASSETS.GIF"/>
<node CREATED="1124560950732" ID="ID_800426055" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/CONTACTS.GIF" MODIFIED="1216187545041" TEXT="CONTACTS.GIF"/>
<node CREATED="1124560950732" ID="ID_1258787730" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EVTMGMT.GIF" MODIFIED="1216187545041" TEXT="EVTMGMT.GIF"/>
<node CREATED="1124560950732" ID="ID_1788007193" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EXPENSES.GIF" MODIFIED="1216187545041" TEXT="EXPENSES.GIF"/>
<node CREATED="1124560950732" ID="ID_721190495" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/INVENTRY.GIF" MODIFIED="1216187545041" TEXT="INVENTRY.GIF"/>
<node CREATED="1124560950732" ID="ID_38242249" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/LEDGER.GIF" MODIFIED="1216187545041" TEXT="LEDGER.GIF"/>
<node CREATED="1124560950732" ID="ID_1108543275" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ORDPROC.GIF" MODIFIED="1216187545040" TEXT="ORDPROC.GIF"/>
<node CREATED="1124560950732" ID="ID_1051785223" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/RESOURCE.GIF" MODIFIED="1216187545040" TEXT="RESOURCE.GIF"/>
<node CREATED="1124560950732" ID="ID_413667716" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/SERVICE.GIF" MODIFIED="1216187545040" TEXT="SERVICE.GIF"/>
<node CREATED="1124560950732" ID="ID_294983675" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/TIMEBILL.GIF" MODIFIED="1216187545040" TEXT="TIMEBILL.GIF"/>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="ID_706370356" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/" MODIFIED="1216217072054" TEXT="Stiilid">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1010772548" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLENDS.GIF" MODIFIED="1216187545040" TEXT="ACBLENDS.GIF"/>
<node CREATED="1124560950732" ID="ID_1767567712" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLUPRT.GIF" MODIFIED="1216187545040" TEXT="ACBLUPRT.GIF"/>
<node CREATED="1124560950732" ID="ID_62852524" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACEXPDTN.GIF" MODIFIED="1216187545040" TEXT="ACEXPDTN.GIF"/>
<node CREATED="1124560950732" ID="ID_1590095220" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACINDSTR.GIF" MODIFIED="1216187545040" TEXT="ACINDSTR.GIF"/>
<node CREATED="1124560950732" ID="ID_476038182" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACRICEPR.GIF" MODIFIED="1216187545040" TEXT="ACRICEPR.GIF"/>
<node CREATED="1124560950732" ID="ID_1855878202" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSNDSTN.GIF" MODIFIED="1216187545040" TEXT="ACSNDSTN.GIF"/>
<node CREATED="1124560950732" ID="ID_763481040" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSUMIPT.GIF" MODIFIED="1216187545040" TEXT="ACSUMIPT.GIF"/>
<node CREATED="1124560950732" ID="ID_1894968636" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1216187545040" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" ID="ID_910938684" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1216187545040" TEXT="STONE.BMP"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_269203785" MODIFIED="1216217579976" POSITION="right" TEXT="MS Internet Explorer-i j&#xe4;rjehoidjate importimine">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_260446736" MODIFIED="1216217403619">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      MS Internet Explorer-i j&#228;rjehoidjate importimiseks FreeMind-i valida rippmen&#252;&#252;st Fail -&gt; Impordi -&gt; MS Internet Explorer-i j&#228;rjehoidjad. Siis k&#252;sitakse otsiteekonda, kuhu j&#228;rjehoidjad on salvestatud. Kataloog nimega &quot;J&#228;rjehoidjad&quot; (ingl.k. 'Favorites') asub inglisekeelse MS Windows 2000/XP puhul C:\Documents and Settings\&lt;kasutajanimi&gt;\Favorites
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#999999" CREATED="1124560950732" ID="ID_332563589" MODIFIED="1216217570092" TEXT="M&#xe4;rks&#xf5;nad: Microsoft Internet Explorer, MS Internet Explorer MSIE, MS IE.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1709974530" MODIFIED="1216217672715" POSITION="right" TEXT="MindManager X5 m&#xf5;ttekaardi importimine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1753949120" MODIFIED="1216217660535">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      MindManager X5 m&#245;ttekaardi importimiseks valida rippmen&#252;&#252;st Fail -&gt; Impordi -&gt; MindManager X5 kaart
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913645795" MODIFIED="1216218225233" POSITION="right" TEXT="MS Word-i v&#xf5;i MS Outlook-iga integreerimine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1037098567" MODIFIED="1216217849442">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Sa saad asetada kaarte v&#245;i selle osi MS Word-i, MS Wordpad-i v&#245;i MS Outlook-i kirjadesse. &#220;ldiselt saab neid asetada suvalisse programmi, mis saab aru rikkast teksti vormindamisest. Teksti vormindus ja viited v&#245;etakse samuti asetamisel kaasa.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_599307523" LINK="mailto:don.bonton@supermail.com" MODIFIED="1216218092775">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Kl&#245;psates e-posti viitel (n&#228;iteks <i>mailto:eesnimi.perenimi@mail.ee</i>) avatakse vaikimisi e-postiprogramm uue kirjaga MS Windows-is.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_912458776" LINK="mailto:don.bonton@supermail.com?subject=Last%20phone%20call" MODIFIED="1216217984233" TEXT="E-posti viites saab kasutada teema etteandmist.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1653504142" MODIFIED="1216218218990">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Teine v&#245;imalus on m&#245;ttekaart asetada MS Word-i, seda eelnevalt HTML-i v&#228;lja eksportides ja siis omakorda HTML-versiooni kopeerides-asetades MS Word-i.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1822195277" MODIFIED="1216220330553" POSITION="right" TEXT="Eelistuste seadistamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1947073053" MODIFIED="1216218284690">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Eelistuste redigeerimiseks ava T&#246;&#246;riistad -&gt; Eelistused. Enamus eelistuste muudatused j&#245;ustuvad FreeMind-i uuestik&#228;ivitamisel.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1428285526" MODIFIED="1216220284584">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Eelistuste abil saab seadistada: kiirklahvid, HTML-i eksportimise seaded, viis kuidas s&#245;lmede valimine hiirega k&#228;itub, kirjakujude ja servade ning joonte pehmendamine (ingl.k. 'antialiasing'), jne.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#999999" CREATED="1124560950732" ID="ID_1747353627" MODIFIED="1216220324300" TEXT="V&#xf5;tmes&#xf5;nad: muutmine, eelistused, seadistused">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1528828442" MODIFIED="1216228616420" POSITION="right" TEXT="Printimine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1240927179" MODIFIED="1216220425067">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Printida saab nii, et kogu kaart mahutatakse &#252;hele lehele v&#245;i ka mitmele lehele. Seda saab seadistada Fail -&gt; Lehek&#252;lje seaded
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_176846213" MODIFIED="1216221180496">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ruumi paremaks &#228;rakasutamiseks valida R&#245;htasetus (ingl.k. 'landscape') lehek&#252;lje seadistustes.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_281927805" MODIFIED="1216227265273">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Eelvaade enne printimist ei ole tingimata vajalik. Kui Sul on PostScript printer siis saab kaardi printida *.ps faili ja vaadata seda sealt. Kui prindid printeriga, mis ei saa PostScript-ist aru siis printerile saab saata ehk faili, mis on PCL-is, mida aga ei saa ise arvutis kasutada.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_758130759" MODIFIED="1216228605559">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Samuti saab printida veebilehitsejast peale kaardi HTML-i eksportimist v&#245;i ka p&#228;rast MS Word-i, MS Wordpad-i kopeerimist-asetamist. Nii saab ka stiile muuta vastavalt vajadusele.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_841140408" MODIFIED="1216229413099" POSITION="right" TEXT="HTML-i kasutamine s&#xf5;lmede kujundamisel">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_166500306" MODIFIED="1216228737174">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      S&#245;lmed, mis algavad m&#228;rgendiga &lt;html&gt;, visualiseeritakse kasutades HTML-koodi. See omadus on abiks tehniliselt p&#228;devatele inimestele. Allpool m&#245;ned n&#228;ited.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_900496350" MODIFIED="1216228939238">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <h3>
      HTML-i n&#228;idis
    </h3>
    <p class="msonormal">
      Loetelu:
    </p>
    <ul type="disc">
      <li class="msonormal">
        esimene
      </li>
      <li class="msonormal">
        teine
      </li>
    </ul>
    <p class="msonormal">
      Veel v&#245;ib teha <b>rasvast</b> v&#245;i <i>kaldkirja</i>. Samuti <u>allajoonitud</u> v&#245;i <strike>l&#228;bikriipsutatud</strike> kirja. Ka tabelit saame teha:
    </p>
    <table cellpadding="0" class="msonormaltable" cellspacing="0" border="1" style="border: none">
      <tr>
        <td style="padding-left: .75pt; padding-top: .75pt; padding-bottom: .75pt; border: solid windowtext 1.0pt; padding-right: .75pt">
          <p class="msonormal">
            lahter1
          </p>
        </td>
        <td style="border-left: none; padding-left: .75pt; padding-top: .75pt; padding-bottom: .75pt; border: solid windowtext 1.0pt; padding-right: .75pt">
          <p class="msonormal">
            lahter2
          </p>
        </td>
      </tr>
      <tr>
        <td style="border-top: none; padding-left: .75pt; padding-top: .75pt; padding-bottom: .75pt; border: solid windowtext 1.0pt; padding-right: .75pt">
          <p class="msonormal">
            lahter3
          </p>
        </td>
        <td style="border-left: none; border-top: none; padding-left: .75pt; padding-top: .75pt; padding-bottom: .75pt; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; padding-right: .75pt">
          <p class="msonormal">
            lahter4
          </p>
        </td>
      </tr>
    </table>
    <p class="msonormal">
      Ka erinevaid&#160;<font color="#999900">teksti</font> <font color="#336600">v&#228;rve</font> saab kasutada.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_661706379" MODIFIED="1216229407096">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      HTML-i eksport tekstiks v&#245;i rikkalikuks tekstiks (MS Word, MS Wordpad, jne) ei toeta vorminduse v&#245;i piltide kaasapanemist. Samas on HTML-i eksport mugav veebis kasutamiseks kui on olemas FreeMind-i rakend veebilehitsejale.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_271176250" MODIFIED="1216246952682" POSITION="right" TEXT="Piltide kasutamine s&#xf5;lmede illustreerimiseks">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1646926562" MODIFIED="1216230555707">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pildi lisamiseks FreeMind-i vajuta ALT + K v&#245;i vali s&#245;lme kiirmen&#252;&#252;st Lisamine -&gt; Pilt
    </p>
    <p>
      Pildi lisamisel kaob kogu s&#245;lmes olnud tekst. Selliselt lisatud pildid on viited kuna FreeMind-i *.mm fail on XML-ile sarnase struktuuriga ja peavad asuma ka hiljem samas kohas kus nad olid FreeMind-i lisamise hetkel. M&#245;eldud on siin suhtelist aadressi *.mm v&#245;i *.html faili suhtes, s&#245;ltuvalt sellest, milleks kaarti salvestatakse v&#245;i eksporditakse. Piltide suuruse muutmiseks on v&#245;imalik kasutada HTML-i. Piltide lisamine FreeMind-i on arendusj&#228;rgus olev v&#245;imalus ja ei ole veel l&#245;puni v&#228;lja arendatud.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_234082439" MODIFIED="1216230706364">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Toetatud pildifailide vormingud on PNG, JPEG ja GIF.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_249180132" MODIFIED="1216243961428">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Viidatud piltide n&#228;htavaks muutmiseks vajuta ALT + K. Sa v&#245;id haarata ja kukutada mitmeid pilte FreeMind-i, m&#228;rkida neid kui mitut erinevat s&#245;lme. See omadus peaks v&#228;hemalt MS Windowsis t&#246;&#246;tama.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#000000" CREATED="1124560950732" ID="ID_632640717" MODIFIED="1216244094033">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Rohkem tehniline ja mitte nii algaja kasutaja s&#245;bralik on pilte v&#245;imalik lisada HTML-i abil. Sa pead alustama s&#245;lme teksti m&#228;rgendiga &lt;html&gt; - nii saad lisada pilte s&#245;lme.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1152828233" MODIFIED="1216244204676">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      N&#228;iteks<br />&#160;&#160;&lt;html&gt;&lt;img src=&quot;pildid/oun.png&quot;&gt; - see on suhteline aadress<br />&#160;&#160;&lt;html&gt;&lt;img src=&quot;file://C:/Users/Dokumendid/m6ttekaardid/pildid/oun.png&quot;&gt; - see on absoluutne aadress (ei ole soovitav kasutada)<br />
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1156720512" MODIFIED="1216244235915">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Sa v&#245;id kasutada suhtelisi viiteid piltidele (v&#228;ga soovitatav).
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1825247742" MODIFIED="1216246934166">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      M&#245;ned piltide lisamise n&#228;ited, mis t&#246;&#246;tavad vastavates operatsioonis&#252;steemides
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_384038147" MODIFIED="1216245022354">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="/usr/share/pixmaps/abiword.png" />
      
    </p>
    <p>
      Linuxis Abiword
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_520083225" MODIFIED="1216245000432">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF" />
      
    </p>
    <p>
      MS Windowsis MS Office
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_894022254" MODIFIED="1216245014860">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="../../../../usr/share/pixmaps/vlc.png" />
      
    </p>
    <p>
      Linuxis VLC
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1825871160" MODIFIED="1216244986912">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="../../../../usr/share/pixmaps/thunderbird.png" />
      
    </p>
    <p>
      Linuxis Thunderbird
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1124560950732" ID="ID_1605523460" MODIFIED="1216245006660">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF" />
      
    </p>
    <p>
      MS Windowsis MS Office
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1830235047" MODIFIED="1216244979507">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="../../../../usr/share/icons/skype.png" />
      
    </p>
    <p>
      Linuxis Skype
    </p>
  </body>
</html></richcontent>
<node CREATED="1124560950732" ID="ID_306854150" MODIFIED="1216245065511">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <img src="../../../../usr/share/icons/amsn.png" />
      
    </p>
    <p>
      Linuxis aMSN
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1124560950732" ID="ID_860800567" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1216245119049">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      GLOBE.WMF
    </p>
    <p>
      MS Windowsis MS Office
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_620168247" LINK="/usr/share/icons/autopackage-installer.png" MODIFIED="1216245224115">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      autopackage-installer.png
    </p>
    <p>
      Linuxis Synaptic
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_1101644015" MODIFIED="1216247474477" POSITION="right" TEXT="Eksperimentaalse faililukustuse kasutamine">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_155679724" MODIFIED="1216247047622">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      K&#228;esolev FreeMind-i versioon sisaldab katselist faililukustamise tuge, mis on vaikimisi v&#228;lja l&#252;litatud. Hetke seisuga ei ole k&#245;ik asjad t&#228;iuslikult veel lahendatud ent see peaks juba enamus olukordades t&#246;&#246;tama.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1334618640" MODIFIED="1216247111082">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Faili lukustamine tagab selle, et sama faili ei muuda samal ajal rohkem kui &#252;ks inimene v&#228;ltimaks &#252;ksteise poolt info &#252;lekirjutamist.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1452514837" MODIFIED="1216247269320">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Faililukustamise lubamiseks vali rippmen&#252;&#252;st T&#246;&#246;riistad -&gt; Eelistused ja seal on esimese peat&#252;ki &quot;Keskkond&quot; all jaotis &quot;Failid&quot; kus saab siis panna linnukese &quot;Katseline faili lukustamine&quot; ette.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_516331171" MODIFIED="1216247849400" POSITION="right" TEXT="Liikumine avatud m&#xf5;ttekaartide vahel">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1694364871" MODIFIED="1216247470550">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Teise, juba avatud m&#245;ttekaardi peale liikumiseks saab teha eesoleval m&#245;ttekaardi taustal hiire parema klahviga kl&#245;psu ja sealt valida teine lahtiolev m&#245;ttekaart. Samuti saab hiire vasaku klahviga kl&#245;psata &#252;laservas olevatel sakkidel. Klahvikombinatsioon on ALT + SHIFT + nooleklahv vasakule/paremale
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</map>

 	  	 
