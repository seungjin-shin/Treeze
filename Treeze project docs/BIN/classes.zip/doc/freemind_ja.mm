<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<attribute_registry>
<attribute_name NAME="CHECKPOINT_LIST" RESTRICTED="true">
<attribute_value VALUE="[174156662,0,/home/foltin/java/freemind/0_9_0/freemind/doc/.CHECKPOINT/CHECKPOINT_freemind3888192519106551893.mm]"/>
<attribute_value VALUE="[846848357,174156662,/home/foltin/java/freemind/0_9_0/freemind/doc/.CHECKPOINT/CHECKPOINT_freemind7807431841752386277.mm]"/>
</attribute_name>
<attribute_name NAME="LATEST_VERSION" RESTRICTED="true">
<attribute_value VALUE="846848357"/>
</attribute_name>
<attribute_name NAME="VERSION" RESTRICTED="true">
<attribute_value VALUE="846848357"/>
</attribute_name>
</attribute_registry>
<node COLOR="#993300" CREATED="1124560950701" ID="ID_1835469118" MODIFIED="1286970391468">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body width="">
    <p align="center">
      FreeMind<br /><small>- &#12501;&#12522;&#12540;&#12398;&#12510;&#12452;&#12531;&#12489;&#12510;&#12483;&#12503;&#20316;&#25104;&#12477;&#12501;&#12488;&#160; -</small>
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)&#19968;&#37096;&#12395;&#26410;&#35379;&#31623;&#25152;&#12364;&#12354;&#12426;&#12414;&#12377;&#12290;&#32763;&#35379;&#65306;<a target="_blank" href="http://freemind.asia">FreeMind&#20351;&#12362;&#12358;&#20250;</a>
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="18"/>
<node CREATED="1124560950701" FOLDED="true" ID="ID_323315382" LINK="http://freemind.sourceforge.net" MODIFIED="1286966621562" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind
    </p>
    <p>
      &#12507;&#12540;&#12512;&#12506;&#12540;&#12472;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1277707684718" ID="ID_10604959" LINK="http://sourceforge.jp/projects/freemind/" MODIFIED="1277708826140" TEXT="FreeMind&#x65e5;&#x672c;&#x8a9e;&#x30da;&#x30fc;&#x30b8;"/>
<node CREATED="1277707787609" ID="ID_443098759" LINK="http://code.google.com/p/freemind-ja-localization/" MODIFIED="1277708804078" TEXT="FreeMind&#x65e5;&#x672c;&#x8a9e;&#x5316;"/>
<node CREATED="1282618153578" ID="ID_1012072234" LINK="http://freemind.asia/" MODIFIED="1282618200484" TEXT="FreeMind&#x4f7f;&#x304a;&#x3046;&#x4f1a;"/>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_286605645" MODIFIED="1286970391468" POSITION="left" TEXT="&#x30ad;&#x30fc;&#x64cd;&#x4f5c;&#x4e00;&#x89a7;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="ID_1418520269" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12501;&#12449;&#12452;&#12523;&#25805;&#20316;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277704573234" FOLDED="true" ID="ID_714222136" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26032;&#35215;&#12510;&#12483;&#12503;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708162703" MODIFIED="1277708162703">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl+N
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676687" FOLDED="true" ID="ID_1498362303" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12510;&#12483;&#12503;&#12434;&#38283;&#12367;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277704732328" MODIFIED="1277704747484">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl+O
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676671" FOLDED="true" ID="ID_903301078" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20445;&#23384;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708209078" MODIFIED="1277708209078">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl+S
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676671" FOLDED="true" ID="ID_752483918" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21517;&#21069;&#12434;&#20184;&#12369;&#12390;&#20445;&#23384;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708220140" MODIFIED="1277708220140">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl+Shift+S
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676656" FOLDED="true" ID="ID_359158141" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21360;&#21047;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708233890" MODIFIED="1277708233890">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl+P
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676640" FOLDED="true" ID="ID_1952260734" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38281;&#12376;&#12427;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708244500" MODIFIED="1277708244500">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl+W
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676640" FOLDED="true" ID="ID_517088988" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32066;&#20102;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708390406" MODIFIED="1277708390406">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl+Q
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704614062" FOLDED="true" ID="ID_648803056" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21069;&#12398;&#12510;&#12483;&#12503;&#12408;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708422390" MODIFIED="1277708422390">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Alt+Shift+LEFT
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676625" FOLDED="true" ID="ID_848924749" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27425;&#12398;&#12510;&#12483;&#12503;&#12408;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708436015" MODIFIED="1277708442562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Alt+Shift+RIGHT
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676625" FOLDED="true" ID="ID_690634576" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      HTML&#12395;&#12456;&#12463;&#12473;&#12509;&#12540;&#12488;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708464421" MODIFIED="1277708464421">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl+E
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676609" FOLDED="true" ID="ID_172965901" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26525;&#12434;HTML&#12395;&#12456;&#12463;&#12473;&#12509;&#12540;&#12488;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708482046" MODIFIED="1277708482062">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl+H
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676609" FOLDED="true" ID="ID_1877769190" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26525;&#12434;&#26032;&#35215;&#12501;&#12449;&#12452;&#12523;&#12395;&#12456;&#12463;&#12473;&#12509;&#12540;&#12488;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708526093" MODIFIED="1277708526093">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Alt+Shift+A
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277704676593" FOLDED="true" ID="ID_1997432375" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23653;&#27508;&#12398;&#26368;&#26032;&#12501;&#12449;&#12452;&#12523;&#12434;&#38283;&#12367;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708581468" MODIFIED="1277708581468">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl+Shift+W
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1277704671109" FOLDED="true" ID="ID_165510241" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32232;&#38598;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277704682265" MODIFIED="1279501443891">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Find&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+F
    </p>
    <p>
      Find next&#160;&#160;&#160;- Ctrl+G
    </p>
    <p>
      Cut&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+X
    </p>
    <p>
      Copy&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+C
    </p>
    <p>
      Copy single - Ctrl+Shift+C
    </p>
    <p>
      Paste&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+V
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1279501452353" FOLDED="true" ID="ID_894950789" MODIFIED="1286966621562" TEXT="&#x30e2;&#x30fc;&#x30c9;">
<node CREATED="1279501443897" MODIFIED="1279501474750">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      MindMap mode - Alt+1
    </p>
    <p>
      Browse mode&#160;&#160;- Alt+2
    </p>
    <p>
      File mode&#160;&#160;&#160;&#160;- Alt+3
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277708057562" FOLDED="true" ID="ID_1121833260" MODIFIED="1286966621562">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12489;&#26360;&#24335;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708064078" MODIFIED="1279501508673">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Italicize&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+I
    </p>
    <p>
      Bold&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+B
    </p>
    <p>
      Cloud&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+Shift+B
    </p>
    <p>
      Change node color&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Alt+Shift+F
    </p>
    <p>
      Blend node color&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Alt+Shift+B
    </p>
    <p>
      Change node edge color&#160;&#160;&#160;&#160;- Alt+Shift+E
    </p>
    <p>
      Increase node font size&#160;&#160;&#160;- Ctrl+'+'
    </p>
    <p>
      decrease node font size&#160;&#160;&#160;- Ctrl+'-'
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277708042875" FOLDED="true" ID="ID_234589178" MODIFIED="1286966621578">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12490;&#12499;&#12466;&#12540;&#12471;&#12519;&#12531;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708109281" MODIFIED="1277708109296">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Go to root&#160;&#160;- ESCAPEMove up&#160;&#160;&#160;&#160;&#160;- UPMove down&#160;&#160;&#160;- DOWNMove left&#160;&#160;&#160;- LEFTMove right&#160;&#160;- RIGHTFollow link - Ctrl+ENTERZoom out&#160;&#160;&#160;&#160;- Alt+UPZoom in&#160;&#160;&#160;&#160;&#160;- Alt+DOWN
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277708085640" FOLDED="true" ID="ID_80276418" MODIFIED="1286966621578">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12489;&#12398;&#31227;&#21205;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708118125" MODIFIED="1277708118125">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Move node up&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+UPMove node down&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+DOWNMove node left&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+LEFTMove node right&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+RIGHT
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277708076515" FOLDED="true" ID="ID_1019659058" MODIFIED="1286966621578">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12489;&#12398;&#36861;&#21152;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708122734" MODIFIED="1277708122750">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Add sibling node&#160;&#160;&#160;- ENTERAdd child node&#160;&#160;&#160;&#160;&#160;- INSERTAdd sibling before - Shift+ENTERAdd new parent&#160;&#160;&#160;&#160;&#160;- Shift+INSERT
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1277708097890" FOLDED="true" ID="ID_370269107" MODIFIED="1286966621578">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12489;&#12398;&#32232;&#38598;
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1277708127281" MODIFIED="1277708127296">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Edit selected node&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- F2Edit long node&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Alt+ENTERJoin nodes&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- Ctrl+JToggle folded&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;- SPACEToggle children folded&#160;&#160;&#160;&#160;- Ctrl+SPACESet link by filechooser&#160;&#160;&#160;- Ctrl+Shift+KSet link by text entry&#160;&#160;&#160;&#160;- Ctrl+KSet image by filechooser&#160;&#160;- Alt+K
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#006633" CREATED="1124560950701" FOLDED="true" ID="ID_1012425213" MODIFIED="1286970391468" POSITION="left" TEXT="&#x30a4;&#x30f3;&#x30b9;&#x30c8;&#x30fc;&#x30eb;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;&#65289;&#35379;&#20986;&#12375;&#12390;&#12356;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_1808568056" MODIFIED="1286966621578" TEXT="Links">
<node CREATED="1124560950701" LINK="http://java.sun.com/javase/downloads/index.jsp" MODIFIED="1225953435738" TEXT="Download the Java Runtime Environment (at least J2RE1.4)">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" LINK="http://freemind.sourceforge.net/wiki/index.php/Download#Download" MODIFIED="1216753620941" TEXT="Download the Application">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" MODIFIED="1225863201441" TEXT="To install FreeMind on Microsoft Windows, install FreeMind-Windows-Installer-x_y_z-max-java-installer-embedded.exe. This download also includes the obligatory Java installation routine."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="To install FreeMind on Linux, download Java Runtime Environment and FreeMind application itself. First install Java, then unpack FreeMind. To run FreeMind, execute freemind.sh."/>
<node CREATED="1124560950701" MODIFIED="1225863112656" TEXT="To install FreeMind on Mac OS X, download the universial binary Mac_OS_X_Freemind-x_y_z.dmg, double click it and drag the application FreeMind into the program folder. After that FreeMind is started via double click on the application icon inside the program folder."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="On Microsoft Windows and Mac OS X, you can also simply double click the file freemind.jar located at the folder lib to run FreeMind."/>
</node>
<node COLOR="#006633" CREATED="1225863316581" FOLDED="true" ID="ID_1740713509" MODIFIED="1286970391468" POSITION="left" STYLE="fork" TEXT="&#x30e2;&#x30fc;&#x30c9;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;&#65289;&#35379;&#20986;&#12375;&#12390;&#12356;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html>
</richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="ID_120412432" MODIFIED="1286966621578" TEXT="Browsing the files on your computer">
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="To browse files on your computer, switch to file mode in pull-down menu using Modes &gt; File."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="You browse the file tree as if it was a mind map."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="To make a folder the central node of the map, in node context menu use Center."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="To view, edit or execute a file, follow the link of its node."/>
<node CREATED="1124560950701" MODIFIED="1225863254957" TEXT="The file mode is currently not very useful. It is a demonstration that it&apos;s not too difficult to feed data into the tree from other source than mind map. But some people seem to use this mode."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="ID_1211807788" MODIFIED="1286966621578" TEXT="Browsing mind maps">
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="To browse mind maps rather than to edit them, switch to browse mode in pull-down menu using Modes &gt; Browse. Unless used in FreeMind applet, this function is useless."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="The reasons for having a separate browsing mode are technical. Browsing is the only thing you can do in FreeMind applet which can be put to your website. Normally, you would not use browse mode in FreeMind."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="ID_1494880803" MODIFIED="1286966621578" TEXT="About modes">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Although Freemind is primarily a tool for editing mind maps, it is designed to be able to view data coming from various data sources.  To make a specific data source available for viewing in FreeMind, a programmer has to write a so called mode for that data source. File mode is an example. We do not know of any other modes implemented. It is not clear if anyone would really want to make use of this architecture; it&apos;s here to be exploited if someone wants to.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="There is code almost ready for scheme mode which enables you to edit scheme programs. Again, the usefulness is far from clear. Unlike mind map mode, other modes are more of a demonstration of what is possible rather than something actually in use.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="ID_81784633" MODIFIED="1286970404000" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12454;&#12455;&#12502;&#12469;&#12452;&#12488;&#12408;&#12398;FreeMind
    </p>
    <p>
      &#12450;&#12503;&#12524;&#12483;&#12488;&#12398;&#12452;&#12531;&#12473;&#12488;&#12540;&#12523;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)FreeMind 0.9.0&#12391;&#12399;&#12452;&#12531;&#12473;&#12488;&#12540;&#12523;&#28168;&#12415;&#12398;&#12383;&#12417;&#12289;&#35379;&#20986;&#12375;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#000000" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="You can install the applet at your website so that other users can browse your mind maps.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1225908541430" FOLDED="true" ID="ID_1012949404" MODIFIED="1286966621578" TEXT="Installation using Export">
<node CREATED="1225908548033" MODIFIED="1225908562537" TEXT="Use the functionality Export as Java Applet"/>
<node CREATED="1225908574048" MODIFIED="1225908589017" TEXT="The applet is opened in the browser directly after the export."/>
</node>
<node CREATED="1225908533396" FOLDED="true" ID="ID_1711297395" MODIFIED="1286966621578" TEXT="Installation by hand">
<node CREATED="1124560950701" LINK="http://sourceforge.net/project/showfiles.php?group_id=7118" MODIFIED="1124560950701" TEXT="Download the applet, that is freemind-browser."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="The downloaded archive contains freemindbrowser.jar and freemindbrowser.html. Create a link from your page to freemindbrowser.html. In freemindbrowser.html change the path inside so that it points to your mind map."/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Applet&apos;s jar file must be located at the same server as the map itself, for java security reasons. You have to upload the FreeMind applet jar file and your mind map file to your web site."/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="ID_1611411695" MODIFIED="1286970405843" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind&#12450;&#12503;&#12524;&#12483;&#12488;&#12398;&#20351;&#12356;&#26041;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;&#65289;&#35379;&#20986;&#12375;&#12390;&#12356;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="In FreeMind applet, you can only use the browse mode; you cannot edit remote maps. Click a node to toggle folding or to follow a link. Drag the background to move the map. To search the map, use node context menu.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="ID_245803665" MODIFIED="1286970384843" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12496;&#12540;&#12472;&#12519;&#12531;0.6.5&#12395;&#12362;&#12369;&#12427;
    </p>
    <p>
      &#12452;&#12531;&#12479;&#12540;&#12501;&#12455;&#12452;&#12473;&#12398;&#22793;&#26356;&#28857;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)FreeMind 0.9.0&#12424;&#12426;&#21476;&#12356;&#12496;&#12540;&#12472;&#12519;&#12531;&#12398;&#24773;&#22577;&#12398;&#12383;&#12417;&#35379;&#20986;&#12375;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html>
</richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Some of the keyboard settings have been redefined so that they align themselves with what we consider shared standard or intuitive use. Some of the new keyboard settings are modelled on Microsoft tools. New key settings include enter for creating of new siblings below the node, insert for creating new children, F2 for editing nodes - here the Microsoft influence is apparent while there is no intuitive reason to have F2 for node editing. But once you get used to it in all the applications you use, you want to have that one in FreeMind too.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="The keyboard settings can be changed in pull-down menu Tools &gt; Preferences.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_1002133528" MODIFIED="1286970384859" POSITION="left" TEXT="&#x30af;&#x30ec;&#x30b8;&#x30c3;&#x30c8;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)FreeMind 0.9.0&#12424;&#12426;&#21476;&#12356;&#12496;&#12540;&#12472;&#12519;&#12531;&#12398;&#24773;&#22577;&#12398;&#12383;&#12417;&#35379;&#20986;&#12375;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html>
</richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_332071352" MODIFIED="1286966621593" TEXT="&#x958b;&#x767a;&#x8005;">
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_1794018699" MODIFIED="1286966621578" TEXT="Joerg Mueller">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:ponders@t-online.de" MODIFIED="1124560950701" TEXT="ponders@t-online.de">
<font NAME="Dialog" SIZE="10"/>
</node>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="University of Freiburg, Germany">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" LINK="http://danpolansky.blogspot.com/" MODIFIED="1216753531920" TEXT="Daniel Polansky">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Petr Novak">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_1788694019" MODIFIED="1286966621578" TEXT="Christian Foltin">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:christian.foltin@gmx.de" MODIFIED="1124560950701" TEXT="christian.foltin@gmx.de">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Dimitri Polivaev">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1225908784937" FOLDED="true" ID="ID_1230692187" MODIFIED="1286966621578" STYLE="fork" TEXT="Eric Lavarde">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<node COLOR="#558000" CREATED="1225908790680" MODIFIED="1225908818552" STYLE="fork" TEXT="Linux packaging">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_1358393349" MODIFIED="1286966621593" TEXT="&#x8ca2;&#x732e;&#x8005;">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_1913659849" MODIFIED="1286966621593" TEXT="Andrew Iggleden">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Installer Windows">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_391205425" MODIFIED="1286966621593" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Eclipse howto">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_890257290" MODIFIED="1286966621593" TEXT="David Butt">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Tutorial flash">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_254705947" MODIFIED="1286966621593" TEXT="David Low">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Helpful">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_1722555166" LINK="http://freemind.sourceforge.net/wiki/index.php/Translation" MODIFIED="1286966621609" TEXT="&#x7ffb;&#x8a33;&#x8005;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)FreeMind 0.8.0&#20197;&#21069;&#12398;&#24773;&#22577;&#12398;&#12383;&#12417;&#12289;&#35379;&#20986;&#12375;&#12414;&#12379;&#12435;&#12290;&#26368;&#26032;&#12398;&#26085;&#26412;&#35486;&#32763;&#35379;&#32773;&#12399;&#12289;Google&#12467;&#12540;&#12489;&#12300;FreeMind&#26085;&#26412;&#35486;&#21270; &lt;http://code.google.com/p/freemind-ja-localization/&gt;&#12301;&#12434;&#21442;&#29031;&#12290;
    </p>
  </body>
</html></richcontent>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_290541280" MODIFIED="1286966621593" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Italian translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_1980341274" MODIFIED="1286966621593" TEXT="Knud Riish&#xf8;jg&#xe5;rd">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Danish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_1254074811" MODIFIED="1286966621593" TEXT="Takeshi Kakeda">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562983644" FOLDED="true" ID="ID_1179403330" MODIFIED="1286966621593" TEXT="Kohichi Aoki">
<node COLOR="#999999" CREATED="1124560950701" ID="ID_461650185" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_519364669" MODIFIED="1286966621593" TEXT="Alex Dukal">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562998159" FOLDED="true" ID="ID_1379288939" MODIFIED="1286966621593" TEXT="Hugo Gayosso">
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_627918794" MODIFIED="1286966621593" TEXT="Sylvain Gamel">
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="French translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561242082" FOLDED="true" ID="ID_1820191220" MODIFIED="1286966621593" TEXT="Koen Roggemans">
<node COLOR="#999999" CREATED="1124561245957" MODIFIED="1124561251675" TEXT="Dutch translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561374999" FOLDED="true" ID="ID_606964101" MODIFIED="1286966621593" TEXT="Rafal Kraik">
<node COLOR="#999999" CREATED="1124561377702" MODIFIED="1124561382155" TEXT="Polish translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561969717" FOLDED="true" ID="ID_184878785" MODIFIED="1286966621593" TEXT="Goliath">
<node COLOR="#999999" CREATED="1124561438294" MODIFIED="1124561445950" TEXT="Korean translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561753254" FOLDED="true" ID="ID_699342909" MODIFIED="1286966621593" TEXT="Martin Srebotnjak (nick: Miles a.k.a. filmsi)">
<node COLOR="#999999" CREATED="1124561491886" MODIFIED="1124561506386" TEXT="Slovenian translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561814721" FOLDED="true" ID="ID_1903421552" MODIFIED="1286966621593" TEXT="William Chen">
<node COLOR="#999999" CREATED="1124561497308" MODIFIED="1124561506011" TEXT="Chinese translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561823877" FOLDED="true" ID="ID_1308336041" MODIFIED="1286966621593" TEXT="Radek &#x160;varc">
<node COLOR="#999999" CREATED="1124561515761" MODIFIED="1124561519885" TEXT="Czech translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562250475" FOLDED="true" ID="ID_1273414345" MODIFIED="1286966621593" TEXT="Bal&#xe1;zs M&#xe1;rton">
<node COLOR="#999999" CREATED="1124562252585" MODIFIED="1124562258428" TEXT="Hungarian translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562948942" FOLDED="true" ID="ID_1235768484" MODIFIED="1286966621609" TEXT="Luis Ferreira ">
<node COLOR="#999999" CREATED="1124562956332" MODIFIED="1124562961879" TEXT="Portuguese translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124563066204" ID="ID_365102738" MODIFIED="1225908777406" TEXT="The credits for translations are probably incomplete. If we have forggoten you, let us know. There are so many translations that it is difficult to keep trac of the authors. In any case a warm thank you goes to everyone who has helped to make the program better.">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="ID_69958093" MODIFIED="1286970391468" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl + F&#12391;&#26908;&#32034;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1277705089125" ID="ID_1060656168" MODIFIED="1286970391453" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ctrl + G &#12391;&#27425;&#12434;&#26908;&#32034;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1277705092843" ID="ID_1355568987" MODIFIED="1286970391453" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12510;&#12483;&#12503;&#20840;&#20307;&#12434;&#26908;&#32034;&#12377;&#12427;&#12395;&#12399;&#12289;Esc&#12434;&#25276;&#12375;&#12390;&#12363;&#12425;&#26908;&#32034;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="ID_1647788346" MODIFIED="1286970391453" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#8594;&#12391;&#12494;&#12540;&#12489;&#12434;&#23637;&#38283;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="ID_1691800165" MODIFIED="1286970391453" POSITION="right" TEXT="&#x306f;&#x3058;&#x3081;&#x306b;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" MODIFIED="1279514031932" TEXT="FreeMind&#x306f;&#x3044;&#x308f;&#x3086;&#x308b;&#x30de;&#x30a4;&#x30f3;&#x30c9;&#x30de;&#x30c3;&#x30d7;&#x306e;&#x4f5c;&#x6210;&#x30bd;&#x30d5;&#x30c8;&#x3067;&#x3059;&#x3002;&#x305f;&#x3060;&#x3057;&#x3001;&#x591a;&#x304f;&#x306e;&#x4eba;&#x306f;FreeMind&#x3092;&#x6298;&#x308a;&#x7573;&#x307f;&#x3067;&#x304d;&#x308b;&#x30ce;&#x30fc;&#x30c8;&#x307e;&#x305f;&#x306f;PIM(&#x500b;&#x4eba;&#x60c5;&#x5831;&#x7ba1;&#x7406;)&#x30c4;&#x30fc;&#x30eb;&#x3068;&#x3057;&#x3066;&#x6d3b;&#x7528;&#x3057;&#x3066;&#x3044;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950701" MODIFIED="1279514154601" TEXT="&#x60c5;&#x5831;&#x306f;&#x30ce;&#x30fc;&#x30c9;&#x3068;&#x3044;&#x3046;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x30dc;&#x30c3;&#x30af;&#x30b9;&#x306b;&#x5165;&#x308a;&#x307e;&#x3059;&#x3002;&#x30ce;&#x30fc;&#x30c9;&#x306f;&#x30a8;&#x30c3;&#x30b8;&#x3068;&#x3044;&#x3046;&#x66f2;&#x7dda;&#x3067;&#x3064;&#x306a;&#x304c;&#x308a;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950701" MODIFIED="1279535403484" TEXT="&#x672c;&#x66f8;&#x306f;FreeMind 0.9.0&#x7528;&#x306e;&#x8aac;&#x660e;&#x66f8;&#x3067;&#x3059;&#x3002;&#x30ad;&#x30fc;&#x30dc;&#x30fc;&#x30c9;&#x64cd;&#x4f5c;&#x3084;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x6a5f;&#x80fd;&#x306e;&#x5834;&#x6240;&#x306f;&#x3001;&#x30d0;&#x30fc;&#x30b8;&#x30e7;&#x30f3;&#x306b;&#x3088;&#x3063;&#x3066;&#x5909;&#x308f;&#x308b;&#x5834;&#x5408;&#x304c;&#x3042;&#x308a;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_273515041" MODIFIED="1286966621640" POSITION="right" TEXT="&#x7279;&#x9577;&#x7684;&#x306a;&#x6a5f;&#x80fd;&#x306e;&#x30c7;&#x30e2;&#x30f3;&#x30b9;&#x30c8;&#x30ec;&#x30fc;&#x30b7;&#x30e7;&#x30f3;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="ID_1911517874" MODIFIED="1286966621609" TEXT="&#x753b;&#x9762;&#x8868;&#x793a;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="ID_1634029386" MODIFIED="1286966621609">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12489;&#12395;&#12399;&#12381;&#12428;&#12382;&#12428;&#33394;&#12434;&#12388;&#12369;&#12425;&#12428;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1124560950701" ID="ID_832383105" MODIFIED="1286964449500" TEXT="Red">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#009900" CREATED="1124560950701" ID="ID_1407959466" MODIFIED="1286964449500" TEXT="Green">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0000cc" CREATED="1124560950701" ID="ID_1161184672" MODIFIED="1286964449500" TEXT="Blue">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_1906079850" MODIFIED="1286966621609">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12489;&#12395;&#12399;&#12381;&#12428;&#12382;&#12428;&#32972;&#26223;&#33394;&#12434;&#12388;&#12369;&#12425;&#12428;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<node BACKGROUND_COLOR="#ffff99" CREATED="1124560950701" ID="ID_1999704505" MODIFIED="1286964449500" TEXT="This">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
<node BACKGROUND_COLOR="#00cccc" CREATED="1124560950701" ID="ID_551539896" MODIFIED="1286964449500" TEXT="That">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_472085740" MODIFIED="1286966621609">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12489;&#12395;&#12399;&#12381;&#12428;&#12382;&#12428;&#26360;&#24335;&#12434;&#35373;&#23450;&#12391;&#12365;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1790131049" MODIFIED="1286964449515" TEXT="Bold">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1551782517" MODIFIED="1286964449515" TEXT="Italics">
<font ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_537648954" MODIFIED="1286964449515" TEXT="Bold and italics">
<font BOLD="true" ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_119763997" MODIFIED="1286966621609">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12489;&#12398;&#12501;&#12457;&#12531;&#12488;&#12469;&#12452;&#12474;&#12418;&#22793;&#12360;&#12425;&#12428;&#12414;&#12377;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_164103678" MODIFIED="1286964449515" TEXT="small">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node CREATED="1124560950701" ID="ID_873780010" MODIFIED="1286964449515" TEXT="normal">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node CREATED="1124560950701" ID="ID_69742291" MODIFIED="1286964449515" TEXT="bigger">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_461890366" MODIFIED="1286966621609" TEXT="Large">
<font NAME="SansSerif" SIZE="20"/>
<node CREATED="1124560950701" ID="ID_1588825444" MODIFIED="1286964449515" TEXT="OOh">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_286874771" MODIFIED="1286966621609">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12501;&#12457;&#12531;&#12488;&#12434;&#22793;&#12360;&#12427;&#12371;&#12392;&#12418;&#12391;&#12365;&#12414;&#12377;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1428504409" MODIFIED="1286964449515" TEXT="This">
<font NAME="Dialog" SIZE="16"/>
</node>
<node CREATED="1124560950701" ID="ID_1590598484" MODIFIED="1286964449515" TEXT="Or that">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_615393810" MODIFIED="1286964449515" TEXT="Or that one">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_1735200604" MODIFIED="1286966621609">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12489;&#12473;&#12479;&#12452;&#12523;&#12434;&#22793;&#12360;&#12427;&#12371;&#12392;&#12418;&#12391;&#12365;&#12414;&#12377;
    </p>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="ID_1290753206" MODIFIED="1286966621609" TEXT="Fork">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_436235711" MODIFIED="1286964449515" TEXT="Fork">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_383341327" MODIFIED="1286964449515" TEXT="Fork">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_1657826853" MODIFIED="1286966621609" STYLE="bubble" TEXT="Bubbled">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_343148311" MODIFIED="1286964449515" STYLE="bubble" TEXT="Bubbled">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1679424695" MODIFIED="1286964449515" STYLE="bubble" TEXT="Bubbled">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="ID_781549809" MODIFIED="1286966621609" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306f;&#x6298;&#x308a;&#x7573;&#x3081;&#x307e;&#x3059;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="ID_369898233" MODIFIED="1286966621609" TEXT="Fold">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1920302666" MODIFIED="1286964449515" TEXT="Hidden">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_319322125" MODIFIED="1286966621609" TEXT="Tree">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1892668855" MODIFIED="1286964449515" TEXT="Oak">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_675414679" MODIFIED="1286964449515" TEXT="Beech">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_59329898" MODIFIED="1286964449515" TEXT="Elm">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="ID_1727548409" MODIFIED="1286966621625" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x306f;&#x6b21;&#x306e;&#x3088;&#x3046;&#x306a;&#x30ea;&#x30f3;&#x30af;&#x3092;&#x8cbc;&#x308c;&#x307e;&#x3059;... ">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_840352788" MODIFIED="1286966621625">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12454;&#12455;&#12502;&#12506;&#12540;&#12472;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_94217200" LINK="http://www.google.com/" MODIFIED="1286964449515" TEXT="http://www.google.com/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_1214726118" LINK="www.google.com" MODIFIED="1286966621609" TEXT="www.google.com">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1095396553" MODIFIED="1286964731031">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Freemind &#12399;&#12289;.com&#12434;&#23455;&#34892;&#12501;&#12449;&#12452;&#12523;&#12392;&#35469;&#35672;&#12375;&#12414;&#12377;&#160; :)
    </p>
  </body>
</html></richcontent>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_212752606" MODIFIED="1286966621625">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12525;&#12540;&#12459;&#12523;&#19978;&#12398;&#12501;&#12457;&#12523;&#12480;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1868849059" LINK="C:/Program%20Files/" MODIFIED="1286964449515" TEXT="C:/Program Files/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1397443470" LINK="/home/" MODIFIED="1286964449515" TEXT="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="ID_357650742" MODIFIED="1286966621625">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23455;&#34892;&#12501;&#12449;&#12452;&#12523;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="ID_237230629" LINK="%SystemRoot%\regedit.exe" MODIFIED="1286966621625" TEXT="%SystemRoot%\regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006600" CREATED="1124560950701" ID="ID_159701528" MODIFIED="1286964687093">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12371;&#12398;&#12450;&#12452;&#12467;&#12531;&#12399;&#23455;&#34892;&#12501;&#12449;&#12452;&#12523;&#12395;&#12388;&#12365;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_751778750" MODIFIED="1286964786265" TEXT="&#x30ed;&#x30fc;&#x30ab;&#x30eb;&#x306e;&#x30b3;&#x30f3;&#x30d4;&#x30e5;&#x30fc;&#x30bf;&#x3084;LAN&#x4e0a;&#x306e;&#x3069;&#x3093;&#x306a;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x306b;&#x3082;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="ID_1201033623" MODIFIED="1286966621625" TEXT="&#x8907;&#x6570;&#x884c;&#x306e;&#x30ce;&#x30fc;&#x30c9;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_115149053" MODIFIED="1286965666640" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x5185;&#x306b;&#x8907;&#x6570;&#x884c;&#x3092;&#x66f8;&#x3044;&#x3066;&#x8907;&#x6570;&#x306e;&#x6bb5;&#x843d;&#x306b;&#x5206;&#x3051;&#x308b;&#x3053;&#x3068;&#x3082;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;&#x30ce;&#x30fc;&#x30c9;&#x5185;&#x306b;&#x8907;&#x6570;&#x884c;&#x3092;&#x66f8;&#x304d;&#x8fbc;&#x3080;&#x4ee3;&#x308f;&#x308a;&#x306b;&#x3001;&#x5404;&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x30ce;&#x30fc;&#x30c8;&#x3092;&#x3064;&#x3051;&#x308b;&#x3053;&#x3068;&#x3082;&#x3067;&#x304d;&#x307e;&#x3059;&#xff08;&#x30ce;&#x30fc;&#x30c8;&#x53c2;&#x7167;&#xff09;&#x3002;&#x30ce;&#x30fc;&#x30c8;&#x306b;&#x30d7;&#x30ec;&#x30fc;&#x30f3;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x306e;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x3092;&#x6301;&#x305f;&#x305b;&#x308b;&#x4ee3;&#x308f;&#x308a;&#x306b;&#x3001;&#x8907;&#x6570;&#x884c;&#x306e;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x77ed;&#x3044;&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x5206;&#x3051;&#x3066;&#x5b50;&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x3059;&#x308b;&#x3053;&#x3068;&#x3082;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1078332576" MODIFIED="1286965746625" TEXT="&quot;Science is facts; just as houses are made of stones, so is science made of facts; but a pile of stones is not a house and a collection of facts is not necessarily science.&quot; --Henri Poincar&#xe9;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;&#65289;&#12371;&#12398;&#12494;&#12540;&#12489;&#12399;&#12289;&#35079;&#25968;&#34892;&#12494;&#12540;&#12489;&#12398;&#20363;&#12391;&#12377;&#12290;&#35379;&#20986;&#12375;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="ID_1031805595" MODIFIED="1286966621625">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25913;&#34892;&#12388;&#12365;&#12398;&#30701;&#12356;&#35079;&#25968;&#34892;&#12494;&#12540;&#12489;
    </p>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_229579138" MODIFIED="1286965981250">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Line,
    </p>
    <p>
      and second,
    </p>
    <p>
      and yet another will do,
    </p>
    <p>
      so what do you think of that?
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;&#65289;&#12371;&#12398;&#12494;&#12540;&#12489;&#12399;&#12289;&#25913;&#34892;&#12375;&#12383;&#12494;&#12540;&#12489;&#12398;&#20363;&#12391;&#12377;&#12290;&#35379;&#20986;&#12375;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="ID_961707793" MODIFIED="1286966621625" TEXT="&#x5148;&#x306b;&#x30e9;&#x30d9;&#x30eb;&#x3092;&#x4ed8;&#x3051;&#x308b;&#x3088;&#x3046;&#x306a;&#x4f7f;&#x3044;&#x65b9;&#x3082;&#x3067;&#x304d;&#x307e;&#x3059;">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1954224545" MODIFIED="1286966621625" TEXT="Tree">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="ID_1758727349" MODIFIED="1286966621625" TEXT="is a">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_595822939" MODIFIED="1286964449531" TEXT="Oak">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="ID_1883397544" MODIFIED="1286966621625" TEXT="is a">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_179878371" MODIFIED="1286964449531" TEXT="Beech">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="ID_445581313" MODIFIED="1286966621625" TEXT="is a">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_672831364" MODIFIED="1286964449531" TEXT="Elm">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="ID_574851120" MODIFIED="1286966621625" TEXT="Tree">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="ID_504031856" MODIFIED="1286966621625" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_807166068" MODIFIED="1286964449531" TEXT="Leaf">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="ID_923041820" MODIFIED="1286966621625" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_1166235473" MODIFIED="1286964449531" TEXT="Trunk">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="ID_533781184" MODIFIED="1286964449531" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x4ed8;&#x3051;&#x3089;&#x308c;&#x307e;&#x3059;">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_1649024605" MODIFIED="1286966621625" TEXT="&#x96f2;&#x3092;&#x304b;&#x3051;&#x3089;&#x308c;&#x307e;&#x3059;">
<cloud/>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1928699646" MODIFIED="1286964449531" TEXT="&#x81ea;&#x7531;&#x306a;&#x8272;&#x3067;">
<cloud COLOR="#ffff33"/>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_1094566115" MODIFIED="1286966621640" TEXT="&#x77e2;&#x5370;&#x3092;&#x4ed8;&#x3051;&#x3089;&#x308c;&#x307e;&#x3059;">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_84515015" MODIFIED="1286965848843">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#30690;&#21360;&#12434;&#12371;&#12371;&#12363;&#12425;
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="_Freemind_Link_1249400461" ENDARROW="Default" ENDINCLINATION="41;0;" ID="Arrow_ID_854000001" STARTARROW="None" STARTINCLINATION="41;0;"/>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1249400461" MODIFIED="1286965845640">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12371;&#12371;&#12395;&#20280;&#12400;&#12375;&#12390;
    </p>
  </body>
</html></richcontent>
<arrowlink COLOR="#6600ff" DESTINATION="_Freemind_Link_880551392" ENDARROW="Default" ENDINCLINATION="47;0;" ID="Freemind_Arrow_Link_85185909" STARTARROW="None" STARTINCLINATION="47;0;"/>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_880551392" MODIFIED="1286965893125">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12371;&#12435;&#12394;&#33394;&#12391;&#12418;
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="_Freemind_Link_1789233193" ENDARROW="Default" ENDINCLINATION="82;44;" ID="Freemind_Arrow_Link_1672464612" STARTARROW="None" STARTINCLINATION="82;44;"/>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1789233193" MODIFIED="1286965886875">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12371;&#12435;&#12394;&#21521;&#12365;&#12391;&#12418;
    </p>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_115738718" MODIFIED="1286966621640" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306f;&#x81ea;&#x7531;&#x306b;&#x914d;&#x7f6e;&#x3067;&#x304d;&#x307e;&#x3059;">
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<node CREATED="1124560950717" HGAP="180" ID="ID_1141573597" MODIFIED="1286965916656" VSHIFT="-52">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12371;&#12371;&#12420;
    </p>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
<node CREATED="1124560950717" HGAP="191" ID="ID_1053286788" MODIFIED="1286965928109">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12371;&#12371;&#12395;&#12418;
    </p>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
</node>
<node CREATED="1225909247697" FOLDED="true" ID="ID_1084806131" MODIFIED="1286966621640">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>&#12522;&#12483;&#12481;</b><i>&#12486;&#12461;&#12473;&#12488;</i><u>&#12494;&#12540;&#12489;</u>
    </p>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
<node CREATED="1225909305745" ID="ID_1322652447" MODIFIED="1286964449546">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <table border="0" style="border-right-width: 0; border-left-width: 0; border-bottom-width: 0; border-top-width: 0; border-style: solid; width: 100%">
      <tr>
        <td valign="top" style="border-right-width: 1; border-left-width: 1; border-top-width: 1; border-bottom-width: 1; border-style: solid; width: 80%">
          <p style="margin-bottom: 1; margin-right: 1; margin-top: 1; margin-left: 1">
            &#12450;&#12503;&#12522;&#12465;&#12540;&#12471;&#12519;&#12531;
          </p>
        </td>
        <td valign="top" style="border-right-width: 1; border-left-width: 1; border-top-width: 1; border-bottom-width: 1; border-style: solid; width: 20%">
          <p style="margin-bottom: 1; margin-right: 1; margin-top: 1; margin-left: 1">
            &#27005;&#12375;&#12373;
          </p>
        </td>
      </tr>
      <tr>
        <td valign="top" style="border-right-width: 1; border-left-width: 1; border-top-width: 1; border-bottom-width: 1; border-style: solid; width: 50%">
          <p style="margin-bottom: 1; margin-right: 1; margin-top: 1; margin-left: 1">
            FreeMind
          </p>
        </td>
        <td valign="top" style="border-right-width: 1; border-left-width: 1; border-top-width: 1; border-bottom-width: 1; border-style: solid; width: 50%">
          <p style="margin-bottom: 1; margin-right: 1; margin-top: 1; margin-left: 1">
            &#39640;
          </p>
        </td>
      </tr>
      <tr>
        <td valign="top" style="border-right-width: 1; border-left-width: 1; border-top-width: 1; border-bottom-width: 1; border-style: solid; width: 50%">
          <p style="margin-bottom: 1; margin-right: 1; margin-top: 1; margin-left: 1">
            L*tus
          </p>
        </td>
        <td valign="top" style="border-right-width: 1; border-left-width: 1; border-top-width: 1; border-bottom-width: 1; border-style: solid; width: 50%">
          <p style="margin-bottom: 1; margin-right: 1; margin-top: 1; margin-left: 1">
            &#20302;
          </p>
        </td>
      </tr>
    </table>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
</node>
<node CREATED="1225909094296" ID="ID_674034611" MODIFIED="1286964449546" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x30ce;&#x30fc;&#x30c8;&#x3092;&#x4ed8;&#x3051;&#x3089;&#x308c;&#x307e;&#x3059;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12371;&#12398;&#12494;&#12540;&#12489;&#12395;&#12399;&#12494;&#12540;&#12488;&#12364;&#20184;&#12356;&#12390;&#12356;&#12414;&#12377;&#12290;&#12300;&#34920;&#31034;&#12301;&#12513;&#12491;&#12517;&#12540;&#12391;&#30011;&#38754;&#19979;&#37096;&#12395;&#34920;&#31034;&#12375;&#12390;&#20351;&#12356;&#12414;&#12377;&#12290;&#12494;&#12540;&#12488;&#12399;&#23436;&#20840;&#12395;&#38560;&#12428;&#12390;&#12356;&#12427;&#12398;&#12391;&#12289;&#12510;&#12452;&#12531;&#12489;&#12510;&#12483;&#12503;&#12395;&#20351;&#12360;&#12427;&#12473;&#12506;&#12540;&#12473;&#12434;&#28187;&#12425;&#12377;&#12371;&#12392;&#12364;&#12391;&#12365;&#12414;&#12377;&#12290;&#38263;&#25991;&#12398;&#20837;&#21147;&#12395;&#12399;&#12510;&#12452;&#12531;&#12489;&#12510;&#12483;&#12503;&#12434;&#12365;&#12428;&#12356;&#12395;&#12375;&#12383;&#12414;&#12414;&#12486;&#12461;&#12473;&#12488;&#12434;&#20837;&#21147;&#12377;&#12427;&#26368;&#12418;&#33391;&#12356;&#26041;&#27861;&#12391;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="&#x30e1;&#x30a4;&#x30ea;&#x30aa;" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_1276042608" MODIFIED="1286970391453" POSITION="right" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x4f5c;&#x6210;&#x3068;&#x524a;&#x9664;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" MODIFIED="1279536657465" TEXT="&#x5b50;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x4f38;&#x3070;&#x3059;&#x306b;&#x306f;&#x3001;Insert&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279536662121" TEXT="&#x4ed6;&#x306e;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x7de8;&#x96c6;&#x4e2d;&#x306b;&#x5b50;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x4f38;&#x3070;&#x3059;&#x306b;&#x306f;&#x3001;&#x7de8;&#x96c6;&#x4e2d;&#x306b;Insert&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279536666137" TEXT="&#x5f1f;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x4f38;&#x3070;&#x3059;&#x306b;&#x306f;&#x3001;Enter&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279536649129" TEXT="&#x5144;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x4f38;&#x3070;&#x3059;&#x306b;&#x306f;&#x3001;Shift + Enter&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279536682945" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x524a;&#x9664;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;delete&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279536768130" TEXT="&#x30ab;&#x30c3;&#x30c8;&#xff06;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3057;&#x305f;&#x3044;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x30ab;&#x30c3;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Control + X&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279536878186" TEXT="&#x305d;&#x306e;&#x4ed6;&#x306e;&#x64cd;&#x4f5c;&#x306b;&#x306f;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x3066;&#x3001;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x3092;&#x8868;&#x793a;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_998985024" MODIFIED="1286970391453" POSITION="right" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x7de8;&#x96c6;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_519923426" MODIFIED="1279537006378" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x7de8;&#x96c6;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;F2&#x3001;HOME&#x3001;END&#x306e;&#x3044;&#x305a;&#x308c;&#x304b;&#x306e;&#x30ad;&#x30fc;&#x3001;&#x307e;&#x305f;&#x306f;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x7de8;&#x96c6;&#x300d;&#x3002;&#xa;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x7de8;&#x96c6;&#x3092;&#x7d42;&#x3048;&#x308b;&#x306b;&#x306f;&#x3001;ENTER&#x3002;">
<arrowlink DESTINATION="_Freemind_Link_519923426" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_1179992477" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279537272332" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x5185;&#x306e;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x3092;&#x66f8;&#x304d;&#x63db;&#x3048;&#x308b;&#x306b;&#x306f;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x76f4;&#x63a5;&#x30bf;&#x30a4;&#x30d4;&#x30f3;&#x30b0;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279537481614" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x7de8;&#x96c6;&#x4e2d;&#x306b;&#x9577;&#x6587;&#x7de8;&#x96c6;&#x306b;&#x5207;&#x308a;&#x66ff;&#x3048;&#x308b;&#x306b;&#x306f;&#x3001;Alt + Enter&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279537650387" TEXT="&#x9577;&#x6587;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x5206;&#x5272;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x9577;&#x6587;&#x7de8;&#x96c6;&#x753b;&#x9762;&#x306e;&#x300c;&#x5206;&#x5272;&#x300d;&#x30dc;&#x30bf;&#x30f3;&#x3002;&#x307e;&#x305f;&#x306f;&#x3001;&#x9577;&#x6587;&#x7de8;&#x96c6;&#x753b;&#x9762;&#x3067;Alt + S&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279537958798" TEXT="&#x9577;&#x6587;&#x7de8;&#x96c6;&#x753b;&#x9762;&#x3067;&#x6539;&#x884c;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Control + Enter&#x3002;&#x77ed;&#x6587;&#x7de8;&#x96c6;&#x753b;&#x9762;&#x3067;&#x306f;&#x6539;&#x884c;&#x3067;&#x304d;&#x307e;&#x305b;&#x3093;&#x3002;">
<arrowlink DESTINATION="_Freemind_Link_1445647544" ENDARROW="Default" ENDINCLINATION="118;0;" ID="Freemind_Arrow_Link_1628309717" STARTARROW="None" STARTINCLINATION="118;0;"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279538282861" TEXT="&#x9577;&#x6587;&#x7de8;&#x96c6;&#x753b;&#x9762;&#x3067;&#x9078;&#x629e;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x3092;&#x30b3;&#x30d4;&#x30fc;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x3066;&#x300c;&#x30b3;&#x30d4;&#x30fc;&#x300d;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279538505114" TEXT="&#xa9;&#x306e;&#x3088;&#x3046;&#x306a;&#x7279;&#x6b8a;&#x6587;&#x5b57;&#x3092;&#x8ffd;&#x52a0;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x307e;&#x305a;Microsoft Word&#x306e;&#x3088;&#x3046;&#x306a;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x30a8;&#x30c7;&#x30a3;&#x30bf;&#x3067;&#x7279;&#x6b8a;&#x6587;&#x5b57;&#x3092;&#x30b3;&#x30d4;&#x30fc;&#x3057;&#x3066;FreeMind&#x306b;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3002;"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1445647544" MODIFIED="1279539700781" TEXT="&#x30c7;&#x30d5;&#x30a9;&#x30eb;&#x30c8;&#x3067;&#x306f;&#x3001;Enter&#x3067;&#x9577;&#x6587;&#x7de8;&#x96c6;&#x3092;&#x78ba;&#x5b9a;&#x3001;Ctrl + Enter&#x3067;&#x6539;&#x884c;&#x3002;&#x300c;Enter&#x3067;&#x78ba;&#x5b9a;&#x300d;&#x306e;&#x30c1;&#x30a7;&#x30c3;&#x30af;&#x30dc;&#x30c3;&#x30af;&#x30b9;&#x3092;&#x6709;&#x52b9;&#x306b;&#x3057;&#x3066;&#x3044;&#x306a;&#x3051;&#x308c;&#x3070;&#x3001;&#x5404;&#x30ad;&#x30fc;&#x306e;&#x6a5f;&#x80fd;&#x304c;&#x9006;&#x306b;&#x306a;&#x308a;&#x3001;Enter&#x3067;&#x6539;&#x884c;&#x3001;Ctrl + Enter&#x3067;&#x78ba;&#x5b9a;&#x3002;&#xa;&#x74b0;&#x5883;&#x8a2d;&#x5b9a;&#x306e;&#x30c1;&#x30a7;&#x30c3;&#x30af;&#x30dc;&#x30c3;&#x30af;&#x30b9;&#x3067;&#x30c7;&#x30d5;&#x30a9;&#x30eb;&#x30c8;&#x8a2d;&#x5b9a;&#x3092;&#x5909;&#x66f4;&#x3059;&#x308b;&#x3053;&#x3068;&#x304c;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;&#x3055;&#x3089;&#x306b;&#x3001;&#x30c1;&#x30a7;&#x30c3;&#x30af;&#x30dc;&#x30c3;&#x30af;&#x30b9;&#x306e;&#x8a2d;&#x5b9a;&#x306f;FreeMind&#x306e;&#x8d77;&#x52d5;&#x4e2d;&#x306f;&#x4fdd;&#x5b58;&#x3055;&#x308c;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279539946109" TEXT="FreeMind&#x306f;Unicode&#x5b8c;&#x5168;&#x5bfe;&#x5fdc;&#x3067;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_464612466" MODIFIED="1286970391453" POSITION="right" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x66f8;&#x5f0f;&#x8a2d;&#x5b9a;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" MODIFIED="1279540008661" TEXT="&#x592a;&#x5b57;&#x306b;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl + B&#x3002;">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279540025701" TEXT="&#x659c;&#x4f53;&#x306b;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001; Ctrl + I&#x3002;">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279540046701" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x6587;&#x5b57;&#x8272;&#x3092;&#x5909;&#x66f4;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Alt + Shift + F&#x3002;">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1632534623" MODIFIED="1279540355110" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x80cc;&#x666f;&#x8272;&#x3092;&#x5909;&#x66f4;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x66f8;&#x5f0f;&#x300d;&#x306e;&#x300c;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x80cc;&#x666f;&#x8272;&#x300d;&#x3092;&#x4f7f;&#x7528;&#x3002;"/>
<node CREATED="1124560950717" ID="ID_1508036810" MODIFIED="1279601276078" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x6587;&#x5b57;&#x30b5;&#x30a4;&#x30ba;&#x3092;&#x4e0a;&#x3052;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl + &#xff0b; (&#x30c6;&#x30f3;&#x30ad;&#x30fc;&#x4ee5;&#x5916;)&#x3002;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)&#26085;&#26412;&#35486;&#29872;&#22659;&#12391;&#12399;&#21205;&#20316;&#12375;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1017085687" MODIFIED="1279601294296" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x6587;&#x5b57;&#x30b5;&#x30a4;&#x30ba;&#x3092;&#x4e0b;&#x3052;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl + &#x2212; (&#x30c6;&#x30f3;&#x30ad;&#x30fc;&#x4ee5;&#x5916;)&#x3002;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <a href="http://freemind.asia" target="_blank">&#35379;&#27880;</a>)&#26085;&#26412;&#35486;&#29872;&#22659;&#12391;&#12399;&#21205;&#20316;&#12375;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1701983950" MODIFIED="1279541109349" TEXT="&#x30d5;&#x30a9;&#x30f3;&#x30c8;&#x3092;&#x5909;&#x66f4;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x30e1;&#x30a4;&#x30f3;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x306e;&#x30d5;&#x30a9;&#x30f3;&#x30c8;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x3092;&#x4f7f;&#x7528;&#x3002;"/>
<node CREATED="1124560950717" ID="ID_423005119" MODIFIED="1279541140588" TEXT="&#x66f8;&#x5f0f;&#x3092;&#x30b3;&#x30d4;&#x30fc;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Alt + C&#x3002;"/>
<node CREATED="1124560950717" ID="ID_1360929073" MODIFIED="1279541162802" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x66f8;&#x5f0f;&#x3092;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Alt + V&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_1337242869" MODIFIED="1286970391453" POSITION="right" TEXT="&#x30b9;&#x30bf;&#x30a4;&#x30eb;&#x306e;&#x4f7f;&#x3044;&#x65b9;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" MODIFIED="1279541281379" TEXT="&#x30b9;&#x30bf;&#x30a4;&#x30eb;&#x3092;&#x9069;&#x7528;&#x3059;&#x308b;&#x306b;&#x306f;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30b9;&#x30bf;&#x30a4;&#x30eb;&#x300d;&#x304b;&#x3089;&#x9078;&#x629e;&#x3002;&#x30b9;&#x30bf;&#x30a4;&#x30eb;&#x3092;&#x7d20;&#x65e9;&#x304f;&#x9069;&#x7528;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306b;&#x8868;&#x793a;&#x3055;&#x308c;&#x308b;&#x30ad;&#x30fc;&#x30dc;&#x30fc;&#x30c9;&#x30b7;&#x30e7;&#x30fc;&#x30c8;&#x30ab;&#x30c3;&#x30c8;&#x3092;&#x4f7f;&#x7528;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279541478342" TEXT="&#x81ea;&#x4f5c;&#x30b9;&#x30bf;&#x30a4;&#x30eb;&#x3092;&#x8ffd;&#x52a0;&#x307e;&#x305f;&#x306f;&#x65e2;&#x5b58;&#x30b9;&#x30bf;&#x30a4;&#x30eb;&#x3092;&#x5909;&#x66f4;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30b9;&#x30bf;&#x30a4;&#x30eb;&#x300d;&#x304b;&#x3089;&#x300c;&#x30d1;&#x30bf;&#x30fc;&#x30f3;&#x7ba1;&#x7406;&#x300d;&#x3092;&#x958b;&#x3044;&#x3066;&#x7de8;&#x96c6;&#x3057;&#x307e;&#x3059;&#x3002;&#x30ad;&#x30e3;&#x30f3;&#x30bb;&#x30eb;&#x3057;&#x306a;&#x3044;&#x9650;&#x308a;&#x3001;&#x81ea;&#x52d5;&#x7684;&#x306b;&#x4fdd;&#x5b58;&#x3055;&#x308c;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_1227148308" MODIFIED="1286970391453" POSITION="right" TEXT="&#x96f2;&#x3067;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x5f37;&#x8abf;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" MODIFIED="1279541628755" TEXT="&#x96f2;&#x306f;&#x304b;&#x305f;&#x307e;&#x308a;&#x3092;&#x5f37;&#x8abf;&#x3059;&#x308b;&#x306e;&#x306b;&#x3074;&#x3063;&#x305f;&#x308a;&#x3067;&#x3059;&#x3002;&#x30ce;&#x30fc;&#x30c9;&#x3068;&#x305d;&#x306e;&#x5b50;&#x30ce;&#x30fc;&#x30c9;&#x5168;&#x4f53;&#x3092;&#x5f37;&#x8abf;&#x3057;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279541716117" TEXT="&#x96f2;&#x3092;&#x8ffd;&#x52a0;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl + Shift + B&#x3001;&#x307e;&#x305f;&#x306f;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x633f;&#x5165;&#x300d;&#x306e;&#x300c;&#x96f2;&#x300d;&#x3092;&#x4f7f;&#x3044;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279541707723" TEXT="&#x96f2;&#x306e;&#x8272;&#x3092;&#x5909;&#x66f4;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x66f8;&#x5f0f;&#x300d;&#x306e;&#x300c;&#x96f2;&#x306e;&#x8272;&#x300d;&#x3092;&#x4f7f;&#x3044;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1274825529" MODIFIED="1286966621640" TEXT="&#x96f2;&#x306f;&#x7dd1;&#x306a;&#x3069;&#x306e;&#x69d8;&#x3005;&#x306a;&#x80cc;&#x666f;&#x8272;&#x306b;&#x3059;&#x308b;&#x3053;&#x3068;&#x3082;&#x3067;&#x304d;&#x307e;&#x3059; ...">
<cloud COLOR="#99ff66"/>
<node CREATED="1124560950717" ID="ID_1669638812" MODIFIED="1286966008000">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ... &#12414;&#12383;&#12399;&#33590;&#33394;&#12395;&#12290;
    </p>
  </body>
</html></richcontent>
<cloud COLOR="#504213"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_1108148779" MODIFIED="1286970391453" POSITION="right" TEXT="&#x30ea;&#x30f3;&#x30af;&#x3092;&#x8cbc;&#x308b;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1225954212343" FOLDED="true" ID="ID_183496777" MODIFIED="1286966621640" TEXT="&#x901a;&#x5e38;&#x306e;&#x30cf;&#x30a4;&#x30d1;&#x30fc;&#x30ea;&#x30f3;&#x30af;">
<node CREATED="1225954232570" LINK="http://freemind.asia/" MODIFIED="1279541851431" TEXT="&#x30a6;&#x30a7;&#x30d6;&#x30da;&#x30fc;&#x30b8;"/>
<node CREATED="1225954247489" LINK="freemind_de.mm" MODIFIED="1279541864221" TEXT="&#x4ed6;&#x306e;&#x30de;&#x30c3;&#x30d7;"/>
<node CREATED="1225954285662" MODIFIED="1279541870939" TEXT="&#x30ed;&#x30fc;&#x30ab;&#x30eb;&#x30d5;&#x30a1;&#x30a4;&#x30eb;"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279541923392" TEXT="&#x30cf;&#x30a4;&#x30d1;&#x30fc;&#x30ea;&#x30f3;&#x30af;&#x3092;&#x8ffd;&#x52a0;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl + K&#x3001;&#x307e;&#x305f;&#x306f;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x633f;&#x5165;&#x300d;&#x306e;&#x300c;&#x30cf;&#x30a4;&#x30d1;&#x30fc;&#x30ea;&#x30f3;&#x30af;&#x300d;&#x3092;&#x4f7f;&#x3044;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279541984335" TEXT="&#x30cf;&#x30a4;&#x30d1;&#x30fc;&#x30ea;&#x30f3;&#x30af;&#x3092;&#x524a;&#x9664;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl + K&#x3092;&#x62bc;&#x3057;&#x3066;&#x304b;&#x3089;&#x30cf;&#x30a4;&#x30d1;&#x30fc;&#x30ea;&#x30f3;&#x30af;&#x3092;&#x7a7a;&#x6b04;&#x306b;&#x3057;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" LINK="mailto:info@freemind.asia" MODIFIED="1279542113507">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    &#12513;&#12540;&#12523;&#12450;&#12489;&#12524;&#12473;&#12395;&#12522;&#12531;&#12463;&#12377;&#12427;&#12395;&#12399;&#12289;&#27425;&#12398;&#12424;&#12358;&#12395;&#35373;&#23450;&#12375;&#12414;&#12377;&#12290;

    <p>
      <i>mailto:info@freemind.asia</i>
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" LINK="mailto:info@freemind.asia?subject=FreeMind&#x306e;&#x30d8;&#x30eb;&#x30d7;&#x30c9;&#x30ad;&#x30e5;&#x30e1;&#x30f3;&#x30c8;&#x306b;&#x3064;&#x3044;&#x3066;" MODIFIED="1279542209663">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    &#12513;&#12540;&#12523;&#12450;&#12489;&#12524;&#12473;&#12395;&#20214;&#21517;&#12434;&#12388;&#12369;&#12390;&#12522;&#12531;&#12463;&#12377;&#12427;&#12395;&#12399;&#12289;&#27425;&#12398;&#12424;&#12358;&#12395;&#35373;&#23450;&#12375;&#12414;&#12377;&#12290;

    <p>
      <i>mailto:info@freemind.asia?subject=FreeMind&#12398;&#12504;&#12523;&#12503;&#12489;&#12461;&#12517;&#12513;&#12531;&#12488;&#12395;&#12388;&#12356;&#12390;</i>
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_232236875" MODIFIED="1286966621640" POSITION="right" TEXT="&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x3064;&#x3051;&#x308b;">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" FOLDED="true" ID="ID_785443003" MODIFIED="1286966621640" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x306f;&#x8907;&#x6570;&#x306e;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x4ed8;&#x3051;&#x3089;&#x308c;&#x307e;&#x3059;&#x3002;">
<node CREATED="1225954347826" MODIFIED="1279542354993" TEXT="&#x540c;&#x3058;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3067;&#x3082;&#x4ed8;&#x3051;&#x3089;&#x308c;&#x307e;&#x3059;&#x3002;">
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="ID_602338334" MODIFIED="1286966621640" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x4ed8;&#x3051;&#x308b;&#x306b;&#x306f;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x9078;&#x3093;&#x3067;&#x5de6;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x306b;&#x3042;&#x308b;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3002;">
<node CREATED="1225954381617" MODIFIED="1279546027824" TEXT="&#x30de;&#x30a6;&#x30b9;&#x30aa;&#x30fc;&#x30d0;&#x30fc;&#x3067;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x76f4;&#x63a5;&#x9078;&#x629e;&#x3059;&#x308b;&#x30e2;&#x30fc;&#x30c9;&#x306b;&#x306a;&#x3063;&#x3066;&#x3044;&#x308b;&#x3068;&#x304d;&#x306f;&#x3001;&#x6b21;&#x3082;&#x304a;&#x8aad;&#x307f;&#x304f;&#x3060;&#x3055;&#x3044;&#xff1a;&#x30de;&#x30a6;&#x30b9;&#x30ab;&#x30fc;&#x30bd;&#x30eb;&#x3092;&#x5de6;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x306b;&#x79fb;&#x52d5;&#x3059;&#x308b;&#x9593;&#x3001;&#x9078;&#x629e;&#x72b6;&#x614b;&#x3092;&#x7dad;&#x6301;&#x3059;&#x308b;&#x305f;&#x3081;&#x306b;Alt&#x307e;&#x305f;&#x306f;Ctrl&#x3092;&#x62bc;&#x3057;&#x3066;&#x304f;&#x3060;&#x3055;&#x3044;&#x3002;"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279542606746" TEXT="&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x524a;&#x9664;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x5de6;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x6700;&#x4e0a;&#x90e8;&#x306e;&#x8d64;&#x3044;&#xd7;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279546022440" TEXT="&#x3059;&#x3079;&#x3066;&#x306e;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x524a;&#x9664;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x5de6;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x4e0a;&#x90e8;&#x306e;&#x30b4;&#x30df;&#x7bb1;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279542648378" TEXT="&#x5de6;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x3092;&#x4f7f;&#x308f;&#x305a;&#x306b;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x4ed8;&#x3051;&#x308b;&#x306b;&#x306f;&#x3001;Alt + i&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279542849970" TEXT="&#x73fe;&#x5728;&#x306e;&#x3068;&#x3053;&#x308d;&#x3001;FreeMind&#x3067;&#x4f7f;&#x3048;&#x308b;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x62e1;&#x5f35;&#x3059;&#x308b;&#x306e;&#x306f;&#x7c21;&#x5358;&#x3067;&#x306f;&#x3042;&#x308a;&#x307e;&#x305b;&#x3093;(FreeMind&#x306e;wiki&#x3092;&#x53c2;&#x7167;)&#x304c;&#x3001;&#x6b21;&#x671f;&#x30d0;&#x30fc;&#x30b8;&#x30e7;&#x30f3;&#x3067;&#x5909;&#x66f4;&#x3059;&#x308b;&#x53ef;&#x80fd;&#x6027;&#x304c;&#x3042;&#x308a;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279542968834" TEXT="&#x5de6;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x306e;&#x8868;&#x793a;&#x30fb;&#x975e;&#x8868;&#x793a;&#x306e;&#x5207;&#x308a;&#x66ff;&#x3048;&#x306f;&#x3001;&#x300c;&#x8868;&#x793a;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x5de6;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x306e;&#x8868;&#x793a;&#x300d;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279543388095" TEXT="&#x3053;&#x306e;&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x4ed8;&#x3044;&#x305f;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x306e;&#x4ed6;&#x306b;&#x3082;&#x591a;&#x304f;&#x306e;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x304c;&#x4ed8;&#x3051;&#x3089;&#x308c;&#x307e;&#x3059;&#x3002;">
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
<node CREATED="1225954538460" FOLDED="true" ID="ID_1939051320" MODIFIED="1286966621640" TEXT="&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x306e;&#x5c0f;&#x6280;">
<node CREATED="1225954573251" MODIFIED="1279543304251" TEXT="Shift&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x5de6;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x3067;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3059;&#x308b;&#x3068;&#x3001;&#x3082;&#x3068;&#x3082;&#x3068;&#x4ed8;&#x3044;&#x3066;&#x3044;&#x305f;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x3059;&#x3079;&#x3066;&#x6d88;&#x3057;&#x3066;&#x65b0;&#x3057;&#x3044;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x306b;&#x4ed8;&#x3051;&#x66ff;&#x308f;&#x308a;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1225992042602" MODIFIED="1279543438022" TEXT="Ctrl&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x5de6;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x3067;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3092;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3059;&#x308b;&#x3068;&#x3001;&#x305d;&#x306e;&#x30a2;&#x30a4;&#x30b3;&#x30f3;&#x3060;&#x3051;&#x304c;&#x524a;&#x9664;&#x3055;&#x308c;&#x307e;&#x3059;&#x3002;"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_419685105" MODIFIED="1286970391453" POSITION="right" TEXT="&#x77e2;&#x5370;&#x3092;&#x3064;&#x3051;&#x308b;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1841633318" MODIFIED="1279601322953" TEXT="&#x77e2;&#x5370;&#x3092;&#x3064;&#x3051;&#x308b;&#x306b;&#x306f;&#x3001;Shift&#x3068;Ctrl&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x30c9;&#x30e9;&#x30c3;&#x30b0;&#x3057;&#x3066;&#x77e2;&#x5370;&#x3092;&#x4ed8;&#x3051;&#x305f;&#x3044;&#x3082;&#x3046;&#x3072;&#x3068;&#x3064;&#x306e;&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3057;&#x307e;&#x3059;&#x3002;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3059;&#x308b;&#x3068;&#x304d;&#x306f;Shift&#x3068;Ctrl&#x3088;&#x308a;&#x3082;&#x5148;&#x306b;&#x30de;&#x30a6;&#x30b9;&#x30dc;&#x30bf;&#x30f3;&#x3092;&#x96e2;&#x3057;&#x307e;&#x3059;&#x3002;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)FreeMind 0.9.0&#26085;&#26412;&#35486;&#29872;&#22659;&#12391;&#12399;&#21205;&#20316;&#12375;&#12414;&#12379;&#12435;&#12290;2&#12388;&#12398;&#12494;&#12540;&#12489;&#12434;&#36984;&#12435;&#12391;Ctrl+L&#12434;&#12362;&#34214;&#12417;&#12375;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<arrowlink COLOR="#66ff00" DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="255;0;" ID="Freemind_Arrow_Link_1428344028" STARTARROW="None" STARTINCLINATION="255;0;"/>
</node>
<node CREATED="1216753755454" MODIFIED="1279543989534" TEXT="Ctrl&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;2&#x3064;&#x306e;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x9078;&#x3093;&#x3067;&#x3001;&#x300c;&#x633f;&#x5165;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x77e2;&#x5370;&#x3092;&#x8ffd;&#x52a0;&#x300d;&#x3001;&#x307e;&#x305f;&#x306f;Ctrl + L&#x3002;"/>
<node CREATED="1225992224380" FOLDED="true" ID="ID_737744182" MODIFIED="1286966621656" TEXT="&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x30e1;&#x30cb;&#x30e5;&#x30fc;">
<node CREATED="1124560950717" MODIFIED="1279544285049" TEXT="&#x77e2;&#x5370;&#x306e;&#x8272;&#x3092;&#x5909;&#x3048;&#x308b;&#x306b;&#x306f;&#x3001;&#x77e2;&#x5370;&#x3092;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x3066;&#x300c;&#x77e2;&#x5370;&#x306e;&#x8272;&#x300d;&#x3092;&#x4f7f;&#x3044;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279544438340" TEXT="&#x77e2;&#x5370;&#x306e;&#x5411;&#x304d;&#x3092;&#x5909;&#x3048;&#x308b;&#x306b;&#x306f;&#x3001;&#x77e2;&#x5370;&#x3092;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x3066;&#x77e2;&#x5370;&#x306e;&#x5411;&#x304d;&#x3092;&#x9078;&#x3073;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279544467772" TEXT="&#x77e2;&#x5370;&#x3092;&#x524a;&#x9664;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x3066;&#x300c;&#x77e2;&#x5370;&#x3092;&#x524a;&#x9664;&#x300d;&#x3002;"/>
<node CREATED="1124560950717" ID="_Freemind_Link_266716332" MODIFIED="1279544534093" TEXT="&#x30ea;&#x30f3;&#x30af;&#x5148;&#x306e;&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x79fb;&#x52d5;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x3066;&#x30ea;&#x30f3;&#x30af;&#x5148;&#x3092;&#x9078;&#x3073;&#x307e;&#x3059;&#x3002;"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279544630006" TEXT="&#x77e2;&#x5370;&#x306e;&#x66f2;&#x304c;&#x308a;&#x5177;&#x5408;&#x3092;&#x5909;&#x3048;&#x308b;&#x306b;&#x306f;&#x3001;&#x77e2;&#x5370;&#x3092;&#x30c9;&#x30e9;&#x30c3;&#x30b0;&#x3002;">
<arrowlink DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="256;22;" ID="Freemind_Arrow_Link_1273596772" STARTARROW="None" STARTINCLINATION="244;32;"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279544655379" TEXT="&#x77e2;&#x5370;&#x306e;&#x4f8b;&#x306f;&#x4ee5;&#x4e0b;&#x306e;&#x901a;&#x308a;&#x3002;"/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_487348794" MODIFIED="1286966621656" TEXT="&#x4f8b;">
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1170112929" MODIFIED="1279544697359" TEXT="&#x4ed6;&#x30ce;&#x30fc;&#x30c9;&#x3078;&#x306e;&#x30ea;&#x30f3;&#x30af;">
<arrowlink COLOR="#9999ff" DESTINATION="_Freemind_Link_1492563156" ENDARROW="Default" ENDINCLINATION="122;0;" ID="Freemind_Arrow_Link_33407992" STARTARROW="Default" STARTINCLINATION="30;0;"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_582800196" MODIFIED="1286966621656" TEXT="&#x5b50;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x3042;&#x308b;&#x30ce;&#x30fc;&#x30c9;">
<node CREATED="1124560950717" ID="_Freemind_Link_1492563156" MODIFIED="1279544719215" TEXT="&#x5b50;&#x30ce;&#x30fc;&#x30c9;"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" MODIFIED="1279544724991" TEXT="&#x4ed6;&#x30ce;&#x30fc;&#x30c9;">
<arrowlink DESTINATION="_Freemind_Link_1170112929" ENDARROW="Default" ENDINCLINATION="61;0;" ID="Freemind_Arrow_Link_1872050149" STARTARROW="None" STARTINCLINATION="61;0;"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_768136955" MODIFIED="1286966621656" POSITION="right" TEXT="&#x691c;&#x7d22;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" MODIFIED="1279546175245" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x3068;&#x305d;&#x306e;&#x5b50;&#x30ce;&#x30fc;&#x30c9;&#x5168;&#x4f53;&#x306e;&#x4e2d;&#x304b;&#x3089;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x3092;&#x691c;&#x7d22;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl + F&#x3001;&#x307e;&#x305f;&#x306f;&#x300c;&#x7de8;&#x96c6;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x691c;&#x7d22;&#x300d;&#x3092;&#x4f7f;&#x3044;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279546279031" TEXT="&#x6b21;&#x306e;&#x691c;&#x7d22;&#x7d50;&#x679c;&#x3092;&#x898b;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl + G&#x3001;&#x307e;&#x305f;&#x306f;&#x300c;&#x7de8;&#x96c6;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x6b21;&#x3092;&#x691c;&#x7d22;&#x300d;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279546331087" TEXT="&#x30de;&#x30c3;&#x30d7;&#x5168;&#x4f53;&#x3092;&#x691c;&#x7d22;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x691c;&#x7d22;&#x3059;&#x308b;&#x524d;&#x306b;Escape&#x3092;&#x62bc;&#x3057;&#x3066;&#x30eb;&#x30fc;&#x30c8;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x9078;&#x629e;&#x3057;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279546726376" TEXT="FreeMind&#x306e;&#x691c;&#x7d22;&#x306f;&#x5e45;&#x512a;&#x5148;&#x63a2;&#x7d22;&#x3067;&#x3059;&#x3002;&#x3053;&#x308c;&#x306f;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x304c;&#x6df1;&#x304f;&#x306a;&#x308b;&#x307b;&#x3069;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x8a18;&#x8ff0;&#x304c;&#x3088;&#x308a;&#x8a73;&#x7d30;&#x306b;&#x306a;&#x308b;&#x305f;&#x3081;&#x3067;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279546877615" TEXT="&#x691c;&#x7d22;&#x306f;&#x9078;&#x629e;&#x30ce;&#x30fc;&#x30c9;&#x3068;&#x305d;&#x306e;&#x5b50;&#x30ce;&#x30fc;&#x30c9;&#x5168;&#x4f53;&#x3092;&#x5bfe;&#x8c61;&#x306b;&#x3057;&#x307e;&#x3059;&#x3002;&#x30de;&#x30c3;&#x30d7;&#x5168;&#x4f53;&#x3092;&#x691c;&#x7d22;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x691c;&#x7d22;&#x524d;&#x306b;&#x76f4;&#x63a5;&#x30eb;&#x30fc;&#x30c8;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x9078;&#x3076;&#x304b;&#x3001;ESC&#x3092;&#x62bc;&#x3057;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1226637605339" MODIFIED="1279547072450" TEXT="&#x8907;&#x6570;&#x306e;&#x8a9e;&#x53e5;&#x3067;&#x691c;&#x7d22;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x5404;&#x8a9e;&#x53e5;&#x3092;&#x534a;&#x89d2;&#x30b9;&#x30da;&#x30fc;&#x30b9;&#x3067;&#x533a;&#x5207;&#x308a;&#x307e;&#x3059;(&#x8a9e;&#x9806;&#x306f;&#x4e0d;&#x554f;)&#x3002;"/>
<node CREATED="1226637638394" FOLDED="true" ID="ID_399049168" MODIFIED="1286966621656" TEXT="&#x6587;&#x3092;&#x691c;&#x7d22;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x6587;&#x306e;&#x524d;&#x5f8c;&#x3092;&#x30c0;&#x30d6;&#x30eb;&#x30af;&#x30a9;&#x30fc;&#x30c6;&#x30fc;&#x30b7;&#x30e7;&#x30f3;&#x30de;&#x30fc;&#x30af;&#x3067;&#x304f;&#x304f;&#x308a;&#x307e;&#x3059;&#x3002;">
<node CREATED="1226637681207" FOLDED="true" ID="ID_95968246" MODIFIED="1286966621656">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20363;
    </p>
  </body>
</html></richcontent>
<node CREATED="1226637700062" FOLDED="true" ID="ID_1500082589" MODIFIED="1286966621656" TEXT="one">
<node CREATED="1226637700063" MODIFIED="1226637700063" TEXT="one one"/>
<node CREATED="1226637700063" MODIFIED="1226638280369" TEXT="one two">
<arrowlink DESTINATION="ID_1194260195" ENDARROW="None" ENDINCLINATION="233;0;" ID="Arrow_ID_229096619" STARTARROW="Default" STARTINCLINATION="233;0;"/>
</node>
</node>
<node CREATED="1226637700064" FOLDED="true" ID="ID_1273797265" MODIFIED="1286966621656" TEXT="two">
<node CREATED="1226637700064" MODIFIED="1226638276527" TEXT="two one">
<arrowlink DESTINATION="ID_1194260195" ENDARROW="None" ENDINCLINATION="226;0;" ID="Arrow_ID_836438693" STARTARROW="Default" STARTINCLINATION="226;0;"/>
</node>
<node CREATED="1226637700065" MODIFIED="1226637700065" TEXT="two two"/>
</node>
</node>
<node CREATED="1226638251611" FOLDED="true" ID="ID_684335308" MODIFIED="1286966621656" TEXT="&#x6b21;&#x306e;&#x8a9e;&#x53e5;&#x3067;&#x691c;&#x7d22;&#x3059;&#x308b;&#x3068; ...">
<node CREATED="1226637703016" ID="ID_1983575430" MODIFIED="1286966160390" TEXT="one one (&#x5f15;&#x7528;&#x7b26;&#x306a;&#x3057;), 4&#x4ef6;&#x30d2;&#x30c3;&#x30c8;&#x3057;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1226637912635" ID="ID_1194260195" MODIFIED="1286966156828" TEXT="one two (&#x5f15;&#x7528;&#x7b26;&#x306a;&#x3057;), 2&#x4ef6;&#x30d2;&#x30c3;&#x30c8;&#x3057;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1226637732850" ID="ID_837248187" MODIFIED="1286966153812" TEXT="&quot;one one&quot;, &#x5168;&#x304f;&#x540c;&#x3058;1&#x4ef6;&#x3060;&#x3051;&#x30d2;&#x30c3;&#x30c8;&#x3057;&#x307e;&#x3059;&#x3002;"/>
</node>
</node>
<node CREATED="1225992288920" FOLDED="true" ID="ID_1292790650" MODIFIED="1286966621656" TEXT="&#x65b0;&#x3057;&#x3044;&#x30a4;&#x30f3;&#x30bf;&#x30e9;&#x30af;&#x30c6;&#x30a3;&#x30d6;&#x691c;&#x7d22;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      A&#160;new&#160;search&#160;and&#160;replace&#160;dialog&#160;enables&#160;to&#160;quickly&#160;search&#160;for&#160;text&#160;&#160; fragments&#160;and&#160;to&#160;replace&#160;them.
    </p>
    <p>
      Its&#160;functionality&#160;includes
    </p>
    <ul>
      <li>
        Find&#160;as&#160;you&#160;type:&#160;when&#160;you&#160;start&#160;to&#160;specify&#160;your&#160;search&#160;text,&#160;it&#160;&#160; starts&#160;to&#160;reduce&#160;the&#160;amount&#160;of&#160;displayed&#160;nodes.&#160;It&#160;searches&#160;for&#160;the&#160;&#160; text&#160;inside&#160;the&#160;nodes&#160;text&#160;only&#160;(attached&#160;notes&#160;are&#160;currently&#160;not&#160;&#160; searched).
      </li>
      <li>
        Sortable&#160;node&#160;list:&#160;the&#160;main&#160;table&#160;is&#160;sortable&#160;by&#160;each&#160;criterion.&#160;Even&#160; &#160;by&#160;Icon.&#160;Thus,&#160;it&#160;is&#160;easy&#160;to&#160;find&#160;all&#160;nodes&#160;with&#160;attached&#160;note&#160;for&#160;&#160; example.&#160;Or&#160;to&#160;sort&#160;them&#160;by&#160;creation&#160;date&#160;to&#160;get&#160;the&#160;latest&#160;changes&#160;to&#160; &#160;the&#160;map!
      </li>
      <li>
        Cursor&#160;support:&#160;moving&#160;down&#160;moves&#160;from&#160;the&#160;search&#160;field&#160;to&#160;the&#160;replace&#160; &#160;field&#160;and&#160;then&#160;into&#160;the&#160;list.
      </li>
      <li>
        Node&#160;Path&#160;display:&#160;if&#160;you&#160;select&#160;a&#160;line,&#160;its&#160;path&#160;from&#160;the&#160;root&#160;of&#160;the&#160; &#160;map&#160;is&#160;displayed&#160;below.
      </li>
      <li>
        Direct&#160;access:&#160;if&#160;you&#160;press&#160;enter&#160;inside&#160;the&#160;table,&#160;the&#160;mind&#160;map&#160;&#160; displays&#160;the&#160;selected&#160;node&#160;(menu&#160;item&#160;&quot;select&quot;&#160;and&#160;&quot;select&#160;and&#160;close&quot;).
      </li>
      <li>
        Replace:&#160;it&#160;is&#160;possible&#160;to&#160;replace&#160;all&#160;occurences&#160;or&#160;only&#160;the&#160;nodes&#160;&#160; belonging&#160;to&#160;the&#160;selected&#160;lines.
      </li>
      <li>
        Export:&#160;new&#160;striking&#160;possibility.&#160;Select&#160;some&#160;nodes&#160;and&#160;export&#160;them&#160;to&#160; &#160;a&#160;new&#160;mindmap.&#160;This&#160;makes&#160;it&#160;easy&#160;to&#160;generate&#160;a&#160;todo&#160;list&#160;from&#160;a&#160;&#160; hierachical&#160;mind&#160;map.&#160;For&#160;example,&#160;if&#160;you&#160;mark&#160;every&#160;todo&#160;item&#160;with&#160;&#160; the&#160;bell&#160;sign,&#160;then&#160;simply&#160;sort&#160;this&#160;list&#160;by&#160;icon&#160;and&#160;mark&#160;those&#160;&#160; containing&#160;the&#160;bell.&#160;Then&#160;press&#160;&quot;export&quot;&#160;and&#160;you&#160;get&#160;all&#160;these&#160;nodes&#160;&#160; as&#160;single&#160;nodes&#160;in&#160;a&#160;new&#160;map.
      </li>
    </ul>
  </body>
</html></richcontent>
<node CREATED="1225992295568" ID="ID_478956452" MODIFIED="1286966243109" TEXT="[Ctrl]+[SHIFT]+[F]&#x3067;&#x65b0;&#x3057;&#x3044;&#x691c;&#x7d22;&#x3068;&#x7f6e;&#x63db;&#x30c0;&#x30a4;&#x30a2;&#x30ed;&#x30b0;&#x3092;&#x8868;&#x793a;&#x3057;&#x307e;&#x3059;"/>
<node CREATED="1225992321346" ID="ID_1185547187" MODIFIED="1286966257796">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12510;&#12452;&#12531;&#12489;&#12510;&#12483;&#12503;&#20840;&#20307;&#12434;&#26908;&#32034;&#12375;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1225992332834" ID="ID_325253151" MODIFIED="1286966299906">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27491;&#35215;&#34920;&#29694;&#12395;&#23550;&#24540;&#12375;&#12390;&#12356;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1225992346645" ID="ID_976062891" MODIFIED="1286966368625">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12479;&#12452;&#12500;&#12531;&#12464;&#12392;&#21516;&#26178;&#12395;&#26908;&#32034;&#32080;&#26524;&#12434;&#34920;&#31034;&#12375;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_766148400" MODIFIED="1286966621656" POSITION="right" TEXT="&#x8907;&#x6570;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x9078;&#x629e;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1782397575" MODIFIED="1279547363913" TEXT="&#x8907;&#x6570;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x9078;&#x3076;&#x306b;&#x306f;&#x3001;Ctrl&#x307e;&#x305f;&#x306f;Shift&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279547436390" TEXT="&#x3059;&#x3067;&#x306b;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x9078;&#x3093;&#x3067;&#x3044;&#x3066;&#x3082;&#x3046;1&#x3064;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x8ffd;&#x52a0;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279547560841" TEXT="&#x9023;&#x7d9a;&#x3059;&#x308b;&#x7bc4;&#x56f2;&#x306e;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x9078;&#x3076;&#x306b;&#x306f;&#x3001;Shift&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3059;&#x308b;&#x304b;&#x3001;&#x307e;&#x305f;&#x306f;Shift&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x77e2;&#x5370;&#x30ad;&#x30fc;&#x3092;&#x62bc;&#x3057;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279547773281" TEXT="&#x5b50;&#x30ce;&#x30fc;&#x30c9;&#x5168;&#x4f53;&#x3092;&#x542b;&#x3081;&#x3066;&#x9078;&#x3076;&#x306b;&#x306f;Alt&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3059;&#x308b;&#x304b;&#x3001;&#x307e;&#x305f;&#x306f;Shift&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x30ce;&#x30fc;&#x30c9;&#x304b;&#x3089;&#x89aa;&#x30ce;&#x30fc;&#x30c9;&#x307e;&#x3067;&#x77e2;&#x5370;&#x30ad;&#x30fc;&#x3092;&#x62bc;&#x3057;&#x307e;&#x3059;&#x3002;Ctrl + Shift + A&#x3067;&#x3082;&#x540c;&#x69d8;&#x306e;&#x3053;&#x3068;&#x304c;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" MODIFIED="1279547819417" TEXT="&#x8907;&#x6570;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x9078;&#x629e;&#x3092;&#x30ad;&#x30e3;&#x30f3;&#x30bb;&#x30eb;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x30de;&#x30c3;&#x30d7;&#x306e;&#x80cc;&#x666f;&#x3001;&#x307e;&#x305f;&#x306f;&#x672a;&#x9078;&#x629e;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_1601150350" MODIFIED="1286966621656" POSITION="right" TEXT="&#x30c9;&#x30e9;&#x30c3;&#x30b0;&#xff06;&#x30c9;&#x30ed;&#x30c3;&#x30d7;">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" MODIFIED="1279547898276" TEXT="&#x30c9;&#x30e9;&#x30c3;&#x30b0;&#xff06;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3092;&#x4f7f;&#x3063;&#x3066;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x52d5;&#x304b;&#x305b;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279547985530" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x5b50;&#x30ce;&#x30fc;&#x30c9;&#x3068;&#x3057;&#x3066;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x79fb;&#x52d5;&#x5148;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x5916;&#x5074;&#x306b;&#x30ab;&#x30fc;&#x30bd;&#x30eb;&#x3092;&#x5408;&#x308f;&#x305b;&#x3066;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3057;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279548026146" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x5144;&#x30ce;&#x30fc;&#x30c9;&#x3068;&#x3057;&#x3066;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x79fb;&#x52d5;&#x5148;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x4e0a;&#x5074;&#x306b;&#x30ab;&#x30fc;&#x30bd;&#x30eb;&#x3092;&#x5408;&#x308f;&#x305b;&#x3066;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3057;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1279548095288" TEXT="&#x79fb;&#x52d5;&#x3067;&#x306f;&#x306a;&#x304f;&#x30b3;&#x30d4;&#x30fc;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x30c9;&#x30e9;&#x30c3;&#x30b0;&#xff06;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3057;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1297887653" MODIFIED="1279601378406" TEXT="&#x65e2;&#x5b58;&#x306e;&#x30de;&#x30c3;&#x30d7;&#x3092;&#x7de8;&#x96c6;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;FreeMind&#x306e;&#x80cc;&#x666f;(&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x306a;&#x3044;&#x90e8;&#x5206;)&#x306b;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x3092;&#x30c9;&#x30e9;&#x30c3;&#x30b0;&#xff06;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3057;&#x307e;&#x3059;&#x3002;&#x3053;&#x306e;&#x6a5f;&#x80fd;&#x306f;&#x3001;&#x5c11;&#x306a;&#x304f;&#x3068;&#x3082;Microsoft Windows&#x3067;&#x52d5;&#x4f5c;&#x3057;&#x307e;&#x3059;&#x3002;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)Mac OS X 10.6 Leopard&#12391;&#12418;&#21205;&#20316;&#12375;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" MODIFIED="1279548414401" TEXT="&#x8907;&#x6570;&#x30ce;&#x30fc;&#x30c9;&#x9078;&#x629e;&#x6642;&#x306f;&#x3001;&#x9078;&#x629e;&#x4e2d;&#x306e;&#x5168;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x79fb;&#x52d5;&#x307e;&#x305f;&#x306f;&#x30b3;&#x30d4;&#x30fc;&#x3057;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_112644791" MODIFIED="1279548524082" TEXT="Microsoft Windows&#x4e0a;&#x306e;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x3001;&#x307e;&#x305f;&#x306f;&#x30d6;&#x30e9;&#x30a6;&#x30b6;&#x306e;&#x9078;&#x629e;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x3068;&#x3044;&#x3063;&#x305f;&#x5916;&#x90e8;&#x30a2;&#x30d7;&#x30ea;&#x30b1;&#x30fc;&#x30b7;&#x30e7;&#x30f3;&#x304b;&#x3089;&#x306e;&#x30c7;&#x30fc;&#x30bf;&#x3092;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3059;&#x308b;&#x3053;&#x3068;&#x3082;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="ID_1193063116" MODIFIED="1286966621671" POSITION="right" TEXT="&#x30b3;&#x30d4;&#x30fc;&#xff06;&#x30da;&#x30fc;&#x30b9;&#x30c8;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1409335877" MODIFIED="1279597964125" TEXT="&#x30de;&#x30a4;&#x30f3;&#x30c9;&#x30de;&#x30c3;&#x30d7;&#x9593;&#x3067;(&#x8907;&#x6570;&#x306e;)&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x30b3;&#x30d4;&#x30fc;&#xff06;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x304c;&#x53ef;&#x80fd;&#x3067;&#x3059;&#x3002;&#xa;&#x3055;&#x3089;&#x306b;&#x3001;&#x5916;&#x90e8;&#x306e;&#x30a2;&#x30d7;&#x30ea;&#x30b1;&#x30fc;&#x30b7;&#x30e7;&#x30f3;&#x304b;&#x3089;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x3084;HTML&#x3092;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3059;&#x308b;&#x3053;&#x3068;&#x3082;&#x53ef;&#x80fd;&#x3067;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_772591735" MODIFIED="1279601331312" TEXT="&#x30d7;&#x30ec;&#x30fc;&#x30f3;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x3092;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3057;&#x305f;&#x5834;&#x5408;&#x3001;&#x8907;&#x6570;&#x884c;&#x306e;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x306f;&#x8907;&#x6570;&#x306e;&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3055;&#x308c;&#x307e;&#x3059;&#x3002;&#xa;&#x3069;&#x306e;&#x968e;&#x5c64;&#x306b;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3055;&#x308c;&#x308b;&#x304b;&#x306f;&#x3001;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x306e;&#x30b9;&#x30da;&#x30fc;&#x30b9;&#x306e;&#x6570;&#x3067;&#x6c7a;&#x307e;&#x308a;&#x307e;&#x3059;&#x3002;&#xa;&#x4ee5;&#x4e0b;&#x306b;&#x4f8b;&#x793a;&#x3057;&#x307e;&#x3059;&#x3002;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)&#12371;&#12398;&#27231;&#33021;&#12434;&#20351;&#12358;&#12395;&#12399;&#12289;&#12513;&#12514;&#24115;(&#12494;&#12540;&#12488;&#12497;&#12483;&#12489;)&#12398;&#12424;&#12358;&#12394;HTML&#27231;&#33021;&#12398;&#12394;&#12356;&#12486;&#12461;&#12473;&#12488;&#12456;&#12487;&#12451;&#12479;&#12363;&#12425;&#12506;&#12540;&#12473;&#12488;&#12377;&#12427;&#24517;&#35201;&#12364;&#12354;&#12426;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_1166406195" MODIFIED="1286966621671" TEXT="&#x6728;     &#x30aa;&#x30fc;&#x30af;     &#x30d6;&#x30ca;     ">
<node CREATED="1124560950717" FOLDED="true" ID="ID_617363518" MODIFIED="1286966621656" TEXT="&#x306f;&#x6b21;&#x306e;&#x3088;&#x3046;&#x306b;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3055;&#x308c;&#x307e;&#x3059;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_109725432" MODIFIED="1286966621656" TEXT="&#x6728;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_681926528" MODIFIED="1279597859546" TEXT="&#x30aa;&#x30fc;&#x30af;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_1836369410" MODIFIED="1279597863109" TEXT="&#x30d6;&#x30ca;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_414974370" MODIFIED="1279601343875" TEXT="If you paste HTML, it is pasted as plain text. Additionally, the links contained in HTML are pasted as children of an additional node with text &quot;Links&quot;. Example follows.">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)&#12300;HTML&#12434;&#12506;&#12540;&#12473;&#12488;&#12377;&#12427;&#12392;&#12503;&#12524;&#12540;&#12531;&#12486;&#12461;&#12473;&#12488;&#12392;&#12375;&#12390;&#12506;&#12540;&#12473;&#12488;&#12373;&#12428;&#12414;&#12377;&#12290;&#12373;&#12425;&#12395;&#12289;HTML&#20013;&#12398;&#12522;&#12531;&#12463;&#12399;&#12289;&#12522;&#12531;&#12463;&#12388;&#12365;&#12398;&#26032;&#12375;&#12356;&#23376;&#12494;&#12540;&#12489;&#12392;&#12375;&#12390;&#12506;&#12540;&#12473;&#12488;&#12373;&#12428;&#12414;&#12377;&#12290;&#12301;
    </p>
    <p>
      &#12392;&#12356;&#12358;&#24847;&#21619;&#12391;&#12377;&#12364;&#12289;FreeMind 0.9.0&#12391;HTML&#12434;&#12506;&#12540;&#12473;&#12488;&#12377;&#12427;&#12392;HTML&#12486;&#12461;&#12473;&#12488;&#12391;&#12506;&#12540;&#12473;&#12488;&#12373;&#12428;&#12427;&#12383;&#12417;&#12289;&#12371;&#12398;&#35500;&#26126;&#12399;&#21476;&#12356;FreeMind&#12398;&#12418;&#12398;&#12363;&#12418;&#12375;&#12428;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1695555482" MODIFIED="1286966621671" TEXT="Example result after pasting:">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)FreeMind 0.9.0&#12391;&#12399;&#12289;&#12371;&#12398;&#12424;&#12358;&#12395;&#12506;&#12540;&#12473;&#12488;&#12373;&#12428;&#12394;&#12356;&#12383;&#12417;&#12289;&#35379;&#20986;&#12375;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1671192613" MODIFIED="1279598181984" TEXT="Shopping (120236)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1066127560" MODIFIED="1124560950717" TEXT="Urban Living (19)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="ID_341311952" MODIFIED="1286966621671" TEXT="Links">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1065518519" LINK="http://directory.google.com/Top/Shopping/" MODIFIED="1124560950717" TEXT="Shopping">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1822092768" LINK="http://directory.google.com/Top/Home/Urban_Living/" MODIFIED="1124560950717" TEXT="Urban Living">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_1206074552" MODIFIED="1279598992406" TEXT="Microsoft Windows&#x306e;&#x30a8;&#x30af;&#x30b9;&#x30d7;&#x30ed;&#x30fc;&#x30e9;&#x306e;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x30ea;&#x30b9;&#x30c8;&#x3092;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3059;&#x308b;&#x3068;&#x3001;&#x5404;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x3078;&#x306e;&#x30ea;&#x30f3;&#x30af;&#x96c6;&#x3068;&#x3057;&#x3066;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3055;&#x308c;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950717" ID="ID_1699420675" MODIFIED="1279599120671" TEXT="FreeMind&#x3067;&#x679d;&#x3092;&#x30b3;&#x30d4;&#x30fc;&#x3057;&#x3066;&#x30d7;&#x30ec;&#x30fc;&#x30f3;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x30a8;&#x30c7;&#x30a3;&#x30bf;&#x306b;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3059;&#x308b;&#x3068;&#x3001;&#x30c4;&#x30ea;&#x30fc;&#x69cb;&#x9020;&#x3092;&#x53cd;&#x6620;&#x3057;&#x305f;&#x7b87;&#x6761;&#x66f8;&#x304d;&#x306b;&#x306a;&#x308a;&#x307e;&#x3059;&#x3002;&#x30cf;&#x30a4;&#x30d1;&#x30fc;&#x30ea;&#x30f3;&#x30af;&#x306f;&#x3001;&lt;&gt; &#x306e;&#x62ec;&#x5f27;&#x66f8;&#x304d;&#x306b;&#x306a;&#x308a;&#x307e;&#x3059;&#x3002;&#x4ee5;&#x4e0b;&#x306b;&#x4f8b;&#x793a;&#x3057;&#x307e;&#x3059;&#x3002;"/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_293920725" MODIFIED="1286966621671" TEXT="&#x6728;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_1896533246" MODIFIED="1279599137281" TEXT="&#x30aa;&#x30fc;&#x30af;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_1146606601" MODIFIED="1286966621671" TEXT="&#x30d6;&#x30ca;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" FOLDED="true" ID="ID_1733645532" MODIFIED="1286966621671" TEXT="&#x306f;&#x3053;&#x306e;&#x3088;&#x3046;&#x306b;&#x30da;&#x30fc;&#x30b9;&#x30c8;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_1773459569" MODIFIED="1279599176781" TEXT="&#x6728;     &#x30aa;&#x30fc;&#x30af;     &#x30d6;&#x30ca;     Google &lt;http://www.google.com/&gt;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_904721162" LINK="http://www.google.com/" MODIFIED="1124560950732" TEXT="Google">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" ID="ID_901171430" MODIFIED="1279599505562" TEXT="FreeMind&#x3067;&#x679d;&#x3092;&#x30b3;&#x30d4;&#x30fc;&#x3057;&#x3066;&#x30ea;&#x30c3;&#x30c1;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x5bfe;&#x5fdc;&#x306e;&#x30a8;&#x30c7;&#x30a3;&#x30bf;&#x306b;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3059;&#x308b;&#x3068;&#x3001;&#x6587;&#x5b57;&#x8272;&#x3084;&#x30d5;&#x30a9;&#x30f3;&#x30c8;&#x306a;&#x3069;&#x306e;&#x66f8;&#x5f0f;&#x3082;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3055;&#x308c;&#x307e;&#x3059;&#x3002;&#x30cf;&#x30a4;&#x30d1;&#x30fc;&#x30ea;&#x30f3;&#x30af;&#x306f;&#x3001;&#x30d7;&#x30ec;&#x30fc;&#x30f3;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x540c;&#x69d8;&#x306b; &lt;&gt; &#x306e;&#x62ec;&#x5f27;&#x66f8;&#x304d;&#x306b;&#x306a;&#x308a;&#x307e;&#x3059;&#x3002;&#xa;&#x30ea;&#x30c3;&#x30c1;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x5bfe;&#x5fdc;&#x306e;&#x30a8;&#x30c7;&#x30a3;&#x30bf;&#x306b;&#x306f;&#x3001;Microsoft Word&#x3001;&#x30ef;&#x30fc;&#x30c9;&#x30d1;&#x30c3;&#x30c9;&#x3001;Microsoft Outlook&#x3001;Linux&#x306e;&#x30bf;&#x30d6;&#x5bfe;&#x5fdc;&#x30ce;&#x30fc;&#x30c8;&#x30d6;&#x30c3;&#x30af;&#x306a;&#x3069;&#x304c;&#x3042;&#x308a;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1003556214" MODIFIED="1279599597171" TEXT="&#x5b50;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x542b;&#x3081;&#x305a;&#x306b;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x30b3;&#x30d4;&#x30fc;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl + Shift + C&#x3001;&#x307e;&#x305f;&#x306f;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x9078;&#x629e;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x307f;&#x30b3;&#x30d4;&#x30fc;&#x300d;&#x3092;&#x4f7f;&#x3044;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_373269430" MODIFIED="1286970408296" POSITION="right" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x9078;&#x629e;&#x3068;&#x79fb;&#x52d5;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1218689844" MODIFIED="1279600517062">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12459;&#12540;&#12477;&#12523;&#12434;&#19978;&#19979;&#24038;&#21491;&#12395;&#31227;&#21205;&#12377;&#12427;&#12395;&#12399;&#12289;&#30690;&#21360;&#12461;&#12540;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_734240300" MODIFIED="1279601391593">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26368;&#21021;&#12398;&#20804;&#12494;&#12540;&#12489;&#12395;&#31227;&#21205;&#12377;&#12427;&#12395;&#12399;&#12289;PageUp&#12290;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)&#26368;&#21021;&#12398;&#20804;&#12494;&#12540;&#12489;&#12434;&#36984;&#12435;&#12391;&#12356;&#12427;&#22580;&#21512;&#12399;&#12289;&#35242;&#12398;&#38542;&#23652;&#12398;&#26368;&#21021;&#12398;&#20804;&#12494;&#12540;&#12489;&#12395;&#31227;&#21205;&#12375;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_172832027" MODIFIED="1279601397500">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26368;&#24460;&#12398;&#24351;&#12494;&#12540;&#12489;&#12395;&#31227;&#21205;&#12377;&#12427;&#12395;&#12399;&#12289;PageDown&#12290;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;)&#26368;&#24460;&#12398;&#24351;&#12494;&#12540;&#12489;&#12434;&#36984;&#12435;&#12391;&#12356;&#12427;&#22580;&#21512;&#12399;&#12289;&#35242;&#12398;&#38542;&#23652;&#12398;&#26368;&#24460;&#12398;&#24351;&#12494;&#12540;&#12489;&#12395;&#31227;&#21205;&#12375;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1996437079" MODIFIED="1279600495359">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12523;&#12540;&#12488;&#12494;&#12540;&#12489;&#12395;&#31227;&#21205;&#12377;&#12427;&#12395;&#12399;&#12289;Escape&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_800415793" MODIFIED="1279600649703" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x9593;&#x9694;&#x3092;&#x81ea;&#x7531;&#x306b;&#x5909;&#x3048;&#x308b;&#x306b;&#x306f;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x6839;&#x5143;&#x306b;&#x30ab;&#x30fc;&#x30bd;&#x30eb;&#x3092;&#x5408;&#x308f;&#x305b;&#x308b;&#x3068;&#x8868;&#x308c;&#x308b;&#x30cf;&#x30f3;&#x30c9;&#x30e9;&#x30fc;&#x3092;&#x30c9;&#x30e9;&#x30c3;&#x30b0;&#x3057;&#x3066;&#x52d5;&#x304b;&#x3057;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_1250294298" MODIFIED="1286970391453" POSITION="right" TEXT="&#x6298;&#x308a;&#x7573;&#x307f;&#x3068;&#x5c55;&#x958b;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1986988407" MODIFIED="1282611971375" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x7573;&#x3080;&#x306b;&#x306f;&#x3001;Space&#x30ad;&#x30fc;&#x3001;&#x307e;&#x305f;&#x306f;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x3066;&#x300c;&#x6298;&#x308a;&#x7573;&#x307f;/&#x5c55;&#x958b;&#x300d;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1736660279" MODIFIED="1282612186937" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x5c55;&#x958b;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Space&#x30ad;&#x30fc;&#x3001;&#x307e;&#x305f;&#x306f;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x3066;&#x300c;&#x6298;&#x308a;&#x7573;&#x307f;/&#x5c55;&#x958b;&#x300d;&#x3001;&#x5c55;&#x958b;&#x3057;&#x305f;&#x3044;&#x65b9;&#x5411;&#x306e;&#x77e2;&#x5370;&#x30ad;&#x30fc;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1210957239" MODIFIED="1282612357890" TEXT="&#x968e;&#x5c64;&#x3054;&#x3068;&#x306b;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x6298;&#x308a;&#x7573;&#x3093;&#x3060;&#x308a;&#x5c55;&#x958b;&#x3057;&#x305f;&#x308a;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Alt&#x30ad;&#x30fc;&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x30de;&#x30a6;&#x30b9;&#x30db;&#x30a4;&#x30fc;&#x30eb;&#x3001;&#x307e;&#x305f;&#x306f;Alt+PageUp&#x307e;&#x305f;&#x306f;Alt+PageDown&#x3002;&#x5927;&#x304d;&#x306a;&#x30de;&#x30c3;&#x30d7;&#x3067;&#x306f;&#x3001;&#x3053;&#x306e;&#x6a5f;&#x80fd;&#x3092;&#x6ce8;&#x610f;&#x3057;&#x3066;&#x304a;&#x4f7f;&#x3044;&#x304f;&#x3060;&#x3055;&#x3044;&#x3002;&#x30e1;&#x30e2;&#x30ea;&#x30fc;&#x306e;&#x554f;&#x984c;&#x3092;&#x8d77;&#x3053;&#x3059;&#x5834;&#x5408;&#x304c;&#x3042;&#x308a;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1615500164" MODIFIED="1282612499828" TEXT="&#x5168;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x5c55;&#x958b;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x30e1;&#x30a4;&#x30f3;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x306e;&#x300c;&#x7070;&#x8272;&#x306e;&#x30d7;&#x30e9;&#x30b9;&#x300d;&#x30dc;&#x30bf;&#x30f3;&#x304b;&#x3001;&#x307e;&#x305f;&#x306f;&#x300c;&#x30ca;&#x30d3;&#x30b2;&#x30fc;&#x30b7;&#x30e7;&#x30f3;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x3059;&#x3079;&#x3066;&#x3092;&#x5c55;&#x958b;&#x300d;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_783780040" MODIFIED="1282612554093" TEXT="&#x5168;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x6298;&#x308a;&#x7573;&#x3080;&#x306b;&#x306f;&#x3001;&#x30e1;&#x30a4;&#x30f3;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x306e;&#x300c;&#x7070;&#x8272;&#x306e;&#x30de;&#x30a4;&#x30ca;&#x30b9;&#x300d;&#x30dc;&#x30bf;&#x30f3;&#x3001;&#x307e;&#x305f;&#x306f;&#x300c;&#x30ca;&#x30d3;&#x30b2;&#x30fc;&#x30b7;&#x30e7;&#x30f3;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x3059;&#x3079;&#x3066;&#x3092;&#x6298;&#x308a;&#x7573;&#x3080;&#x300d;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1226321165" MODIFIED="1282612668656" TEXT="&#x6298;&#x308a;&#x7573;&#x3093;&#x3060;&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x306f;&#x3001;&#x5916;&#x5074;&#x306e;&#x7aef;&#x306b;&#x5c0f;&#x3055;&#x306a;&#x25cb;&#x306e;&#x76ee;&#x5370;&#x304c;&#x3064;&#x304d;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_1700286617" MODIFIED="1286970410031" POSITION="right" TEXT="&#x5225;&#x306e;&#x30de;&#x30a4;&#x30f3;&#x30c9;&#x30de;&#x30c3;&#x30d7;&#x3078;&#x306e;&#x79fb;&#x52d5;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1101997535" MODIFIED="1282612795734" TEXT="&#x3059;&#x3067;&#x306b;&#x958b;&#x3044;&#x3066;&#x3044;&#x308b;&#x5225;&#x306e;&#x30de;&#x30a4;&#x30f3;&#x30c9;&#x30de;&#x30c3;&#x30d7;&#x306b;&#x79fb;&#x308b;&#x306b;&#x306f;&#x3001;&#x80cc;&#x666f;&#x3092;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x3066;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x304b;&#x3089;&#x5225;&#x306e;&#x30de;&#x30c3;&#x30d7;&#x540d;&#x3092;&#x9078;&#x629e;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_180549265" MODIFIED="1286970411656" POSITION="right" TEXT="&#x30de;&#x30c3;&#x30d7;&#x306e;&#x30b9;&#x30af;&#x30ed;&#x30fc;&#x30eb;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_544754795" MODIFIED="1282613105546" TEXT="&#x30de;&#x30c3;&#x30d7;&#x3092;&#x30b9;&#x30af;&#x30ed;&#x30fc;&#x30eb;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x80cc;&#x666f;&#x3092;&#x30c9;&#x30e9;&#x30c3;&#x30b0;&#x3001;&#x307e;&#x305f;&#x306f;&#x30de;&#x30a6;&#x30b9;&#x30db;&#x30a4;&#x30fc;&#x30eb;&#x3092;&#x4f7f;&#x3044;&#x307e;&#x3059;&#x3002;&#x30de;&#x30a6;&#x30b9;&#x30db;&#x30a4;&#x30fc;&#x30eb;&#x3067;&#x6c34;&#x5e73;&#x65b9;&#x5411;&#x306b;&#x30b9;&#x30af;&#x30ed;&#x30fc;&#x30eb;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Shift&#x30ad;&#x30fc;&#x307e;&#x305f;&#x306f;&#x7247;&#x65b9;&#x306e;&#x30de;&#x30a6;&#x30b9;&#x30dc;&#x30bf;&#x30f3;&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x30db;&#x30a4;&#x30fc;&#x30eb;&#x3092;&#x56de;&#x3057;&#x307e;&#x3059;&#x3002;">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_433516649" MODIFIED="1286970391453" POSITION="right" TEXT="&#x8868;&#x793a;&#x306e;&#x62e1;&#x5927;&#x30fb;&#x7e2e;&#x5c0f;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_947475145" MODIFIED="1282613288515" TEXT="&#x8868;&#x793a;&#x500d;&#x7387;&#x3092;&#x5909;&#x3048;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl&#x30ad;&#x30fc;&#x3092;&#x62bc;&#x3057;&#x306a;&#x304c;&#x3089;&#x30de;&#x30a6;&#x30b9;&#x30db;&#x30a4;&#x30fc;&#x30eb;&#x3092;&#x56de;&#x3059;&#x304b;&#x3001;Alt+Up&#x307e;&#x305f;&#x306f;Down&#x30ad;&#x30fc;&#x304b;&#x3001;&#x30e1;&#x30a4;&#x30f3;&#x30c4;&#x30fc;&#x30eb;&#x30d0;&#x30fc;&#x306e;&#x300c;&#x8868;&#x793a;&#x500d;&#x7387;&#x300d;&#x3092;&#x4f7f;&#x3044;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_715278706" MODIFIED="1286970391453" POSITION="right" TEXT="&#x53d6;&#x308a;&#x6d88;&#x3057;&#x306e;&#x4f7f;&#x3044;&#x65b9;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_557298061" MODIFIED="1282613352593" TEXT="&#x5143;&#x306b;&#x623b;&#x3059;&#x306b;&#x306f;&#x3001;Ctrl+Z&#x30ad;&#x30fc;&#x3001;&#x307e;&#x305f;&#x306f;&#x300c;&#x7de8;&#x96c6;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x53d6;&#x308a;&#x6d88;&#x3057;&#x300d;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1354042120" MODIFIED="1282613543734" TEXT="&#x3084;&#x308a;&#x76f4;&#x3059;&#x306b;&#x306f;&#x3001;Ctrl+Y&#x30ad;&#x30fc;&#x3001;&#x307e;&#x305f;&#x306f;&#x300c;&#x7de8;&#x96c6;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x3084;&#x308a;&#x76f4;&#x3057;&#x300d;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1817678079" MODIFIED="1282613606000" TEXT="&#x53d6;&#x308a;&#x6d88;&#x3057;&#x53ef;&#x80fd;&#x306a;&#x56de;&#x6570;&#x3092;&#x8a2d;&#x5b9a;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30c4;&#x30fc;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x74b0;&#x5883;&#x8a2d;&#x5b9a;&#x300d;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_165180827" MODIFIED="1286970414296" POSITION="right" TEXT="HTML&#x3078;&#x306e;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1711507520" MODIFIED="1282614012671" TEXT="&#x679d;&#x3092;HTML&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;Ctrl+H&#x30ad;&#x30fc;&#x3002;&#x74b0;&#x5883;&#x8a2d;&#x5b9a;&#x306b;&#x3088;&#x3063;&#x3066;&#x306f;&#x3001;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3057;&#x305f;HTML&#x30da;&#x30fc;&#x30b8;&#x304c;&#x968e;&#x5c64;&#x306e;&#x6298;&#x308a;&#x7573;&#x307f;&#x306b;&#x5bfe;&#x5fdc;&#x3059;&#x308b;&#x5834;&#x5408;&#x304c;&#x3042;&#x308a;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1360137146" MODIFIED="1282613940109" TEXT="&#x5225;&#x306e;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x6a5f;&#x80fd;&#x3092;&#x4f7f;&#x3046;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;Export&#x300d;&#x304b;&#x3089;&#x300c;XHTML(Javascript&#x7248;)&#x300d;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_598076968" MODIFIED="1282615145812" TEXT="&#x96f2;&#x3084;&#x30ea;&#x30f3;&#x30af;&#x3092;&#x542b;&#x3081;&#x305f;&#x30de;&#x30c3;&#x30d7;&#x3092;HTML&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x300d;&#x304b;&#x3089;&#x300c;XHTML(&#x96f2;&#x3084;&#x30ea;&#x30f3;&#x30af;&#x3092;&#x542b;&#x3080;)&#x300d;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_1841028470" MODIFIED="1286970391453" POSITION="right" TEXT="&#x753b;&#x50cf;&#x3078;&#x306e;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_884909586" MODIFIED="1282615218203" TEXT="&#x30de;&#x30c3;&#x30d7;&#x3092;PNG&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x300d;&#x304b;&#x3089;&#x300c;PNG&#x3068;&#x3057;&#x3066;&#x300d;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_690168265" MODIFIED="1282615248609" TEXT="&#x30de;&#x30c3;&#x30d7;&#x3092;JPEG&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x300d;&#x306e;&#x300c;JPEG&#x3068;&#x3057;&#x3066;&#x300d;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_185513303" MODIFIED="1282615392625" TEXT="&#x30de;&#x30c3;&#x30d7;&#x3092;SVG&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x300d;&#x304b;&#x3089;&#x300c;SVG&#x3068;&#x3057;&#x3066;&#x300d;&#x3002;&#x3053;&#x306e;&#x6a5f;&#x80fd;&#x306f;&#x3001;SVG&#x30d7;&#x30e9;&#x30b0;&#x30a4;&#x30f3;&#x3092;&#x30a4;&#x30f3;&#x30b9;&#x30c8;&#x30fc;&#x30eb;&#x3057;&#x3066;&#x3042;&#x308b;&#x5834;&#x5408;&#x306b;&#x9650;&#x308a;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_130923938" MODIFIED="1282615493781" TEXT="&#x30de;&#x30c3;&#x30d7;&#x3092;PDF&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x300d;&#x304b;&#x3089;&#x300c;PDF&#x300d;&#x3002;&#x300c;&#x3053;&#x306e;&#x6a5f;&#x80fd;&#x306f;&#x3001;SVG&#x30d7;&#x30e9;&#x30b0;&#x30a4;&#x30f3;&#x3092;&#x30a4;&#x30f3;&#x30b9;&#x30c8;&#x30fc;&#x30eb;&#x3057;&#x3066;&#x3042;&#x308b;&#x5834;&#x5408;&#x306b;&#x9650;&#x308a;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_1630736246" MODIFIED="1286970391453" POSITION="right" TEXT="XML&#x5f62;&#x5f0f;&#x3067;&#x306e;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_75334671" MODIFIED="1282615694296" TEXT="&#x30de;&#x30c3;&#x30d7;&#x3092;&#x304a;&#x6301;&#x3061;&#x306e;XSLT&#x5909;&#x63db;&#x30b7;&#x30fc;&#x30c8;&#x306b;&#x3042;&#x308b;XML&#x5f62;&#x5f0f;&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x300d;&#x304b;&#x3089;&#x300c;XSLT&#x3092;&#x4f7f;&#x7528;&#x300d;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1577074748" MODIFIED="1282615749515" TEXT="&#x30de;&#x30c3;&#x30d7;&#x3092;OpenOffice Writer&#x5f62;&#x5f0f;&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x300d;&#x304b;&#x3089;&#x300c;OpenOffice Writer&#x6587;&#x66f8;&#x300d;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_835572500" MODIFIED="1286970391453" POSITION="right" TEXT="&#x30d5;&#x30a9;&#x30eb;&#x30c0;&#x69cb;&#x9020;&#x306e;&#x30a4;&#x30f3;&#x30dd;&#x30fc;&#x30c8;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1799862740" MODIFIED="1282616322921" TEXT="&#x30d5;&#x30a9;&#x30eb;&#x30c0;&#x69cb;&#x9020;&#x3092;&#x30a4;&#x30f3;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30a4;&#x30f3;&#x30dd;&#x30fc;&#x30c8;&#x300d;&#x304b;&#x3089;&#x300c;&#x30d5;&#x30a9;&#x30eb;&#x30c0;&#x69cb;&#x9020;&#x300d;&#x3002;&#x30a4;&#x30f3;&#x30dd;&#x30fc;&#x30c8;&#x3057;&#x305f;&#x3044;&#x69cb;&#x9020;&#x306e;&#x30d5;&#x30a9;&#x30eb;&#x30c0;&#x3092;&#x9078;&#x629e;&#x3059;&#x308b;&#x3068;&#x3001;&#x69cb;&#x9020;&#x901a;&#x308a;&#x306b;&#x5168;&#x30b5;&#x30d6;&#x30d5;&#x30a9;&#x30eb;&#x30c0;&#x304c;&#x30de;&#x30c3;&#x30d7;&#x5316;&#x3055;&#x308c;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x304b;&#x3089;&#x30d5;&#x30a9;&#x30eb;&#x30c0;&#x304a;&#x3088;&#x3073;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x3078;&#x30ea;&#x30f3;&#x30af;&#x3057;&#x307e;&#x3059;&#x3002;&#x4ee5;&#x4e0b;&#x306e;&#x30ce;&#x30fc;&#x30c9;&#x306b;&#x4f8b;&#x793a;&#x3057;&#x307e;&#x3059;&#x3002;"/>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="ID_1573619495" MODIFIED="1286966621687" TEXT="&#x4f8b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="ID_540423763" MODIFIED="1286966621687" TEXT="&#x9078;&#x629e;&#x30d5;&#x30a9;&#x30eb;&#x30c0;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1662626487" LINK="C:\Program%20Files\Microsoft%20Office\Office\Bitmaps" MODIFIED="1124560950732" TEXT="C:\Program Files\Microsoft Office\Office\Bitmaps">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="ID_655208283" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/" MODIFIED="1286966621687" TEXT="Dbwiz">
<node CREATED="1124560950732" ID="ID_162399031" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ASSETS.GIF" MODIFIED="1124560950732" TEXT="ASSETS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/CONTACTS.GIF" MODIFIED="1124560950732" TEXT="CONTACTS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EVTMGMT.GIF" MODIFIED="1124560950732" TEXT="EVTMGMT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/EXPENSES.GIF" MODIFIED="1124560950732" TEXT="EXPENSES.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/INVENTRY.GIF" MODIFIED="1124560950732" TEXT="INVENTRY.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/LEDGER.GIF" MODIFIED="1124560950732" TEXT="LEDGER.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/ORDPROC.GIF" MODIFIED="1124560950732" TEXT="ORDPROC.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/RESOURCE.GIF" MODIFIED="1124560950732" TEXT="RESOURCE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/SERVICE.GIF" MODIFIED="1124560950732" TEXT="SERVICE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Dbwiz/TIMEBILL.GIF" MODIFIED="1124560950732" TEXT="TIMEBILL.GIF"/>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="ID_1468683869" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/" MODIFIED="1286966621687" TEXT="Styles">
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLENDS.GIF" MODIFIED="1124560950732" TEXT="ACBLENDS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACBLUPRT.GIF" MODIFIED="1124560950732" TEXT="ACBLUPRT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACEXPDTN.GIF" MODIFIED="1124560950732" TEXT="ACEXPDTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACINDSTR.GIF" MODIFIED="1124560950732" TEXT="ACINDSTR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACRICEPR.GIF" MODIFIED="1124560950732" TEXT="ACRICEPR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSNDSTN.GIF" MODIFIED="1124560950732" TEXT="ACSNDSTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/ACSUMIPT.GIF" MODIFIED="1124560950732" TEXT="ACSUMIPT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_409581884" MODIFIED="1286966621687" POSITION="right" TEXT="IE&#x306e;&#x304a;&#x6c17;&#x306b;&#x5165;&#x308a;&#x306e;&#x30a4;&#x30f3;&#x30dd;&#x30fc;&#x30c8;">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_213882086" MODIFIED="1282616578609">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Internet Explorer&#12398;&#12362;&#27671;&#12395;&#20837;&#12426;&#12434;FreeMind&#12395;&#12452;&#12531;&#12509;&#12540;&#12488;&#12377;&#12427;&#12395;&#12399;&#12289;&#12300;&#12501;&#12449;&#12452;&#12523;&#12301;&#12513;&#12491;&#12517;&#12540;&#12398;&#12300;&#12452;&#12531;&#12509;&#12540;&#12488;&#12301;&#12398;&#12300;&#12456;&#12463;&#12473;&#12503;&#12525;&#12540;&#12521;&#12398;&#12362;&#27671;&#12395;&#20837;&#12426;&#12301;&#12290;&#12300;&#12362;&#27671;&#12395;&#20837;&#12426;&#12301;&#12434;&#20445;&#23384;&#12375;&#12383;&#12501;&#12457;&#12523;&#12480;&#12408;&#12398;&#12497;&#12473;&#12434;&#20837;&#21147;&#12377;&#12427;&#30011;&#38754;&#12364;&#34920;&#31034;&#12373;&#12428;&#12383;&#12425;&#12289;&#12487;&#12451;&#12473;&#12463;&#19978;&#12398;&#12300;&#12362;&#27671;&#12395;&#20837;&#12426;&#12301;&#12392;&#12356;&#12358;&#21517;&#21069;&#12398;&#12501;&#12457;&#12523;&#12480;&#12434;&#36984;&#25246;&#12375;&#12414;&#12377;&#12290;Windows 2000&#12391;&#12399;&#12497;&#12473;&#12399;&#12300;C:\Documents and Settings\&lt;&#12518;&#12540;&#12470;&#12540;&#21517;&gt;\&#12362;&#27671;&#12395;&#20837;&#12426;&#12301;&#12391;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#999999" CREATED="1124560950732" ID="ID_1383210028" MODIFIED="1282616596140" TEXT="&#x30ad;&#x30fc;&#x30ef;&#x30fc;&#x30c9;: Microsoft Internet Explorer, MSIE, MS IE.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_1561632053" MODIFIED="1286970416125" POSITION="right" TEXT="MindManager X5&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x306e;&#x30a4;&#x30f3;&#x30dd;&#x30fc;&#x30c8;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1218599348" MODIFIED="1282616653734" TEXT="MindManager&#x5f62;&#x5f0f;&#x306e;&#x30de;&#x30a4;&#x30f3;&#x30c9;&#x30de;&#x30c3;&#x30d7;&#x3092;&#x30a4;&#x30f3;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30a4;&#x30f3;&#x30dd;&#x30fc;&#x30c8;&#x300d;&#x304b;&#x3089;&#x300c;MindManager X5&#x5f62;&#x5f0f;&#x300d;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_1078512690" MODIFIED="1286970418015" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Word&#12420;Outlook&#12392;&#12398;&#36899;&#25658;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1126132692" MODIFIED="1282616928781" TEXT="&#x30de;&#x30c3;&#x30d7;&#x3084;&#x679d;&#x306f;&#x3001;Microsoft Word&#x3001;Wordpad&#x3001;Outlook&#x306a;&#x3069;&#x306b;&#x8cbc;&#x308a;&#x4ed8;&#x3051;&#x308b;&#x3053;&#x3068;&#x304c;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;&#x901a;&#x5e38;&#x3001;&#x30ea;&#x30c3;&#x30c1;&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x5f62;&#x5f0f;&#x306b;&#x5bfe;&#x5fdc;&#x3057;&#x3066;&#x3044;&#x308b;&#x30a2;&#x30d7;&#x30ea;&#x30b1;&#x30fc;&#x30b7;&#x30e7;&#x30f3;&#x306b;&#x8cbc;&#x308a;&#x4ed8;&#x3051;&#x308b;&#x3053;&#x3068;&#x304c;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;&#x66f8;&#x5f0f;&#x3084;&#x30ea;&#x30f3;&#x30af;&#x3082;&#x8cbc;&#x308a;&#x4ed8;&#x3051;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_35432713" LINK="mailto:info@freemind.asia" MODIFIED="1282617247859" TEXT="&#x30e1;&#x30fc;&#x30eb;&#x30ea;&#x30f3;&#x30af;(mailto:info@freemind.asia)&#x3092;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3059;&#x308b;&#x3068;&#x3001;Outlook&#x307e;&#x305f;&#x306f;&#x4ed6;&#x306e;&#x30e1;&#x30fc;&#x30e9;&#x30fc;&#x304c;&#x8d77;&#x52d5;&#x3057;&#x3066;&#x65b0;&#x898f;&#x30e1;&#x30c3;&#x30bb;&#x30fc;&#x30b8;&#x306e;&#x4f5c;&#x6210;&#x753b;&#x9762;&#x304c;&#x958b;&#x304d;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1306963971" LINK="mailto:info@freemind.asia?subject=FreeMind&#x4f7f;&#x304a;&#x3046;&#x4f1a;&#x3078;&#x306e;&#x554f;&#x3044;&#x5408;&#x308f;&#x305b;" MODIFIED="1282617242609">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12513;&#12540;&#12523;&#12522;&#12531;&#12463;&#12395;&#20214;&#21517;&#12434;&#21547;&#12417;&#12427;&#12371;&#12392;&#12418;&#12391;&#12365;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_850712799" MODIFIED="1282617476953" TEXT="&#x30de;&#x30a4;&#x30f3;&#x30c9;&#x30de;&#x30c3;&#x30d7;&#x3092;Microsoft Word&#x306b;&#x8cbc;&#x308a;&#x4ed8;&#x3051;&#x308b;&#x5225;&#x306e;&#x65b9;&#x6cd5;&#x3068;&#x3057;&#x3066;&#x306f;&#x3001;&#x524d;&#x8ff0;&#x306e;&#x901a;&#x308a;HTML&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3057;&#x3066;HTML&#x3092;&#x30b3;&#x30d4;&#x30fc;&#x3057;&#x3066;Word&#x306b;&#x8cbc;&#x308a;&#x4ed8;&#x3051;&#x308b;&#x3068;&#x3044;&#x3046;&#x624b;&#x3082;&#x3042;&#x308a;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_927584970" MODIFIED="1286966621687" POSITION="right" TEXT="&#x74b0;&#x5883;&#x8a2d;&#x5b9a;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_597376506" MODIFIED="1282617595671" TEXT="&#x74b0;&#x5883;&#x8a2d;&#x5b9a;&#x3092;&#x7de8;&#x96c6;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30c4;&#x30fc;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x74b0;&#x5883;&#x8a2d;&#x5b9a;&#x300d;&#x3002;&#x307b;&#x3068;&#x3093;&#x3069;&#x306e;&#x5909;&#x66f4;&#x306f;&#x3001;FreeMind&#x518d;&#x8d77;&#x52d5;&#x5f8c;&#x306b;&#x6709;&#x52b9;&#x306b;&#x306a;&#x308a;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_181846530" MODIFIED="1282617781015" TEXT="&#x74b0;&#x5883;&#x8a2d;&#x5b9a;&#x3067;&#x306f;&#x3001;&#x30ad;&#x30fc;&#x30dc;&#x30fc;&#x30c9;&#x306e;&#x30ad;&#x30fc;&#x8a2d;&#x5b9a;&#x3001;HTML&#x306e;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x6642;&#x306e;&#x52d5;&#x4f5c;&#x8a2d;&#x5b9a;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x9078;&#x629e;&#x6642;&#x306e;&#x30de;&#x30a6;&#x30b9;&#x64cd;&#x4f5c;&#x8a2d;&#x5b9a;&#x3001;&#x30a2;&#x30f3;&#x30c1;&#x30a8;&#x30a4;&#x30ea;&#x30a2;&#x30b9;&#x306e;&#x9078;&#x629e;&#x306a;&#x3069;&#x304c;&#x8a2d;&#x5b9a;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;"/>
<node COLOR="#999999" CREATED="1124560950732" ID="ID_325684894" MODIFIED="1282617800875" TEXT="&#x30ad;&#x30fc;&#x30ef;&#x30fc;&#x30c9;: &#x30ab;&#x30b9;&#x30bf;&#x30de;&#x30a4;&#x30ba;">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_68493179" MODIFIED="1286966621687" POSITION="right" TEXT="&#x5370;&#x5237;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1731127882" MODIFIED="1286958069921" TEXT="&#x30de;&#x30c3;&#x30d7;&#x5168;&#x4f53;&#x3092;1&#x30da;&#x30fc;&#x30b8;&#x306b;&#x53ce;&#x3081;&#x3066;&#x3082;&#x3001;&#x30de;&#x30c3;&#x30d7;&#x3092;&#x4f55;&#x679a;&#x304b;&#x306b;&#x5206;&#x3051;&#x3066;&#x3082;&#x3001;&#x3069;&#x3061;&#x3089;&#x3067;&#x3082;&#x5370;&#x5237;&#x3059;&#x308b;&#x3053;&#x3068;&#x304c;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;&#x3053;&#x306e;&#x9078;&#x629e;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30da;&#x30fc;&#x30b8;&#x8a2d;&#x5b9a;&#x300d;&#x3067;&#x884c;&#x3044;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_691550093" MODIFIED="1286958210109" TEXT="&#x30b9;&#x30da;&#x30fc;&#x30b9;&#x3092;&#x6709;&#x52b9;&#x5229;&#x7528;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x30de;&#x30c3;&#x30d7;&#x306b;&#x5fdc;&#x3058;&#x3066;&#x300c;&#x30da;&#x30fc;&#x30b8;&#x8a2d;&#x5b9a;&#x300d;&#x3067;&#x300c;&#x5370;&#x5237;&#x306e;&#x5411;&#x304d;&#x300d;&#x3092;&#x5408;&#x308f;&#x305b;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1324338159" MODIFIED="1286958245406" TEXT="&#x5370;&#x5237;&#x306e;&#x524d;&#x306b;&#x30d7;&#x30ec;&#x30d3;&#x30e5;&#x30fc;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x5370;&#x5237;&#x30d7;&#x30ec;&#x30d3;&#x30e5;&#x30fc;&#x300d;&#x3002;"/>
<node CREATED="1226522472728" ID="ID_1400892105" MODIFIED="1286958483125" TEXT="(&#x6539;&#x5584;&#x306e;&#x4f59;&#x5730;&#x304c;&#x6b8b;&#x308b;)FreeMind&#x306e;&#x5370;&#x5237;&#x6a5f;&#x80fd;&#x304c;&#x6c17;&#x306b;&#x5165;&#x3089;&#x306a;&#x3044;&#x65b9;&#x306f;&#x3001;&#x300c;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x300d;&#x304b;&#x3089;&#x300c;PDF&#x300d;&#x3092;&#x9078;&#x3093;&#x3067;&#x3001;PDF&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x3092;&#x751f;&#x6210;&#x3057;&#x3066;&#x5370;&#x5237;&#x3059;&#x308b;&#x3053;&#x3068;&#x3082;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1039008700" MODIFIED="1286958760500" TEXT="&#x30de;&#x30c3;&#x30d7;&#x3092;HTML&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3057;&#x3066;&#x30d6;&#x30e9;&#x30a6;&#x30b6;&#x304b;&#x3089;&#x5370;&#x5237;&#x3057;&#x305f;&#x308a;&#x3001;&#x30de;&#x30c3;&#x30d7;&#x3092;&#x30b3;&#x30d4;&#x30fc;&#xff06;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3057;&#x3066;Word&#x3084;&#x30ef;&#x30fc;&#x30c9;&#x30d1;&#x30c3;&#x30c9;&#x304b;&#x3089;&#x5370;&#x5237;&#x3057;&#x305f;&#x308a;&#x3059;&#x308b;&#x3053;&#x3068;&#x3082;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;&#x307e;&#x305f;&#x3001;&#x30de;&#x30c3;&#x30d7;&#x3092;HTML&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3057;&#x3066;&#x304b;&#x3089;&#x3001;&#x305d;&#x308c;&#x3092;Word&#x3084;&#x30ef;&#x30fc;&#x30c9;&#x30d1;&#x30c3;&#x30c9;&#x306b;&#x30b3;&#x30d4;&#x30fc;&#xff06;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3057;&#x3066;&#x5370;&#x5237;&#x3059;&#x308b;&#x3053;&#x3068;&#x3082;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;&#x305d;&#x306e;&#x5834;&#x5408;&#x3001;&#x304a;&#x597d;&#x307f;&#x3067;&#x30b9;&#x30bf;&#x30a4;&#x30eb;&#x3092;&#x5909;&#x66f4;&#x3059;&#x308b;&#x3053;&#x3068;&#x304c;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_1546970099" MODIFIED="1286970391453" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      HTML&#12395;&#12424;&#12427;&#12494;&#12540;&#12489;&#20869;&#12398;
    </p>
    <p>
      &#12522;&#12483;&#12481;&#12486;&#12461;&#12473;&#12488;&#21033;&#29992;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1551988593" MODIFIED="1286959088515">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12489;&#12399;&quot;SimplyHTML&quot;&#12392;&#12356;&#12358;&#12522;&#12483;&#12481;&#12486;&#12461;&#12473;&#12488;&#12456;&#12487;&#12451;&#12479;&#12391;&#12522;&#12483;&#12481;&#12486;&#12461;&#12473;&#12488;&#12395;&#12377;&#12427;&#12371;&#12392;&#12364;&#12391;&#12365;&#12414;&#12377;&#12290;&#12300;&#12494;&#12540;&#12489;&#12398;&#38263;&#25991;&#32232;&#38598;&#12301;&#30011;&#38754;&#12395;&#12484;&#12540;&#12523;&#12496;&#12540;&#12364;&#34920;&#12428;&#12394;&#12356;&#22580;&#21512;&#12399;&#12289;&#12300;&#12494;&#12540;&#12489;&#12398;&#38263;&#25991;&#32232;&#38598;&#12301;&#30011;&#38754;&#12434;&#38281;&#12376;&#12390;&#12363;&#12425;&#12289;&#12494;&#12540;&#12489;&#12434;&#36984;&#25246;&#12375;&#12390;&#12289;&#12300;&#26360;&#24335;&#12301;&#12513;&#12491;&#12517;&#12540;&#12398;&#12300;&#12522;&#12483;&#12481;&#12486;&#12461;&#12473;&#12488;&#12434;&#20351;&#29992;&#12301;&#12434;&#36984;&#25246;&#12375;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1747393077" MODIFIED="1286959325343">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <h3>
      HTML &#35352;&#36848;&#20363;
    </h3>
    <p class="msonormal">
      &#12450;&#12452;&#12486;&#12512;&#12434;&#31623;&#26465;&#26360;&#12365;&#12395;&#12377;&#12427;&#12371;&#12392;&#12364;&#12391;&#12365;&#12414;&#12377;:
    </p>
    <ul type="disc">
      <li class="msonormal">
        &#38917;&#30446;1
      </li>
      <li class="msonormal">
        &#38917;&#30446;2
      </li>
    </ul>
    <p class="msonormal">
      <b>&#22826;&#23383;</b>&#12420;<i>&#26012;&#20307;</i>&#12395;&#12377;&#12427;&#12371;&#12392;&#12418;&#12391;&#12365;&#12414;&#12377;&#12290;&#160; <u>&#19979;&#32218;</u>&#12420;<strike>&#21462;&#12426;&#28040;&#12375;&#32218;</strike>&#12395;&#12377;&#12427;&#12371;&#12392;&#12418;&#12391;&#12365;&#12414;&#12377;&#12290;&#12414;&#12383;&#12289;&#34920;&#12418;&#20316;&#12428;&#12414;&#12377;:
    </p>
    <table cellspacing="0" style="border: none" border="1" class="msonormaltable" cellpadding="0">
      <tr>
        <td style="padding-right: .75pt; border: solid windowtext 1.0pt; padding-top: .75pt; padding-left: .75pt; padding-bottom: .75pt">
          <p class="msonormal">
            &#12475;&#12523;1
          </p>
        </td>
        <td style="padding-right: .75pt; border: solid windowtext 1.0pt; padding-top: .75pt; border-left: none; padding-left: .75pt; padding-bottom: .75pt">
          <p class="msonormal">
            &#12475;&#12523;2
          </p>
        </td>
      </tr>
      <tr>
        <td style="padding-right: .75pt; border: solid windowtext 1.0pt; border-top: none; padding-top: .75pt; padding-left: .75pt; padding-bottom: .75pt">
          <p class="msonormal">
            &#12475;&#12523;3
          </p>
        </td>
        <td style="border-bottom: solid windowtext 1.0pt; padding-right: .75pt; border-top: none; border-right: solid windowtext 1.0pt; padding-top: .75pt; border-left: none; padding-left: .75pt; padding-bottom: .75pt">
          <p class="msonormal">
            &#12475;&#12523;4.
          </p>
        </td>
      </tr>
    </table>
    <p class="msonormal">
      <font color="#999900">&#27096;&#12293;&#12394;</font><font color="#336600">&#25991;&#23383;&#12398;&#33394;</font>&#12434;&#12388;&#12369;&#12427;&#12371;&#12392;&#12418;&#12391;&#12365;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_993763126" MODIFIED="1286959483296" TEXT="&#x30c6;&#x30ad;&#x30b9;&#x30c8;&#x3084;RTF (Word, &#x30ef;&#x30fc;&#x30c9;&#x30d1;&#x30c3;&#x30c9;) &#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3059;&#x308b;&#x969b;&#x306b;&#x306f;&#x3001;HTML&#x30ce;&#x30fc;&#x30c9;&#x3084;&#x753b;&#x50cf;&#x306e;&#x5bfe;&#x5fdc;&#x306b;&#x5236;&#x9650;&#x304c;&#x3042;&#x308a;&#x307e;&#x3059;&#x3002;&#x305f;&#x3060;&#x3057;&#x3001;HTML&#x306e;&#x4f7f;&#x7528;&#x306f;&#x3001;FreeMind&#x30a2;&#x30d7;&#x30ec;&#x30c3;&#x30c8;&#x3092;&#x4f7f;&#x3063;&#x3066;&#x30a6;&#x30a7;&#x30d6;&#x30b5;&#x30a4;&#x30c8;&#x306b;&#x516c;&#x958b;&#x3059;&#x308b;&#x306b;&#x306f;&#x4fbf;&#x5229;&#x3067;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_608769551" MODIFIED="1286966621703" POSITION="right" TEXT="&#x30ce;&#x30fc;&#x30c9;&#x5185;&#x306e;&#x753b;&#x50cf;&#x306e;&#x5229;&#x7528;">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1421453503" MODIFIED="1286959574296">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind&#12398;&#30011;&#20687;&#27231;&#33021;&#12399;&#12289;&#12414;&#12384;&#28310;&#20633;&#27573;&#38542;&#12398;&#27231;&#33021;&#12391;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1246862074332" ID="ID_334627796" MODIFIED="1286959731953" TEXT="FreeMind&#x306b;&#x753b;&#x50cf;&#x3092;&#x633f;&#x5165;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001; Alt + K &#x3092;&#x62bc;&#x3059;&#x304b;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x53f3;&#x30af;&#x30ea;&#x30c3;&#x30af;&#x3057;&#x3066;&#x300c;&#x633f;&#x5165;&#x300d;&#x306e;&#x300c;&#x753b;&#x50cf;&#x300d;&#x3092;&#x9078;&#x3073;&#x307e;&#x3059;&#x3002;&#x305f;&#x3060;&#x3057;&#x3001;&#x753b;&#x50cf;&#x3092;&#x633f;&#x5165;&#x3059;&#x308b;&#x3068;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x5185;&#x306e;&#x6587;&#x5b57;&#x304c;&#x753b;&#x50cf;&#x3067;&#x4e0a;&#x66f8;&#x304d;&#x3055;&#x308c;&#x307e;&#x3059;&#x3002;"/>
<node CREATED="1246862103719" FOLDED="true" ID="ID_612793700" MODIFIED="1286966621687" TEXT="&#x5236;&#x9650;: ">
<node CREATED="1246862113482" ID="ID_1655437401" MODIFIED="1286960013687" TEXT="&#x3053;&#x306e;&#x65b9;&#x6cd5;&#x3067;&#x633f;&#x5165;&#x3057;&#x305f;&#x753b;&#x50cf;&#x306f;&#x3001;FreeMind&#x304b;&#x3089;&#x4ed6;&#x306e;&#x30bd;&#x30d5;&#x30c8;&#x306b;&#x30da;&#x30fc;&#x30b9;&#x30c8;&#x3057;&#x305f;&#x308a;&#x3001;HTML&#x306b;&#x30a8;&#x30af;&#x30b9;&#x30dd;&#x30fc;&#x30c8;&#x3057;&#x305f;&#x308a;&#x3057;&#x3066;&#x3082;&#x3001;&#x6b63;&#x3057;&#x304f;&#x53cd;&#x6620;&#x3055;&#x308c;&#x307e;&#x305b;&#x3093;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1886768544" MODIFIED="1286960057546" TEXT="&#x5bfe;&#x5fdc;&#x3059;&#x308b;&#x753b;&#x50cf;&#x5f62;&#x5f0f;&#x306f;&#x3001;PNG, JPEG, GIF&#x306e;3&#x7a2e;&#x985e;&#x3067;&#x3059;&#x3002;&#xa;"/>
</node>
<node CREATED="1124560950732" ID="ID_891536599" MODIFIED="1286960355890" TEXT="&#x753b;&#x50cf;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x3078;&#x306e;&#x30ea;&#x30f3;&#x30af;&#x3092;&#x753b;&#x50cf;&#x8868;&#x793a;&#x306b;&#x5909;&#x3048;&#x308b;&#x306b;&#x306f;&#x3001;Alt + K &#x3092;&#x4f7f;&#x3044;&#x307e;&#x3059;&#x3002;&#x8907;&#x6570;&#x306e;&#x753b;&#x50cf;&#x3092;&#x633f;&#x5165;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x8907;&#x6570;&#x306e;&#x753b;&#x50cf;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x3092;FreeMind&#x306b;&#x30c9;&#x30e9;&#x30c3;&#x30b0;&#xff06;&#x30c9;&#x30ed;&#x30c3;&#x30d7;&#x3057;&#x3001;&#x305d;&#x3053;&#x3067;&#x3067;&#x304d;&#x305f;&#x8907;&#x6570;&#x306e;&#x30ce;&#x30fc;&#x30c9;&#x3092;&#x9078;&#x629e;&#x3057;&#x3066; Alt + K &#x3092;&#x4f7f;&#x3044;&#x307e;&#x3059;&#x3002;&#xa;"/>
<node COLOR="#000000" CREATED="1124560950732" ID="ID_183187570" MODIFIED="1286960578765" TEXT="&#x3055;&#x3089;&#x306b;&#x9ad8;&#x5ea6;&#x3067;&#x3042;&#x307e;&#x308a;&#x30e6;&#x30fc;&#x30b6;&#x30fc;&#x30d5;&#x30ec;&#x30f3;&#x30c9;&#x30ea;&#x30fc;&#x3067;&#x306f;&#x306a;&#x3044;&#x65b9;&#x6cd5;&#x3067;&#x3059;&#x304c;&#x3001;&#x30ce;&#x30fc;&#x30c9;&#x306b;HTML&#x30bf;&#x30b0;&#x3092;&#x542b;&#x3081;&#x308b;&#x3053;&#x3068;&#x3082;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;&#x30ce;&#x30fc;&#x30c9;&#x306e;&#x5185;&#x5bb9;&#x3092;&lt;html&gt;&#x30bf;&#x30b0;&#x3067;&#x66f8;&#x304d;&#x59cb;&#x3081;&#x308b;&#x3053;&#x3068;&#x304c;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;&#x3053;&#x306e;&#x65b9;&#x6cd5;&#x3067;&#x3082;&#x753b;&#x50cf;&#x3092;&#x633f;&#x5165;&#x3059;&#x308b;&#x3053;&#x3068;&#x304c;&#x3067;&#x304d;&#x307e;&#x3059;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1523337847" MODIFIED="1286960601875" TEXT="&#x8a18;&#x8ff0;&#x4f8b;  &lt;html&gt;&lt;img src=&quot;linked/Apple.png&quot;&gt;  &lt;html&gt;&lt;img src=&quot;file://C:/Users/My Documents/Mind Maps/Linked/Apple.png&quot;&gt;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1357493333" MODIFIED="1286960775343">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#30011;&#20687;&#12395;&#12399;&#30456;&#23550;&#12522;&#12531;&#12463;&#12434;&#20351;&#12358;&#12371;&#12392;&#12418;&#12391;&#12365;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="ID_538156267" MODIFIED="1286966621703" TEXT="Windows&#x304c;&#x63d0;&#x4f9b;&#x3059;&#x308b;&#x753b;&#x50cf;&#x306e;&#x4f7f;&#x7528;&#x4f8b;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;&#65289;&#30011;&#20687;&#12364;&#27491;&#24120;&#12395;&#34920;&#31034;&#12373;&#12428;&#12414;&#12379;&#12435;&#12290;&#21476;&#12356;&#12496;&#12540;&#12472;&#12519;&#12531;&#12398;Office&#12395;&#21547;&#12414;&#12428;&#12390;&#12356;&#12427;&#30011;&#20687;&#12408;&#12398;&#12497;&#12473;&#12364;&#25351;&#23450;&#12373;&#12428;&#12390;&#12356;&#12427;&#12424;&#12358;&#12391;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_961247449" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLENDS.GIF"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1303473008" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="ID_1503291611" MODIFIED="1286966621687">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACEXPDTN.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACINDSTR.GIF"/>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1124560950732" FOLDED="true" ID="ID_1268856967" MODIFIED="1286966621687">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" FOLDED="true" ID="ID_143068824" MODIFIED="1286966621687">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSNDSTN.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" ID="ID_1818699082" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSUMIPT.GIF"/>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1124560950732" ID="ID_1747452800" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" ID="ID_1077886632" LINK="file:/C:/Program%20Files/Microsoft%20Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_1862790957" MODIFIED="1286970391437" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20182;&#32773;&#12392;&#12398;&#21516;&#26178;&#32232;&#38598;&#26178;&#12398;
    </p>
    <p>
      &#12501;&#12449;&#12452;&#12523;&#12525;&#12483;&#12463;&#27231;&#33021;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1444414576" MODIFIED="1286961579359" TEXT="&#x6700;&#x65b0;&#x7248;&#x306e;FreeMind&#x306b;&#x306f;&#x8a66;&#x9a13;&#x7684;&#x306a;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x30ed;&#x30c3;&#x30af;&#x6a5f;&#x80fd;&#x304c;&#x3042;&#x308a;&#x307e;&#x3059;&#x3002;&#x30c7;&#x30d5;&#x30a9;&#x30eb;&#x30c8;&#x3067;&#x306f;&#x7121;&#x52b9;&#x306b;&#x306a;&#x3063;&#x3066;&#x3044;&#x307e;&#x3059;&#x3002;&#x73fe;&#x884c;&#x7248;&#x306f;&#x4ed6;&#x8005;&#x306b;&#x3088;&#x308b;&#x4e0a;&#x66f8;&#x304d;&#x3092;&#x56de;&#x907f;&#x3059;&#x308b;&#x6a5f;&#x80fd;&#x304c;&#x5b8c;&#x5168;&#x306b;&#x306f;&#x52d5;&#x4f5c;&#x3057;&#x307e;&#x305b;&#x3093;&#x304c;&#x3001;&#x5b9f;&#x969b;&#x306b;&#x306f;&#x307b;&#x307c;&#x554f;&#x984c;&#x3042;&#x308a;&#x307e;&#x305b;&#x3093;&#x3002;">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;&#65289;&#33258;&#20998;&#12364;&#32232;&#38598;&#12375;&#12390;&#12356;&#12427;&#12392;&#12365;&#12391;&#12418;&#12501;&#12449;&#12452;&#12523;&#12364;&#12525;&#12483;&#12463;&#12373;&#12428;&#12390;&#12375;&#12414;&#12358;&#12496;&#12464;&#12364;&#12354;&#12426;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" ID="ID_1178760745" MODIFIED="1286961512968" TEXT="&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x30ed;&#x30c3;&#x30af;&#x6a5f;&#x80fd;&#x306f;&#x3001;&#x4ed6;&#x8005;&#x304c;&#x8aa4;&#x3063;&#x3066;&#x4e0a;&#x66f8;&#x304d;&#x3059;&#x308b;&#x3053;&#x3068;&#x3092;&#x9632;&#x3050;&#x305f;&#x3081;&#x306b;&#x3001;&#x8907;&#x6570;&#x306e;&#x30e6;&#x30fc;&#x30b6;&#x30fc;&#x304c;&#x540c;&#x6642;&#x306b;&#x540c;&#x3058;&#x30de;&#x30c3;&#x30d7;&#x3092;&#x7de8;&#x96c6;&#x3067;&#x304d;&#x306a;&#x304f;&#x3059;&#x308b;&#x6a5f;&#x80fd;&#x3067;&#x3059;&#x3002;"/>
<node CREATED="1124560950732" ID="ID_1319486536" MODIFIED="1286961648421" TEXT="&#x8a66;&#x9a13;&#x7684;&#x30d5;&#x30a1;&#x30a4;&#x30eb;&#x30ed;&#x30c3;&#x30af;&#x3092;&#x6709;&#x52b9;&#x306b;&#x3059;&#x308b;&#x306b;&#x306f;&#x3001;&#x300c;&#x30c4;&#x30fc;&#x30eb;&#x300d;&#x30e1;&#x30cb;&#x30e5;&#x30fc;&#x306e;&#x300c;&#x74b0;&#x5883;&#x8a2d;&#x5b9a;&#x300d;&#x3092;&#x958b;&#x304d;&#x307e;&#x3059;&#x3002;"/>
</node>
<node COLOR="#407000" CREATED="1229414588553" FOLDED="true" ID="ID_465575513" MODIFIED="1286970391437" POSITION="right" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12496;&#12540;&#12472;&#12519;&#12531;0.9.0&#12398;&#26032;&#27231;&#33021;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;&#65289;Scripiting Support&#65288;&#12473;&#12463;&#12522;&#12503;&#12488;&#23550;&#24540;&#65289;&#12399;&#12289;Groovy&#12392;&#12356;&#12358;&#12473;&#12463;&#12522;&#12503;&#12488;&#35328;&#35486;&#12408;&#12398;&#23550;&#24540;&#12395;&#38306;&#12377;&#12427;&#35299;&#35500;&#12391;&#12377;&#12290;&#35379;&#32773;&#12399;Groovy&#12395;&#38306;&#12377;&#12427;&#29702;&#35299;&#12364;&#12394;&#12356;&#12383;&#12417;&#12289;&#26085;&#26412;&#35486;&#35379;&#12434;&#30465;&#12365;&#12414;&#12375;&#12383;&#12290;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201283648829" FOLDED="true" ID="ID_780619160" MODIFIED="1286966621703" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20027;&#12394;&#26032;&#27231;&#33021;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;&#65289;&#19968;&#37096;&#12398;&#12494;&#12540;&#12488;&#12399;&#35379;&#20986;&#12375;&#12390;&#12356;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201283660674" ID="ID_540290551" MODIFIED="1286962287484" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26032;&#12375;&#12356;&#12456;&#12487;&#12451;&#12479;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26032;&#12375;&#12356;&#12456;&#12487;&#12451;&#12479;&#12399;&#12494;&#12540;&#12489;&#12420;&#12494;&#12540;&#12488;(&#26528;&#12398;&#19979;&#12395;&#12354;&#12427;&#23567;&#12373;&#12394;&#12454;&#12451;&#12531;&#12489;&#12454;)&#12398;&#26360;&#24335;&#35373;&#23450;&#12395;&#23550;&#24540;&#12375;&#12414;&#12375;&#12383;&#12290;
    </p>
    <p>
      (X)HTML&#12391;&#12494;&#12540;&#12489;&#12398;&#20013;&#12395;&#35352;&#36848;&#12373;&#12428;&#12390;&#12356;&#12427;&#12383;&#12417;&#12289;&#38750;&#24120;&#12395;&#21177;&#26524;&#30340;&#12395;HTML&#12395;&#12456;&#12463;&#12473;&#12509;&#12540;&#12488;&#12377;&#12427;&#12371;&#12392;&#12364;&#12391;&#12365;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1201283806888" ID="ID_425787034" MODIFIED="1286962408093" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12488;&#12398;&#25913;&#33391;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12494;&#12540;&#12488;&#12364;&#12513;&#12452;&#12531;&#12454;&#12451;&#12531;&#12489;&#12454;&#12395;&#30452;&#25509;&#36899;&#21205;&#12377;&#12427;&#12424;&#12358;&#12395;&#12394;&#12426;&#12414;&#12375;&#12383;&#12290;&#12494;&#12540;&#12488;&#12454;&#12451;&#12531;&#12489;&#12454;&#12434;&#34920;&#31034;&#12375;&#12394;&#12356;&#22580;&#21512;&#12391;&#12418;&#12289;&#12484;&#12540;&#12523;&#12481;&#12483;&#12503;&#12391;&#20869;&#23481;&#12434;&#34920;&#31034;&#12375;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1201506800600" ID="ID_1300778251" MODIFIED="1286962448890" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12501;&#12451;&#12523;&#12479;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Using Filters the current mindmap can be reduced to nodes satisfying certain criteria. For example, if you only want to see every node containing &quot;TODO&quot;, then you have to press on the filter symbol (the funnel beside the zoom box), the filter toolbar appears, choose &quot;edit&quot; and add the condition that the node content contains &quot;TODO&quot;. Then select the filter in the filter toolbar. Now, only the filtered nodes and its ancestors are displayed unless you choose &quot;No filtering&quot; in the toolbar.
    </p>
    <p>
      Using the settings &quot;Show ancestors&quot; and &quot;Show descendants&quot; you can influence the apperance of the parent and child nodes that are connected with the nodes being filtered.
    </p>
    <p>
      There are many different criteria filters can be based on such as a set of selected nodes, a specific icon and some attributes.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1201506806036" ID="ID_382184941" MODIFIED="1286962453968" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23646;&#24615;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Attributes are additional meta information in the form of text pairs attached to nodes.
    </p>
    <p>
      Thus, criteria like Context-&gt;Home or Context-&gt;Job can be expressed. Later a filter limits the display only to certain contexts.
    </p>
    <p>
      Moreover, Groovy scripts are currently stored within attributes.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1201282217311" FOLDED="true" ID="ID_104517237" MODIFIED="1286966621703" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#34920;&#31034;&#19978;&#12398;&#22793;&#26356;&#28857;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201282224869" ID="ID_1892639005" MODIFIED="1286962837515" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12479;&#12502;&#34920;&#31034;&#23550;&#24540;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38283;&#12356;&#12390;&#12356;&#12427;&#12510;&#12483;&#12503;&#12364;&#19968;&#30446;&#12391;&#12431;&#12363;&#12427;&#12424;&#12358;&#12395;&#12394;&#12426;&#12414;&#12375;&#12383;&#12290;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1201282406968" ID="ID_619994674" MODIFIED="1286962744906" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12450;&#12452;&#12467;&#12531;&#12484;&#12540;&#12523;&#12496;&#12540;&#12398;&#12473;&#12463;&#12525;&#12540;&#12523;&#23550;&#24540;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1201282319118" FOLDED="true" ID="ID_1097927650" MODIFIED="1286966621703" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12518;&#12540;&#12470;&#12499;&#12522;&#12486;&#12451;&#12398;&#21521;&#19978;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35379;&#27880;&#65289;&#19968;&#37096;&#12398;&#12494;&#12540;&#12488;&#12399;&#35379;&#20986;&#12375;&#12390;&#12356;&#12414;&#12379;&#12435;&#12290;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201282325640" FOLDED="true" ID="ID_985773977" MODIFIED="1286966621703" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#19978;&#19979;&#24038;&#21491;&#12408;&#12398;&#31227;&#21205;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1201282465994" ID="ID_1451406366" MODIFIED="1286963093156">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#19978;&#19979;&#12398;&#30690;&#21360;&#12461;&#12540;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12371;&#12398;&#26041;&#21521;&#12398;&#30690;&#21360;&#12461;&#12540;&#12395;&#12424;&#12427;&#31227;&#21205;&#12399;&#12289;&#12377;&#12391;&#12395;FreeMind&#160; 0.8.0&#12391;&#23550;&#24540;&#12375;&#12390;&#12356;&#12414;&#12375;&#12383;&#12364;&#12289;&#12371;&#12398;&#12496;&#12540;&#12472;&#12519;&#12531;&#12363;&#12425;&#20840;&#26041;&#21521;&#12395;&#23550;&#24540;&#12375;&#12414;&#12375;&#12383;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1201282426565" FOLDED="true" ID="ID_1370145845" MODIFIED="1286966621703">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24038;&#21491;&#12398;&#30690;&#21360;&#12461;&#12540;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24038;&#21491;&#12398;&#30690;&#21360;&#12461;&#12540;&#12395;&#12424;&#12427;&#12494;&#12540;&#12489;&#12398;&#31227;&#21205;&#12395;&#23550;&#24540;&#12375;&#12414;&#12375;&#12383;&#12290;&#12523;&#12540;&#12488;&#12395;&#36817;&#12389;&#12369;&#12383;&#12426;&#12289;&#12354;&#12427;&#12494;&#12540;&#12489;&#12398;&#23376;&#12494;&#12540;&#12489;&#12395;&#31227;&#21205;&#12375;&#12383;&#12426;&#12377;&#12427;&#12371;&#12392;&#12364;&#12391;&#12365;&#12414;&#12377;&#12290;&#12414;&#12383;&#12289;&#12523;&#12540;&#12488;&#12434;&#12414;&#12383;&#12356;&#12391;&#24038;&#21491;&#12395;&#31227;&#21205;&#12377;&#12427;&#12371;&#12392;&#12418;&#12391;&#12365;&#12414;&#12377;&#12290;&#12371;&#12398;&#27231;&#33021;&#12395;&#12399;&#12289;[Ctrl]+[&#8592;]&#12362;&#12424;&#12403;[Ctrl]+[&#8594;]&#12434;&#20351;&#12356;&#12414;&#12377;&#12290;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1201282851749" ID="ID_52368938" MODIFIED="1286963161140">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12484;&#12522;&#12540;&#20869;&#12398;&#19978;&#19979;&#38542;&#23652;&#12398;&#31227;&#21205;&#12395;&#23550;&#24540;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1201282843249" ID="ID_956193813" MODIFIED="1286963176468">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12523;&#12540;&#12488;&#12494;&#12540;&#12489;&#12434;&#12414;&#12383;&#12368;&#31227;&#21205;&#12395;&#23550;&#24540;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1201282332144" ID="ID_456774299" MODIFIED="1286963929468" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12513;&#12491;&#12517;&#12540;&#38917;&#30446;&#12395;&#35226;&#12360;&#12420;&#12377;&#12356;&#12450;&#12452;&#12467;&#12531;&#12434;&#34920;&#31034;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1202399993070" ID="ID_783332471" MODIFIED="1286963859093" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26360;&#24335;&#22793;&#26356;&#12364;1&#22238;&#12398;&#12480;&#12452;&#12450;&#12525;&#12464;&#12391;&#21487;&#33021;&#12395;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1202400125364" ID="ID_1886224657" MODIFIED="1286964084203" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26032;&#12375;&#12356;&#12497;&#12479;&#12540;&#12531;&#12456;&#12487;&#12451;&#12479;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Patterns are very useful helpers to get a consistent layout of your map. You can perform various format changes with one keystroke.
    </p>
    <p>
      The pattern editor is opened using F11 and presents all currently defined patterns.
    </p>
    <p>
      The following basic actions are available:
    </p>
    <ul>
      <li>
        You can move the pattern(s) up&amp;down using drag and drop.
      </li>
      <li>
        You can add a new pattern via the action menu.
      </li>
      <li>
        You can create a pattern from the selected nodes. If only one node is selected, its format changes in comparison to an unformatted node build a new pattern. If you have selected several nodes, the format changes that are common to all selected nodes are gathered in a new pattern. For example, if you have a bold node with yellow background and an italic node with the same background color, the newly created pattern would consist of the yellow background change.
      </li>
      <li>
        You can apply patterns to the currently selected nodes and finally,
      </li>
      <li>
        you can remove patterns.
      </li>
    </ul>
    <p>
      The patterns are stored in the patterns.xml file in your &lt;user directory&gt;/.freemind/ directory and are reloaded the next time you use freemind. The patterns are not part of the maps.
    </p>
    <p>
      Inside the patterns, there is a left and right hand side. On the right hand side, the format changes are displayed. On the left side there is a plus or minus or empty box. They mean the following:
    </p>
    <ul>
      <li>
        Plus: indicates that the format on the left is applied.
      </li>
      <li>
        Minus: forces the corresponding format to be reverted to the standard value.
      </li>
      <li>
        Empty: No change.
      </li>
    </ul>
    <p>
      A novelity is the possibility to associate a script to a pattern. Thus, patterns can now change much more than the pure format changes. For example, you can put macros inside the patterns that change the selected or more nodes at once. This functionality can't be overestimated as it opens complete new automatism capabilities to FreeMind.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1203059325942" ID="ID_44398902" MODIFIED="1286964084390" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33258;&#21205;&#12524;&#12452;&#12450;&#12454;&#12488;&#12364;&#12459;&#12473;&#12479;&#12510;&#12452;&#12474;&#21487;&#33021;&#12395;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Inside the preferences there is the possibility to change the layout of the automatic layout functionality.
    </p>
    <p>
      Thus, you can change the color and appearance of each level. For example, the used color green is difficult to be read with a beamer. Now, you can change the color to dark green.
    </p>
    <p>
      Observe, that changes to the specification doesn't change the layout of the map directly. You have to close and reopen the map, first.
    </p>
    <p>
      Currently, these format specifications are stored in the preferences of the current user and not inside the map. Thus, on a different system, the automatic layout of a map may look different. This will be changed in the next release of FreeMind.
    </p>
    <p>
      For advanced users it is even possible to change the number of levels. Change something in the preferences of the automatic layout. Now, the format specification is stored in the user preferences. Open the file &lt;user_directory&gt;/.freemind/auto.properties and search for the line automaticLayout_level, and duplicate the last &lt;pattern name=...&gt;...&lt;/pattern&gt; entry. Now, you have one level more.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1202400209358" ID="ID_1567192362" MODIFIED="1286964084500" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26908;&#32034;&#12392;&#32622;&#25563;&#12395;&#12480;&#12452;&#12450;&#12525;&#12464;&#34920;&#31034;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      A new search and replace dialog enables to quickly search for text fragments and to replace them.
    </p>
    <p>
      Its functionality includes
    </p>
    <ul>
      <li>
        Find as you type: when you start to specify your search text, it starts to reduce the amount of displayed nodes. It searches for the text inside the nodes text only (attached notes are currently not searched).
      </li>
      <li>
        Sortable node list: the main table is sortable by each criterion. Even by Icon. Thus, it is easy to find all nodes with attached note for example. Or to sort them by creation date to get the latest changes to the map!
      </li>
      <li>
        Cursor support: moving down moves from the search field to the replace field and then into the list.
      </li>
      <li>
        Node Path display: if you select a line, its path from the root of the map is displayed below.
      </li>
      <li>
        Direct access: if you press enter inside the table, the mind map displays the selected node (menu item &quot;select&quot; and &quot;select and close&quot;).
      </li>
      <li>
        Replace: it is possible to replace all occurences or only the nodes belonging to the selected lines.
      </li>
      <li>
        Export: new striking possibility. Select some nodes and export them to a new mindmap. This makes it easy to generate a todo list from a hierachical mind map. For example, if you mark every todo item with the bell sign, then simply sort this list by icon and mark those containing the bell. Then press &quot;export&quot; and you get all these nodes as single nodes in a new map.
      </li>
    </ul>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1208893265045" ID="ID_605044144" MODIFIED="1286964100984" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#12450;&#12452;&#12467;&#12531;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font face="Serif">Some key strokes makes the handling of icons even more easier. If you hold the SHIFT key while pressing on an icon on the left toolbar, all other icons are removed and this icon is the only one after the action. This is for example useful for changing the priority of a node. </font>
    </p>
    <p>
      <font face="Serif">Another feature comes with pressing CTRL while choosing an icon. It causes this type of icon to be removed one by one. Suppose you have a node with the icons (1)(2)(1)(3) and you press CTRL-1 you get (1)(2)(3). This is useful as with the normal remove methods, only the last icon can be removed.</font>
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1201282939150" FOLDED="true" ID="ID_1258317535" MODIFIED="1286966621703" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26032;&#12383;&#12394;&#12456;&#12463;&#12473;&#12509;&#12540;&#12488;&#24418;&#24335;
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201282945124" ID="ID_257177419" MODIFIED="1286964135234" STYLE="fork">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Flash&#12392;Java&#12473;&#12463;&#12522;&#12503;&#12488;&#12395;&#23550;&#24540;
    </p>
  </body>
</html></richcontent>
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Flash and Java applet export can be used to bring mindmaps into the internet.
    </p>
    <p>
      The difference between the two is, that the Java applet looks exactly like the map on the screen, but needs longer to be loaded.
    </p>
    <p>
      The flash application is very fast and has some different features built in. But it has a different look and feel.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1201506466515" FOLDED="true" ID="ID_1053295685" MODIFIED="1286966621703" STYLE="fork" TEXT="Scripting Support">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FreeMind can now be scripted by using Groovy scripts. Groovy is a very easy to use scripting language best integrating into FreeMind.
    </p>
    <p>
      There are two possibilities to use scripts:
    </p>
    <ol>
      <li>
        Choose the script editor to easily add, change and test your scripts. Technically, scripts are attached to a node via an attribute starting with &quot;script&quot; (like &quot;script1&quot;) that contains the script. Every time you choose &quot;Evaluate&quot; from the tools menu, all scripts attached to nodes are executed.
      </li>
      <li>
        Create or change a pattern and press the script button. The script editor appears and your script will be associated to a pattern. Every time you apply the pattern to some nodes, the script is executed for that nodes automatically. Thus, you can have the scripts with keyboard shortcuts as the patterns are accessible via shortcuts.
      </li>
    </ol>
    <p>
      Every script is at evaluation time started with two predefined java objects coming from the map:
    </p>
    <ul>
      <li>
        node is the current node. It is a freemind.modes.MindMapNode. This node can be used to retrieve information about the contents, its children or its formatting. <i>Don't use the setter to change the node. Use the following instead:</i>
      </li>
      <li>
        c is the current controller. It is a freemind.modes.mindmapmode.MindMapController. This controller <b>should</b>&#160; &#160;&#160;&#160;be used to change information. For example, if you want to change the nodes text or if you want to add children. The methods that can be used are sumarized in freemind.modes.mindmapmode.actions.MindMapActions.
      </li>
    </ul>
    <p>
      There are two automatisms regarding the effect of a script:
    </p>
    <ol>
      <li>
        If a script starts with &quot;=&quot;, the result of the script is taken to be the new nodes text. Example script1: =17+4. If executed, the node the script is associated to will be changed to 21.
      </li>
      <li>
        If a script starts with letters (digits and '_') only and then a &quot;=&quot; sign, like &quot;sum=17+4&quot;, the result is taken to be a (possibly new) attribute named &quot;sum&quot; in this case with the content 21.
      </li>
    </ol>
    <p>
      For more examples consult our little scripting guide below or our web pages.
    </p>
    <p>
      A last word on security: before scripts is evaluated for the first time in FreeMind, the user is asked whether or not he allows it. The answer can be stored for every script but observe that a malicious script is able to perform every action on your computer that your users rights allow up to delete all files or send them to pirates.ru. This said, be careful and don't allow scripts when you don't know that the author is trusted. Finally, scripts are never evaluated automatically in FreeMind for these reasons. Thus, you can open a map without problems and have a look at the scripts it contains.
    </p>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#407000" CREATED="1201506580407" ID="ID_609352872" MODIFIED="1229414646108" STYLE="fork" TEXT="Little FreeMind Scripting Guide">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      If your scripts want to change some map data (which they commonly want to) they should rely on the methods provided by the MindMapController c.
    </p>
    <p>
      These methods are summarized and partially documented in the class &quot;MindMapActions&quot;:
    </p>
    <p>
      <a href="http://freemind.cvs.sourceforge.net/freemind/freemind/freemind/modes/mindmapmode/actions/MindMapActions.java?view=log&amp;pathrev=fm_060405_integration">http://freemind.cvs.sourceforge.net/freemind/freemind/freemind/modes/mindmapmode/actions/MindMapActions.java?view=log&amp;pathrev=fm_060405_integration</a>
    </p>
    <p>
      The listeners mentioned below (ie. NodeSelectionListener and NodeLifetimeListener) can be registered and found in the class &quot;ModeController&quot; (also c):
    </p>
    <p>
      <a href="http://freemind.cvs.sourceforge.net/freemind/freemind/freemind/modes/ModeController.java?view=log&amp;pathrev=fm_060405_integration">http://freemind.cvs.sourceforge.net/freemind/freemind/freemind/modes/ModeController.java?view=log&amp;pathrev=fm_060405_integration</a>
    </p>
    <p>
      Here we present some snippets of useful Groovy code that can be used as parts of your scripts. More scripts can be found on our web sites.
    </p>
    <ul>
      <li>
        Change the node text:<br />=17+4<br />(Explanation: if a script starts with &quot;=&quot;, the result of the script is taken as the new nodes text.)
      </li>
      <li>
        Change an attributes value:<br />attribute_name=17+4<br />(Explanation: if a script starts with a name and then directly a &quot;=&quot; sign, its result is associated to this attribute which is created if not already present.)
      </li>
      <li>
        Read and change the nodes text:<br />c.setNodeText(node, node.getText() + &quot;_CHANGED&quot;);
      </li>
      <li>
        Read an attribute<br />def value = node.getAttribute(&quot;key&quot;); // value is of type String.<br /><br />
      </li>
      <li>
        Create or change attributes: the following method checks whether or not an attribute with the same key exists and replaces it. Otherwise a new attribute is created and added.<br />c.editAttribute(node, &quot;key&quot;, &quot;new value&quot;);<br />
      </li>
      <li>
        Remove an attribute by name:<br />c.editAttribute(node, &quot;key&quot;, null);<br />This method returns the former index of the attribute, or -1 if the key wasn't found.<br />
      </li>
      <li>
        Traverse all children<br />def it = node.childrenUnfolded();<br />while(it.hasNext()) {<br />def child = it.next();<br />}
      </li>
      <li>
        Traverse all children and its children recursively. The following examples prints the content of every node including its childs<br />

        <pre>def stack = new java.util.Stack();<br />stack.push(node);<br />while(stack.size()&gt;0) 
        {<br />		def current =stack.pop();<br />		print current.getShortText(c) + &quot;, &quot;;<br />		stack.addAll(current.getChildren());<br />	}</pre>
        <br />
        <br />
        
      </li>
      <li>
        Real world example: nodes may have an attribute &quot;work&quot; that specifies the work needed for the specific work package (e.g. in days). This script computes the sum of all work packages such that each node gets an attribute &quot;sum&quot; containing the amount of work needed for all descendants. This script, if executed via Alt+F8, automatically applies to the root of the map. But, every time, you change the values, you have to reexecute this script.<br /><br />

        <pre>def calcWork(child) {
	def sum = 0;
	def it = child.childrenUnfolded(); 
	while(it.hasNext()) { 
		def child2 = it.next(); 
		sum += calcWork(child2);
		def w = child2.getAttribute(&quot;work&quot;);
		if(w != null)
			sum += Integer.parseInt( w);
	}
	if(sum&gt;0)
		c.editAttribute(child, &quot;sum&quot;, (String) sum);
	return sum;
}

calcWork(c.getRootNode());</pre>
      </li>
      <li>
        A very advanced example: the last script is integrated into a listener that detects node changes, so the sums are always recreated when a node is changed. This script introduces a new element in scripting: the &quot;cookies&quot;. It is a usual HashMap where scripts can store values that they need the next time, they are executed. For every map, there is a new cookie map, such that cookies are map local. Moreover, they are not stored persistently and are lost after termination of FreeMind or after closing a map. In this example, they serve as a static variable in which it is stored whether or not the script was already executed and which listener was used in order to deregister the old one first.<br />

        <pre>class MyNodeListener implements freemind.modes.ModeController.NodeSelectionListener {
	freemind.modes.mindmapmode.MindMapController c;
        MyNodeListener(freemind.modes.mindmapmode.MindMapController con) {
		this.c = con;
		}

		/** 
         * Sent, if a node is changed
         * */
        void onUpdateNodeHook(freemind.modes.MindMapNode node){		
			calcWork(c.getRootNode());
		};

        /** Is sent when a node is selected.
         */
        void onSelectHook(freemind.view.mindmapview.NodeView node){};
        /**
         * Is sent when a node is deselected.
         */
        void onDeselectHook(freemind.view.mindmapview.NodeView node){};

		/**
		 * Is issued before a node is saved (eg. to save its notes, too, even if the notes is currently edited).
		 */
		void onSaveNode(freemind.modes.MindMapNode node){};

def calcWork(child) {
	def sum = 0;
	def it = child.childrenUnfolded(); 
	while(it.hasNext()) { 
		def child2 = it.next(); 
		sum += calcWork(child2);
		def w = child2.getAttribute(&quot;work&quot;);
		if(w != null)
			sum += Integer.parseInt( w);
	}
	if(sum&gt;0)
		c.editAttribute(child, &quot;sum&quot;, (String) sum);
	return sum;
}

}

def cookieKey = &quot;work_update_listener&quot;;
if(cookies.get(cookieKey) != null) {
	c.deregisterNodeSelectionListener(cookies.get(cookieKey));
}
def newListener = new MyNodeListener(c);
cookies.put(cookieKey, newListener);
c.registerNodeSelectionListener(newListener);
      </pre>
      </li>
      <li>
        A sorting example: Currently we provide a function that sorts all children by name, but if you want to sort them by their icons for example, you can use the following script (or change it, if you have different sorting criteria):<br />

        <pre>import java.awt.datatransfer.Transferable;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Vector;
import freemind.modes.MindMapNode;

	class IconComparator implements java.util.Comparator {
			int compare(java.lang.Object pArg0, java.lang.Object pArg1) {
				if (pArg0 instanceof MindMapNode) {
					MindMapNode node1 = (MindMapNode) pArg0;
					if (pArg1 instanceof MindMapNode) {
						MindMapNode node2 = (MindMapNode) pArg1;
						String iconText1 = getIconText(node1);
						String iconText2 = getIconText(node2);
						//print &quot;comparing&quot; + iconText1 + &quot; with &quot; + iconText2 + &quot;\n&quot;;
						return iconText1.compareToIgnoreCase(iconText2);
					}
				}
				return 0;
			}
		def getIconText(MindMapNode n) {
			if(n.getIcons() == null || n.getIcons().size()==0) 
				return &quot;&quot;;
			def retString = &quot;&quot;;
			def it = n.getIcons().iterator();
			while(it.hasNext()) {
				retString +=it.next().getName()+&quot;, &quot;;
			}
			return retString;
		}
	}


		// we want to sort the children of the node:
	 	Vector children = new Vector();
		// put in all children of the node
		children.addAll(node.getChildren());
		// sort them
		java.util.Collections.sort(children, new IconComparator());
		//print &quot;The set has &quot; + children.size() + &quot; entries\n&quot;;
		// now, as it is sorted. we cut the children
		def it2 = children.iterator();
		while (it2.hasNext()) {
			MindMapNode child = (MindMapNode) it2.next();
			Vector childList = new Vector();
			childList.add(child);
			Transferable cut = c.cut(childList);
			// paste directly again causes that the node is added as the last one.
			c.paste(cut, node);
		}
		c.select(c.getNodeView(node));</pre>
      </li>
      <li>
        A presentation script. Everytime you select a node, all other nodes are closed and this node is expanded by one. Just give it a try..<br />

        <pre>class MyNodeListener implements freemind.modes.ModeController.NodeSelectionListener {
	freemind.modes.mindmapmode.MindMapController c;
        MyNodeListener(freemind.modes.mindmapmode.MindMapController con) {
		this.c = con;
		}

		/** 
         * Sent, if a node is changed
         * */
        void onUpdateNodeHook(freemind.modes.MindMapNode node){		
		};

        /** Is sent when a node is selected.
         */
        void onSelectHook(freemind.view.mindmapview.NodeView node){
			if(c.getSelecteds().size()&gt;1)
				return;
			// unfold node:
			c.setFolded(node.getModel(), false);
			// fold every child:
                def it2 = node.getModel().childrenUnfolded().iterator();
                while (it2.hasNext()) {
                        def child = it2.next();
				  c.setFolded(child, true);
			}
			// close everything else:
			foldEverybody(node.getModel().getParent(),node.getModel());
		};
        /**
         * Is sent when a node is deselected.
         */
        void onDeselectHook(freemind.view.mindmapview.NodeView node){};

		/**
		 * Is issued before a node is saved (eg. to save its notes, too, even if the notes is currently edited).
		 */
		void onSaveNode(freemind.modes.MindMapNode node){};
def foldEverybody(child, exception) {
		if(child == null || child.isRoot())
			return;
        def it = child.childrenUnfolded();
        while(it.hasNext()) {
                def child2 = it.next();
			if(child2 != exception) {
				c.setFolded(child2, true);
			}
        }
	if(!child.getParent().isRoot())
		foldEverybody(child.getParent(), exception.getParent());
}


}

def cookieKey = &quot;presentation_listener&quot;;
if(cookies.get(cookieKey) != null) {
	c.deregisterNodeSelectionListener(cookies.get(cookieKey));
}
def newListener = new MyNodeListener(c);
cookies.put(cookieKey, newListener);
c.registerNodeSelectionListener(newListener);</pre>
      </li>
    </ul>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#407000" CREATED="1204696614656" ID="ID_1588262906" MODIFIED="1229414646104" STYLE="fork" TEXT="How to install a script as a menu item">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Once, you've created or found some interesting scripts, you probably want to get a FreeMind menu item with an own shortcut to execute the script.
    </p>
    <p>
      To do this, save the script to a file and edit &quot;ScriptingEngine.xml&quot; inside the FreeMind script directory inside your installation.
    </p>
    <p>
      You'll find a template for a script action that is commented out (ie. surrounded by &lt;!-- ... --&gt;). Uncomment the template and fill out the following bold places:
    </p>
    <pre>      &lt;plugin_action
      name=&quot;<b>GroovyGroovy</b>&quot;
      documentation=&quot;<b>this is my first installed groovy script.</b>&quot;
      label=&quot;<b>plugins/GroovyScript1</b>&quot;
      base=&quot;freemind.extensions.ModeControllerHookAdapter&quot;
      class_name=&quot;plugins.script.ScriptingEngine&quot;&gt;
      &lt;plugin_mode class_name=&quot;freemind.modes.mindmapmode&quot;/&gt;
      &lt;plugin_menu location=&quot;<b>menu_bar/extras/first/scripting/groovy1</b>&quot;/&gt;
      &lt;plugin_property name=&quot;ScriptLocation&quot; value=&quot;<b>/home/foltin/test.groovy</b>&quot;/&gt;
      &lt;/plugin_action&gt;
    </pre>
    <p>
      The most important change is the location of the script. Moreover, if you have several scripts you want to install, the labels and the menu_location must be unique.
    </p>
    <p>
      If you now restart FreeMind you get a new menu item (in this example in the &quot;Extras&quot; menu) that carries out your script. Observe, that the &quot;node&quot; variable points to the root node.
    </p>
    <p>
      If you want to have a keyboard short cut for the new script, you have to add the bold line into the entry in ScriptingEngine.xml like:
    </p>
    <pre>      &lt;plugin_action
      name=&quot;GroovyGroovy&quot;
      documentation=&quot;this is my first installed groovy script.&quot;
      label=&quot;plugins/GroovyScript1&quot;
      <b>key_stroke=&quot;control shift M&quot; </b>
      base=&quot;freemind.extensions.ModeControllerHookAdapter&quot;
      class_name=&quot;plugins.script.ScriptingEngine&quot;&gt;
      &lt;plugin_mode class_name=&quot;freemind.modes.mindmapmode&quot;/&gt;
      &lt;plugin_menu location=&quot;menu_bar/extras/first/scripting/groovy1&quot;/&gt;
      &lt;plugin_property name=&quot;ScriptLocation&quot; value=&quot;/home/foltin/test.groovy&quot;/&gt;
      &lt;/plugin_action&gt;
    </pre>
  </body>
</html></richcontent>
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
</map>
