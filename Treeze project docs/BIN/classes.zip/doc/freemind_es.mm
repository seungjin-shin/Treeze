<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#993300" CREATED="1124560950701" ID="Freemind_Link_37609021" MODIFIED="1170661549281" TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body width=&quot;&quot;&gt;&#xa;    &lt;p align=&quot;center&quot;&gt;&#xa;      FreeMind&lt;br&gt;&lt;small&gt;- Aplicaci&#xf3;n libre para la creaci&#xf3;n de mapas mentales -&lt;/small&gt;&#xa0;&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;&#xa;">
<font BOLD="true" NAME="Dialog" SIZE="18"/>
<node CREATED="1124560950701" ID="Freemind_Link_367746551" LINK="http://freemind.sourceforge.net" MODIFIED="1170318639020" POSITION="left" TEXT="P&#xe1;gina web de Freemind">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1091417446" MODIFIED="1170318817613" POSITION="left" TEXT="Tabla de teclas r&#xe1;pidas">
<node COLOR="#338800" CREATED="1124560950701" ID="Freemind_Link_1439762647" MODIFIED="1170662308844" TEXT="Comandos de fichero&#xa;Nuevo mapa                                      - Ctrl+N&#xa;Abrir mapa                                      - Ctrl+O&#xa;Guardar mapa                                    - Ctrl+S&#xa;Guardar como&#x2026;                                   - Ctrl+A&#xa;Imprimir                                        - Ctrl+P&#xa;Cerrar                                          - Ctrl+Q&#xa;Mapa anterior                                   - Ctrl+Izquierda&#xa;Mapa siguiente                                  - Ctrl+Derecha&#xa;Exportar fichero a HTML                         - Ctrl+E&#xa;Exportar rama a HTML                            - Ctrl+H&#xa;Exportar rama a un nuevo fichero MM             - Alt+A&#xa;Abrir el primer fichero del hist&#xf3;rico           - Ctrl+SHIFT (MAY&#xda;SCULAS)+W&#xa;&#xa;Comandos de edici&#xf3;n&#xa;Buscar                                          - Ctrl+F&#xa;Buscar siguiente                                - Ctrl+G&#xa;Cortar                                          - Ctrl+X&#xa;Copiar                                          - Ctrl+C&#xa;Copiar elemento                                 - Ctrl+Y&#xa;Pegar                                           - Ctrl+V&#xa;&#xa;Comandos de modos&#xa;Modo Mapa mental (MindMap)                      - Alt+1&#xa;Modo navegaci&#xf3;n                                 - Alt+2&#xa;Modo fichero                                    - Alt+3&#xa;&#xa;Comandos de formato de nodos&#xa;Cursiva                                         - Ctrl+I&#xa;Negrita                                         - Ctrl+B&#xa;Nube (Cloud)                                    - Ctrl+SHIFT (MAY&#xda;SCULAS)+B&#xa;Cambiar el color del nodo                       - Alt+C&#xa;Mezclar el color del nodo                       - Alt+B&#xa;Cambiar el color del borde del nodo             - Alt+E&#xa;Aumentar el tama&#xf1;o de letra del nodo            - Ctrl+L&#xa;Disminuir el tama&#xf1;o de letra del nodo           - Ctrl+M&#xa;Aumentar el tama&#xf1;o de letra de la rama          - Ctrl+SHIFT (MAY&#xda;SCULAS)+L&#xa;Disminuir el tama&#xf1;o de letra de la rama         - Ctrl+SHIFT (MAY&#xda;SCULAS)+M&#xa;&#xa;Comandos del modo navegaci&#xf3;n&#xa;Ir a la ra&#xed;z                                    - ESCAPE&#xa;Subir                                           - ARRIBA&#xa;Bajar                                           - ABAJO&#xa;Izquierda                                       - IZQUIERDA&#xa;Derecha                                         - DERECHA&#xa;Seguir el enlace                                - Ctrl+ENTER&#xa;Disminuir Zoom                                  - Alt+ARRIBA&#xa;Aumentar Zoom                                   - Alt+ABAJO&#xa;&#xa;Comandos para un nuevo nodo&#xa;A&#xf1;adir un nodo hermano                          - ENTER&#xa;A&#xf1;adir un nodo hijo                             - INSERT&#xa;A&#xf1;adir un nodo hermano anterior (padre)         - SHIFT (MAY&#xda;SCULAS)+ENTER&#xa;&#xa;Comandos de edici&#xf3;n de nodos&#xa;Editar el nodo seleccionado                     - F2&#xa;Editar la longitud del nodo                     - Alt+ENTER&#xa;Unir nodos                                      - Ctrl+J&#xa;Desplegar/Replegar nodo                         - BARRA ESPACIADORA&#xa;Desplegar/Replegar todas las ramas de un nodo   - Ctrl+BARRA ESPACIADORA&#xa;Establecer enlace con un fichero                - Ctrl+SHIFT (MAY&#xda;SCULAS)+K&#xa;Establecer enlace con una entrada de texto      - Ctrl+K&#xa;Establecer enlace con un fichero de imagen      - Alt+K&#xa;Subir nodo (mover)                              - Ctrl+ARRIBA&#xa;Bajar nodo (mover)                              - Ctrl+ABAJO">
<font NAME="Courier New" SIZE="12"/>
</node>
</node>
<node COLOR="#006633" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_904501221" MODIFIED="1170319517218" POSITION="left" TEXT="Instalaci&#xf3;n">
<arrowlink DESTINATION="_Freemind_Link_904501221" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_823790149" STARTARROW="None" STARTINCLINATION="0;0;"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1911559485" MODIFIED="1170319539983" TEXT="Enlaces">
<node CREATED="1124560950701" ID="Freemind_Link_355384845" LINK="http://java.sun.com/j2se" MODIFIED="1170319548608" TEXT="Descargar el entorno de ejecuci&#xf3;n de Java (J2RE 1.4 &#xf3; superior)">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1612101865" LINK="http://sourceforge.net/project/showfiles.php?project_id=7118" MODIFIED="1170319561858" TEXT="Descargar la aplicaci&#xf3;n">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1170319584827" ID="Freemind_Link_1046224624" MODIFIED="1170319584827" TEXT="Para instalar FreeMind en Microsoft Windows, instalar Java de Sun e instalar FreeMind usando el instalador de &#xe9;ste."/>
<node CREATED="1170319584827" MODIFIED="1170319584827" TEXT="Para instalar FreeMind en Linux, descargar el entorno de ejecuci&#xf3;n de Java y la propia aplicaci&#xf3;n de FreeMind. Primero instale Java, y despu&#xe9;s descomprima FreeMind. Para usar FreeMind, ejecutar freemind.sh."/>
<node CREATED="1170319584827" MODIFIED="1170319584827" TEXT="En Microsoft Windows y MAC OS X, tambi&#xe9;n puede hacer doble click en el fichero freemind.jar alojado en carpeta lib para ejecutar FreeMind."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_353522063" MODIFIED="1170319618577" POSITION="left" TEXT="Explorando los ficheros de su ordenador">
<node CREATED="1170320065246" HGAP="25" ID="Freemind_Link_1640650757" MODIFIED="1170661644279" TEXT="Para explorar los ficheros en su ordenador, seleccione el modo fichero en el men&#xfa; desplegable Modos &#xf0e0; File. [Alt+3]" VSHIFT="-13"/>
<node CREATED="1170320065246" ID="Freemind_Link_555797793" MODIFIED="1170661634201" TEXT="Navegar&#xe1; por su &#xe1;rbol de ficheros/directorios como si fuese un mapa mental. "/>
<node CREATED="1170320065246" ID="Freemind_Link_1148324994" MODIFIED="1170320065246" TEXT="Para hacer que una carpeta sea el nodo central, en el men&#xfa; contextual de nodos (Bot&#xf3;n izquierdo del rat&#xf3;n en el nodo) seleccione &#x201c;Centrar&#x201d;."/>
<node CREATED="1170320065246" ID="Freemind_Link_1098215924" MODIFIED="1170326984528" TEXT="Para ver, editar &#xf3; ejecutar fichero, siga el enlace de su nodo."/>
<node CREATED="1170320065246" ID="Freemind_Link_223431013" MODIFIED="1170662169175" TEXT="El modo fichero actualmente no es muy &#xfa;til. Es una demostraci&#xf3;n de que no es mucho m&#xe1;s dif&#xed;cil generar &#xe1;rboles de informaci&#xf3;n desde otras fuentes que de mapas mentales. No hay evidencia de que actualmente la gente utilice este modo."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1530607683" MODIFIED="1170661606154" POSITION="left" TEXT="Explorando mapas mentales">
<node CREATED="1170327125916" ID="Freemind_Link_1803255787" MODIFIED="1170661616154" TEXT="Tanto para explorar como para editar mapas mentales, seleccione el modo navegaci&#xf3;n (Browse) en el men&#xfa; desplegable Modos&#xf0e0;Browse. [Alt+2]"/>
<node CREATED="1170327125916" MODIFIED="1170327125916" TEXT="Las razones para separar el modo de exploraci&#xf3;n son t&#xe9;cnicas. Navegar &#xf3; explorar es lo &#xfa;nico que se puede hacer con el applet que se puede colocar en su sitio web. Normalmente, usted no usar&#xe1; el modo exploraci&#xf3;n en FreeMind."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1136088046" MODIFIED="1170327167056" POSITION="left" TEXT="Sobre los modos">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170327180322" HGAP="30" ID="Freemind_Link_1279853809" MODIFIED="1170661662794" TEXT="Aunque FreeMind es principalmente una herramienta para editar mapas mentales, est&#xe1; dise&#xf1;ado para ser capaz de visualizar informaci&#xf3;n de diversas fuentes de datos. Para hacer una fuente de datos espec&#xed;fica visible en FreeMind, un programador tiene que escribirla con un modo a tal fin. El modo fichero es un ejemplo. No sabemos si se han implementado otros modos. No est&#xe1; claro si alguien realmente querr&#xed;a hacer uso de esta arquitectura; es un recurso a explotar si alguien est&#xe1; interesado y lo desea hacer." VSHIFT="4"/>
<node CREATED="1170327180322" ID="Freemind_Link_501151798" MODIFIED="1170661865274" TEXT="Hay c&#xf3;digo casi preparado para el modo &#x201c;esquema&#x201d; (Scheme) que deja editar programas de esquematizaci&#xf3;n. De nuevo, la utilidad no est&#xe1; clara. A diferencia del modo de mapa mental, otros modos son m&#xe1;s bien demostraciones de las posibilidades de la aplicaci&#xf3;n diferentes a las actuales."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1525986009" MODIFIED="1170327302117" POSITION="left" TEXT="Instalar el applet de FreeMind en su sitio web">
<node CREATED="1170327314148" ID="Freemind_Link_728262703" MODIFIED="1170662179237" TEXT="Usted puede instalar el applet en su sitio web para que otros usuarios puedan ver su mapas mentales."/>
<node CREATED="1124560950701" ID="Freemind_Link_1253169862" LINK="http://sourceforge.net/project/showfiles.php?group_id=7118" MODIFIED="1170327467943" TEXT="Descargue el applet, que se llama freemind-browser." VSHIFT="-6"/>
<node CREATED="1170327314148" ID="Freemind_Link_748768856" MODIFIED="1170662189253" TEXT="El fichero descargado contiene los ficheros freemindbrowser.jar y freemindbrowser.html. Cree un enlace desde su p&#xe1;gina al freemindbrowser.html. En el fichero freemindbrowser.html cambie la ruta para que apunte a su mapa mental."/>
<node CREATED="1170327314164" ID="Freemind_Link_1041757100" MODIFIED="1170662204284" TEXT="El fichero de extensi&#xf3;n .jar del applet debe estar alojado en el mismo servidor que el mapa, por razones de seguridad de Java. Tiene que subir por tanto, el fichero .jar del applet de FreeMind y su mapa mental a su sitio web."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1083756111" MODIFIED="1170327531427" POSITION="left" TEXT="Usando el applet de FreeMind">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170327537224" ID="Freemind_Link_1893434848" MODIFIED="1170327537224" TEXT="En el applet de FreeMind, s&#xf3;lo puede usar el modo exploraci&#xf3;n/navegaci&#xf3;n; no podr&#xe1; editar los mapas. Haga click en el nodo para desplegar/replegarlo, o para seguir un enlace. Arrastre el fondo para mover el mapa. Para buscar dentro del mapa, utilice el modo contextual de los nodos. (Bot&#xf3;n izquierdo del rat&#xf3;n)."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1976458022" MODIFIED="1170327564379" POSITION="left" TEXT="Cambios en la interfaz de usuario en la versi&#xf3;n 0.6.5">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170327577817" ID="Freemind_Link_361392781" MODIFIED="1170327577817" TEXT="Algunas configuraciones de teclado han tenido que ser redefinidas para darles un uso m&#xe1;s intuititvo y considerado est&#xe1;ndar. Algunas de las nuevas configuraciones de teclado son usadas en herramientas de Microsoft. La nueva configuraci&#xf3;n de teclas incluyen el &#x201c;Enter&#x201d; para editar nuevos nodos sobre el seleccionado, insertar nuevos nodos hijos, F2 para editar los nodos &#x2013; Aqu&#xed; la influencia de Microsoft es aparente aunque puede que no hay una raz&#xf3;n de uso intuitivo para usar la tecla F2 para tener que editar nodos. Pero una vez que se acostumbre al uso de las teclas r&#xe1;pidas en todas las aplicaciones que use (En ingl&#xe9;s, claro), querr&#xe1; hacer uso de ellas en FreeMind tambi&#xe9;n."/>
<node CREATED="1170327577817" MODIFIED="1170327577817" TEXT="La configuraci&#xf3;n del teclado puede cambiarse en el men&#xfa; desplegable Herramientas &#xf0e0; Preferencias (Preferences)."/>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_784043927" MODIFIED="1170327604301" POSITION="left" TEXT="Cr&#xe9;ditos">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_415458128" MODIFIED="1170327624629" TEXT="Autores">
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1896457660" MODIFIED="1124560950701" TEXT="Joerg Mueller">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:ponders@t-online.de" MODIFIED="1124560950701" TEXT="ponders@t-online.de">
<font NAME="Dialog" SIZE="10"/>
</node>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_268552515" MODIFIED="1170327672284" TEXT="Universidad de Freiburg, Alemania">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_984984595" LINK="http://mujweb.cz/www/danielpolansky" MODIFIED="1124560950701" TEXT="Daniel Polansky">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_459203293" MODIFIED="1124560950701" TEXT="Petr Novak">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_875814410" MODIFIED="1124560950701" TEXT="Christian Foltin">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:christian.foltin@gmx.de" MODIFIED="1124560950701" TEXT="christian.foltin@gmx.de">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1415293905" MODIFIED="1124560950701" TEXT="Dimitri Polivaev">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_816166020" MODIFIED="1170327637519" TEXT="Peque&#xf1;as contribuciones">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_189984007" MODIFIED="1124560950701" TEXT="Andrew Iggleden">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_117526613" MODIFIED="1170327651956" TEXT="Instalador de Windows">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1096673251" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Eclipse howto">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1024053399" MODIFIED="1124560950701" TEXT="David Butt">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Tutorial flash">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1534904708" MODIFIED="1124560950701" TEXT="David Low">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Helpful">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_360501151" MODIFIED="1170327642550" TEXT="Traducciones">
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_807977431" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Italian translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1853214917" MODIFIED="1124560950701" TEXT="Knud Riish&#xf8;jg&#xe5;rd">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Danish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1676529317" MODIFIED="1124560950701" TEXT="Takeshi Kakeda">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562983644" FOLDED="true" ID="Freemind_Link_1172193026" MODIFIED="1124562984816" TEXT="Kohichi Aoki">
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1928961904" MODIFIED="1124560950701" TEXT="Alex Dukal">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562998159" FOLDED="true" ID="Freemind_Link_757563697" MODIFIED="1124563008034" TEXT="Hugo Gayosso">
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1783275246" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_929540960" MODIFIED="1124560950701" TEXT="Sylvain Gamel">
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="French translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561242082" FOLDED="true" ID="Freemind_Link_946171164" MODIFIED="1124561245019" TEXT="Koen Roggemans">
<node COLOR="#999999" CREATED="1124561245957" ID="Freemind_Link_1819881845" MODIFIED="1124561251675" TEXT="Dutch translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561374999" FOLDED="true" ID="Freemind_Link_235962981" MODIFIED="1124561376718" TEXT="Rafal Kraik">
<node COLOR="#999999" CREATED="1124561377702" ID="Freemind_Link_459079511" MODIFIED="1124561382155" TEXT="Polish translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561969717" FOLDED="true" ID="Freemind_Link_653284985" MODIFIED="1124561972920" TEXT="Goliath">
<node COLOR="#999999" CREATED="1124561438294" ID="Freemind_Link_1387213811" MODIFIED="1124561445950" TEXT="Korean translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561753254" FOLDED="true" ID="Freemind_Link_35211963" MODIFIED="1124563712385" TEXT="Miles a.k.a. filmsi">
<node COLOR="#999999" CREATED="1124561491886" ID="Freemind_Link_835144271" MODIFIED="1124561506386" TEXT="Slovenian translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561814721" FOLDED="true" ID="Freemind_Link_1008886206" MODIFIED="1124561818580" TEXT="William Chen">
<node COLOR="#999999" CREATED="1124561497308" ID="Freemind_Link_1960552629" MODIFIED="1124561506011" TEXT="Chinese translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561823877" FOLDED="true" ID="Freemind_Link_1650138043" MODIFIED="1124561876907" TEXT="Radek &#x160;varc">
<node COLOR="#999999" CREATED="1124561515761" ID="Freemind_Link_768227373" MODIFIED="1124561519885" TEXT="Czech translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562250475" FOLDED="true" ID="Freemind_Link_901975324" MODIFIED="1124562252007" TEXT="Bal&#xe1;zs M&#xe1;rton">
<node COLOR="#999999" CREATED="1124562252585" ID="Freemind_Link_557911120" MODIFIED="1124562258428" TEXT="Hungarian translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562948942" FOLDED="true" ID="Freemind_Link_290351026" MODIFIED="1124562950270" TEXT="Luis Ferreira ">
<node COLOR="#999999" CREATED="1124562956332" ID="Freemind_Link_6081004" MODIFIED="1124562961879" TEXT="Portuguese translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124563066204" ID="Freemind_Link_23652566" MODIFIED="1124563189197" TEXT="The credits for translations are probably incomplete. If we have forggoten you, let us know. All people who we know to contribute a least an incomplete translation are listed.">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="Freemind_Link_1273736577" MODIFIED="1170327716253" POSITION="right" TEXT="Pulse Ctrl+F para buscar. Pulse Ctrl+G para buscar el siguiente. Para hacer un b&#xfa;squeda global, pulse ESCAPE antes de la b&#xfa;squeda."/>
<node COLOR="#0033ff" CREATED="1124560950701" ID="Freemind_Link_1043530021" MODIFIED="1170338370893" POSITION="right" TEXT="Pulse DERECHA para desplegar una caja de texto."/>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1596161299" MODIFIED="1170338378534" POSITION="right" TEXT="Introducci&#xf3;n">
<node CREATED="1170338389205" ID="Freemind_Link_792489824" MODIFIED="1170661902868" TEXT="FreeMind hace posible la creaci&#xf3;n los llamados mapas mentales. Es m&#xe1;s, la gente la utiliza como alternativa de un bloc de notas tabulado &#xf3; de un gestor personal de informaci&#xf3;n." VSHIFT="-1"/>
<node CREATED="1170338389205" MODIFIED="1170338389205" TEXT="La informaci&#xf3;n se almacena en cajas de texto, llamados nodos. Los nodos se conectan entre s&#xed; usando l&#xed;neas curvas llamadas bordes (ramas)."/>
<node CREATED="1170338389205" MODIFIED="1170338389205" TEXT="Esta es una documentaci&#xf3;n para FreeMind 0.8.0, por lo que el mapeo de teclas r&#xe1;pidas &#xf3; las funciones de los men&#xfa;s pueden cambiar de una versi&#xf3;n a otra."/>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_706084071" MODIFIED="1170401730966" POSITION="right" TEXT="Demostraci&#xf3;n de algunas caracter&#xed;sticas">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_735193624" MODIFIED="1170401751153" TEXT="Apariencia">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_801391449" MODIFIED="1170401759200" TEXT="Los nodos pueden tener diferentes colores">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1124560950701" ID="Freemind_Link_1935642015" MODIFIED="1170401763778" TEXT="Rojo">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#009900" CREATED="1124560950701" ID="Freemind_Link_358662946" MODIFIED="1170401767216" TEXT="Verde">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0000cc" CREATED="1124560950701" ID="Freemind_Link_569149865" MODIFIED="1170401772466" TEXT="Azul">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_" MODIFIED="1170401783950" TEXT="Los nodos pueden tener varios colores de fondo">
<node BACKGROUND_COLOR="#ff66cc" CREATED="1124560950701" ID="_Freemind_Link_1358611533" MODIFIED="1170401812419" TEXT="&#xc9;ste"/>
<node BACKGROUND_COLOR="#66ff66" CREATED="1124560950701" ID="_Freemind_Link_1317973766" MODIFIED="1170401826248" TEXT="&#xf3; &#xe9;ste"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_542663260" MODIFIED="1170401836498" TEXT="Los nodos pueden tener diferentes estilos de fuentes">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_807716236" MODIFIED="1170401842685" TEXT="Negrita">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1517956725" MODIFIED="1170401848310" TEXT="Cursiva">
<font ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1716797514" MODIFIED="1170401855592" TEXT="Negrita y cursiva">
<font BOLD="true" ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1651709962" MODIFIED="1170401864248" TEXT="Los tama&#xf1;os de fuente puedes ser diferentes">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_94543529" MODIFIED="1170401870482" TEXT="Peque&#xf1;o">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1637486722" MODIFIED="1170401875560" TEXT="Normal">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_660570324" MODIFIED="1170401882482" TEXT="Grande">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_232732639" MODIFIED="1170401889154" TEXT="Gigante">
<font NAME="SansSerif" SIZE="20"/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="OOh">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_277624866" MODIFIED="1170401897076" TEXT="Se pueden utilizar diferente fuentes de letra">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_1872197155" MODIFIED="1170401905951" TEXT="&#xc9;sta">
<font NAME="Times New Roman" SIZE="16"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1568731425" MODIFIED="1170401911608" TEXT="&#xc9;sta otra">
<font NAME="Verdana" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_704399864" MODIFIED="1170401921873" TEXT="&#xd3; &#xe9;sta otra">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1193071041" MODIFIED="1170401933139" TEXT="Se puede utilizar diferentes tipos de nodos">
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1979277285" MODIFIED="1170402078187" TEXT="Con bifurcaciones">
<node CREATED="1124560950701" ID="_Freemind_Link_89124429" MODIFIED="1170402083218" TEXT="Con bifurcaciones"/>
<node CREATED="1124560950701" ID="_Freemind_Link_173850525" MODIFIED="1170402086124" TEXT="Con bifurcaciones"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1001811541" MODIFIED="1170402091952" STYLE="bubble" TEXT="Con burbujas">
<node CREATED="1124560950701" ID="_Freemind_Link_1677737286" MODIFIED="1170402095281" STYLE="bubble" TEXT="Con burbujas"/>
<node CREATED="1124560950701" ID="_Freemind_Link_978246353" MODIFIED="1170402098093" STYLE="bubble" TEXT="Con burbujas"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1271086229" MODIFIED="1170402128468" TEXT="Los nodos se pueden desplegar">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_307016912" MODIFIED="1170402134671" TEXT="Doblez">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_339068638" MODIFIED="1170402138140" TEXT="Oculta">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1488567837" MODIFIED="1170402144875" TEXT="&#xc1;rbol">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_1450639329" MODIFIED="1170402149750" TEXT="Roble">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1463816938" MODIFIED="1170402159531" TEXT="Haya">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="Freemind_Link_1006242670" MODIFIED="1170402153547" TEXT="Olmo">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_271846593" MODIFIED="1170402170062" TEXT="Los pueden contener enlaces a&#x2026;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1178924051" MODIFIED="1170402176937" TEXT="P&#xe1;ginas web">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" LINK="http://www.google.com/" MODIFIED="1124560950701" TEXT="http://www.google.com/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1626963395" LINK="www.google.com" MODIFIED="1124560950701" TEXT="www.google.com">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1646455138" MODIFIED="1170402230875" TEXT="Freemind thinks this is executable :)">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1571818298" MODIFIED="1170402185078" TEXT="Carpetas locales">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="Freemind_Link_134747683" LINK="C:/Program Files/" MODIFIED="1170402246313" TEXT="C:/Program files/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" LINK="/home/" MODIFIED="1124560950701" TEXT="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_179286322" MODIFIED="1170402191875" TEXT="Ejecutables">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_801065485" LINK="%SystemRoot%\regedit.exe" MODIFIED="1124560950701" TEXT="%SystemRoot%\regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006600" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="You see that the node is executable by icon.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_597537942" MODIFIED="1170402198969" TEXT="Cualquier otro documento en su ordenador o en la red de su empresa.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_839677176" MODIFIED="1170402256219" TEXT="Nodos multil&#xed;nea">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1423568963" MODIFIED="1170402268204" TEXT="Los nodos multil&#xed;nea se puede ver como un p&#xe1;rrafo o varios p&#xe1;rrafos. Si va a construir una base de conocimiento usando FreeMind, es la mejor manera de hacerlo usando este tipo de nodos. En vez de tener un fichero de texto plano para almacenar sus notas, puede tener un nodo ra&#xed;z con m&#xfa;ltiples nodos como hijos."/>
<node CREATED="1124560950717" ID="_Freemind_Link_1686184172" MODIFIED="1170402277094" TEXT="&#x201c;La Ciencia son hechos; al igual que las casa se hacen de piedra, la Ciencia est&#xe1;  hecha de hechos; pero un mont&#xf3;n de piedras no es una casa y una colecci&#xf3;n de hechos no tiene por que ser necesariamente ciencia&#x201d; -- Henri Poincar&#xe9;."/>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1045645831" MODIFIED="1170402296782" TEXT="Nodos multil&#xed;nea cortos con nuevas l&#xed;neas (newlines).">
<node CREATED="1124560950717" ID="_Freemind_Link_1957797574" MODIFIED="1170402322173" TEXT="L&#xed;nea,&#xa;y una segunda&#xa;&#xa;Y todav&#xed;a se puede hacer otra,&#xa;as&#xed; que... Qu&#xe9; le parece &#xe9;sto?"/>
</node>
<node COLOR="#669900" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_871345962" MODIFIED="1170402339813" TEXT="Puede emular ramas etiquetadas">
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1576627386" MODIFIED="1170402348642" TEXT="&#xc1;rbol">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_707227593" MODIFIED="1170402363954" TEXT="es un">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_1405291988" MODIFIED="1170402377767" TEXT="Roble">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_867032809" MODIFIED="1170402368939" TEXT="es un">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_779687380" MODIFIED="1170402382657" TEXT="Haya">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_802687707" MODIFIED="1170402372720" TEXT="es un">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_544688485" MODIFIED="1170402386376" TEXT="Olmo">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1421027901" MODIFIED="1170402355314" TEXT="&#xc1;rbol">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_921860045" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_1635761458" MODIFIED="1170402395236" TEXT="Hoja">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1017438621" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="Freemind_Link_1545141692" MODIFIED="1170402400142" TEXT="Tronco">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="Freemind_Link_686526928" MODIFIED="1170402409689" TEXT="Se pueden poner iconos en los nodos">
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_318937820" MODIFIED="1170402416736" TEXT="Puede tener nubes">
<cloud/>
<node CREATED="1124560950717" ID="Freemind_Link_1908793564" MODIFIED="1170402436205" TEXT="Con colores personalizados">
<cloud COLOR="#3333ff"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1750585847" MODIFIED="1170402448392" TEXT="Puede tener enlaces enlaces gr&#xe1;ficos">
<node CREATED="1124560950717" ID="_Freemind_Link_1212380407" MODIFIED="1170402453642" TEXT="Conectando nodos">
<arrowlink DESTINATION="_Freemind_Link_1249400461" ENDARROW="Default" ENDINCLINATION="41;0;" STARTARROW="None" STARTINCLINATION="41;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1249400461" MODIFIED="1170402460470" TEXT="Con otros">
<arrowlink COLOR="#6600ff" DESTINATION="_Freemind_Link_880551392" ENDARROW="Default" ENDINCLINATION="47;0;" ID="Freemind_Arrow_Link_85185909" STARTARROW="None" STARTINCLINATION="47;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_880551392" MODIFIED="1170402465439" TEXT="Con diferentes colores">
<arrowlink DESTINATION="_Freemind_Link_1789233193" ENDARROW="Default" ENDINCLINATION="82;44;" ID="Freemind_Arrow_Link_1672464612" STARTARROW="None" STARTINCLINATION="82;44;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1789233193" MODIFIED="1170402473017" TEXT="Y diferentes encaminamientos"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_127668276" MODIFIED="1170402480955" TEXT="El nodo se puede mover y colocar libremente">
<node CREATED="1124560950717" ID="_Freemind_Link_894936766" MODIFIED="1170402486221" TEXT="Uno"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1942481455" MODIFIED="1170402490908" TEXT="Otro"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1709752669" MODIFIED="1170402508049" POSITION="right" TEXT="Crear y borrar nodos">
<node CREATED="1170402517861" ID="Freemind_Link_151246132" MODIFIED="1170402517861" TEXT="Para crear un nodo, pulse INSERT"/>
<node CREATED="1170402517861" MODIFIED="1170402517861" TEXT="Para crear un nodo hijo mientra edita otro nodo, pulse INSERT mientras edita"/>
<node CREATED="1170402517877" MODIFIED="1170402517877" TEXT="Para crear un nodo hermano anterior, pulse ENTER"/>
<node CREATED="1170402517877" MODIFIED="1170402517877" TEXT="Para crear un nodo hermano despu&#xe9;s, pulse SHIFT (MAY&#xda;SCULAS)+ENTER"/>
<node CREATED="1170402517877" MODIFIED="1170402517877" TEXT="Para borrar un nodo, pulse DELETE &#xf3; SUPR"/>
<node CREATED="1170402517877" MODIFIED="1170402517877" TEXT="Para borrar un nodo y poder pegarlo despu&#xe9;s, pulse CTRL+X."/>
<node CREATED="1170402517877" MODIFIED="1170402517877" TEXT="Como alternativa, puede usar el men&#xfa; contextual, haciendo click izquierdo con el rat&#xf3;n en un nodo."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1700974092" MODIFIED="1170402540752" POSITION="right" TEXT="Editar un nodo de texto">
<node CREATED="1170402567565" ID="Freemind_Link_611372497" MODIFIED="1170402567565" TEXT="Para editar un nodo, pulse F2, HOME (INICIO) &#xf3; END (FIN), &#xf3; en el men&#xfa; contextual usando Edit. Para terminar la edici&#xf3;n de un nodo, pulse ENTER."/>
<node CREATED="1170402567565" MODIFIED="1170402567565" TEXT="Para reemplazar un nodo de texto con otro nuevo, comience a escribir directamente."/>
<node CREATED="1170402567565" MODIFIED="1170402567565" TEXT="Para forzar el cambio de edici&#xf3;n de un nodo largo desde uno corto, pulse ALT+ENTER."/>
<node CREATED="1170402567565" MODIFIED="1170402567565" TEXT="Para dividir un nodo largo, use el bot&#xf3;n SEPARAR (Split) en la parte superior del editor de nodos, o pulse ALT+S en el editor de nodos largos."/>
<node CREATED="1170402567565" MODIFIED="1170402567565" TEXT="Para introducir una nueva l&#xed;nea en el editor de nodos largos, pulse CTRL+ENTER. No puede insertar una nueva l&#xed;nea en el editor corto o b&#xe1;sico de nodos."/>
<node CREATED="1170402567565" MODIFIED="1170402567565" TEXT="Para copiar una selecci&#xf3;n al portapapeles, haga click con el bot&#xf3;n derecho del rat&#xf3;n y seleccione COPIAR."/>
<node CREATED="1170402567565" MODIFIED="1170402567565" TEXT="Por defecto, al pulsar ENTER se termina la edici&#xf3;n de un nodo largo, y con CTRL+ENTER se inserta una nueva l&#xed;nea. Deseleccionando la opci&#xf3;n &#x201c;Confirmar ENTER&#x201d; puede invertir la funci&#xf3;n de la citada combinaci&#xf3;n de teclas, p.e. ENTER inserta una nueva l&#xed;nea y CTRL+ENTER finaliza la edici&#xf3;n. Puede establecer por defecto este valor en el men&#xfa; preferencias, y se almacenar&#xe1; cuando finalice la sesi&#xf3;n de FreeMind."/>
<node CREATED="1170402567565" MODIFIED="1170402567565" TEXT="FreeMind soporta Unicode. Adem&#xe1;s, puede usar el script que usted elija."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1660149394" MODIFIED="1170402594612" POSITION="right" TEXT="Dar formato a un nodo">
<node CREATED="1170402604643" ID="Freemind_Link_183644252" MODIFIED="1170402604643" TEXT="Para poner en negrita un nodo, pulse CTRL+B."/>
<node CREATED="1170402604643" MODIFIED="1170402604643" TEXT="Para poner en cursiva un nodo, pulse CTRL+I."/>
<node CREATED="1170402604643" MODIFIED="1170402604643" TEXT="Para cambiar el color del texto del nodo, pulse ALT+C."/>
<node CREATED="1170402604643" MODIFIED="1170402604643" TEXT="Para cambiar el color del fondo de un nodo, en el men&#xfa; contextual utilice Formato --&gt; Color de fondo del nodo."/>
<node CREATED="1170402604643" MODIFIED="1170402604643" TEXT="Para aumentar el tama&#xf1;o del texto del nodo, pulse CTRL++ (Tecla +, NO del teclado num&#xe9;rico, sino del de texto)."/>
<node CREATED="1170402604659" MODIFIED="1170402604659" TEXT="Para disminuir el tama&#xf1;o del texto del nodo, pulse CTRL+- (Tecla -, NO del teclado num&#xe9;rico, sino del de texto)."/>
<node CREATED="1170402604659" MODIFIED="1170402604659" TEXT="Para cambiar el tipo de fuente de texto, use el campo a tal fin en la barra principal."/>
<node CREATED="1170402604659" MODIFIED="1170402604659" TEXT="Para copiar formatos a un nodo, pulse ALT+V."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_526328879" MODIFIED="1170402629050" POSITION="right" TEXT="Usar estilos f&#xed;sicos">
<node CREATED="1170402640284" ID="Freemind_Link_1076084298" MODIFIED="1170402640284" TEXT="Para aplicar un estudio f&#xed;sico, en el men&#xfa; contextual use &#x201c;Estilo f&#xed;sico&#x201d; y seleccione el estilo deseado. Para aplicar estilos m&#xe1;s r&#xe1;pidamente, utilice las teclas r&#xe1;pidas que se muestran en el citado men&#xfa; contextual."/>
<node CREATED="1170402640284" MODIFIED="1170402640284" TEXT="Para a&#xf1;adir su propio estilo f&#xed;sico, en el supuesto de que usted sea un usuario con perfil t&#xe9;cnico, puede hacerlo editando el fichero &#x201c;patterns.xml&#x201d; ubicado en la carpeta &#x201c;freemind&#x201d; de su equipo."/>
<node CREATED="1170402640284" MODIFIED="1170402640284" TEXT="Una observaci&#xf3;n sobre el fichero de estilos. Los estilos f&#xed;sicos se aplican al nodo, si existe la etiqueta de de nodo (&lt;node&gt;). Se aplicar&#xe1; al borde, si tiene la etiqueta borde (&lt;edge&gt;). La etiqueta nodo (&lt;node&gt;) puede tener una etiqueta fuente (&lt;font&gt;) como un hijo. Estudie atentamente el fichero &#x201c;patterns.xml&#x201d; facilitado por FreeMind."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1697687428" MODIFIED="1170402655706" POSITION="right" TEXT="Resaltar los nodos mediante nubes">
<node CREATED="1124560950717" MODIFIED="1124560950717" TEXT="Clouds are well suited for highlighting a region. Highlighted are the node and all its descendants."/>
<node CREATED="1170402669175" MODIFIED="1170402669175" TEXT="Las nubes se pueden utilizar para resaltar una regi&#xf3;n. Lo que se resalta es el nodo y sus descendientes."/>
<node CREATED="1170402669191" ID="Freemind_Link_307492688" MODIFIED="1170402669191" TEXT="Para a&#xf1;adir una nube, pulse CTRL+SHIFT (MAY&#xda;SCULAS)+B &#xf3; en el men&#xfa; contextual del nodo, utilice Insertar--&gt;Nube."/>
<node CREATED="1170402669191" ID="Freemind_Link_1144511960" MODIFIED="1170402669191" TEXT="Para cambiar el color de la nube, en men&#xfa; contextual de nodo seleccione Formato--&gt;Color de Nube."/>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1884870247" MODIFIED="1170402707785" TEXT="Las nubes pueden tener varios colores de fondo como verde...">
<cloud COLOR="#e1f2e1"/>
<node CREATED="1124560950717" ID="Freemind_Link_335862648" MODIFIED="1170402714863" TEXT="... &#xf3; marr&#xf3;n">
<cloud COLOR="#ede5d5"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_203858515" MODIFIED="1170402734160" POSITION="right" TEXT="A&#xf1;adir enlaces &#xf3; hiperv&#xed;nculos">
<node CREATED="1170402743613" ID="Freemind_Link_1312466416" MODIFIED="1170402743613" TEXT="Para a&#xf1;adir un enlace &#xf3; hiperv&#xed;nculo a un nodo, presione CTRL+K &#xf3; en el men&#xfa; contextual utilice Insertar--&gt;Enlace."/>
<node CREATED="1170402743613" MODIFIED="1170402743613" TEXT="Para borrar un enlace, Deje el enlace en blanco despu&#xe9;s de pulsar CTRL+K."/>
<node CREATED="1170402743613" LINK="mailto:&#x201c;mailto:dircorreo@correo.com&#x201d;" MODIFIED="1170402743613" TEXT="Para enlazar con una cuenta de correo electr&#xf3;nico, establezca el enlace como en este ejemplo: &#x201c;mailto:dircorreo@correo.com&#x201d;"/>
<node CREATED="1170402743613" LINK="mailto:&#x201c;mailto:dircorreo@correo.com?subject=Asunto&#x201d;" MODIFIED="1170402743613" TEXT="Para enlazar con una direcci&#xf3;n de correo electr&#xf3;nico e incluir a su vez un asunto, escriba lo siguiente en el enlace: &#x201c;mailto:dircorreo@correo.com?subject=Asunto&#x201d;"/>
<node CREATED="1170402743613" MODIFIED="1170402743613" TEXT="Se puede enlazar a p&#xe1;ginas web, ficheros locales &#xf3; direcciones de correo electr&#xf3;nico."/>
<node CREATED="1170402743707" FOLDED="true" ID="Freemind_Link_1974937042" MODIFIED="1170402743707" TEXT="Links">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1170402743707" LINK="mailto:dircorreo@correo.com" MODIFIED="1170402743707" TEXT="mailto:dircorreo@correo.com"/>
<node CREATED="1170402743707" LINK="mailto:dircorreo@correo.com?subject=Asunto" MODIFIED="1170402743707" TEXT="mailto:dircorreo@correo.com?subject=Asunto"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1044397139" MODIFIED="1170402783082" POSITION="right" TEXT="A&#xf1;adir iconos">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170402797691" ID="Freemind_Link_1687645098" MODIFIED="1170402797691" TEXT="Un nodo puede tener varios iconos."/>
<node CREATED="1170402797691" MODIFIED="1170402797691" TEXT="Para a&#xf1;adir iconos a un nodo, seleccione un nodo y haga click en los iconos de la barra de men&#xfa; vertical de la izquierda de su pantalla. Mientras mueve el rat&#xf3;n hacia la citada barra de iconos, mantenga pulsado el bot&#xf3;n ALT &#xf3; CTRL de modo que no pierda el foco &#xf3; selecci&#xf3;n del nodo."/>
<node CREATED="1170402797691" MODIFIED="1170402797691" TEXT="Para borrar un icono, pulse la cruz roja en la parte de arriba de la barra de iconos."/>
<node CREATED="1170402797691" MODIFIED="1170402797691" TEXT="Para borrar todos los iconos, pulse el icono de la papelera en la parte de arriba de la barra de iconos."/>
<node CREATED="1170402797691" MODIFIED="1170402797691" TEXT="Para a&#xf1;adir un icono a un nodo sin utilizar la barra de men&#xfa;, presione ALT+I."/>
<node CREATED="1170402797691" MODIFIED="1170402797691" TEXT="No existe opci&#xf3;n para utilizar sus propios iconos, por lo que deber&#xe1; elegir los que le ofrece FreeMind &#xfa;nicamente."/>
<node CREATED="1170402797691" ID="Freemind_Link_1437377566" MODIFIED="1170402797691" TEXT="Para mostrar u ocultar la barra de iconos, utilice el men&#xfa; de la barra superior. Ver--&gt;Des(activar) Barra de herramientas de la izquierda. La barra de herramientas de la izquierda es la forma de llamar a la barra de iconos en la aplicaci&#xf3;n."/>
<node CREATED="1124560950717" ID="Freemind_Link_1609274" MODIFIED="1170402870301" TEXT="Los iconos adjuntados a este nodo son todos los que existen, no hay m&#xe1;s.">
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1996597932" MODIFIED="1170402930317" POSITION="right" TEXT="A&#xf1;adir enlaces gr&#xe1;ficos (Flechas de enlace)">
<node CREATED="1170402940036" ID="Freemind_Link_1942968106" MODIFIED="1170403283663" TEXT="Para crear un enlace gr&#xe1;fico entre dos nodos, arrastre un nodo y su&#xe9;ltelo en otro nodo teniendo pulsadas las teclas SHIFT (MAY&#xda;SCULAS) y CTRL; suelte el bot&#xf3;n del rat&#xf3;n antes de soltar las teclas antes mencionadas.">
<arrowlink DESTINATION="Freemind_Link_967984859" ENDARROW="Default" ENDINCLINATION="99;-7;" ID="Freemind_Arrow_Link_1548449519" STARTARROW="None" STARTINCLINATION="227;0;"/>
</node>
<node CREATED="1170402940036" ID="Freemind_Link_1842889348" MODIFIED="1170402940036" TEXT="Otro modo ser&#xed;a arrastrando y soltando usando el bot&#xf3;n derecho del rat&#xf3;n."/>
<node CREATED="1170402940036" MODIFIED="1170402940036" TEXT="Para cambiar el color del enlace, utilice el men&#xfa; contextual, haciendo click con el bot&#xf3;n derecho del rat&#xf3;n en el enlace gr&#xe1;fico."/>
<node CREATED="1170402940036" MODIFIED="1170402940036" TEXT="Para cambiar las fechas del enlace, use el men&#xfa; contextual del enlace."/>
<node CREATED="1170402940036" MODIFIED="1170402940036" TEXT="Para borrar un enlace, use el men&#xfa; contextual del enlace."/>
<node CREATED="1170402940036" ID="Freemind_Link_967984859" MODIFIED="1170403283663" TEXT="Para navegar al final de uno de los nodos del enlace, utilice el men&#xfa; contextual."/>
<node CREATED="1170402940036" ID="Freemind_Link_1478196416" MODIFIED="1170403278835" TEXT="Para cambiar la ruta de una flecha de enlace, arr&#xe1;strela y mu&#xe9;vela.">
<arrowlink DESTINATION="Freemind_Link_967984859" ENDARROW="Default" ENDINCLINATION="73;0;" ID="Freemind_Arrow_Link_631292318" STARTARROW="None" STARTINCLINATION="73;0;"/>
</node>
<node CREATED="1170402940036" MODIFIED="1170402940036" TEXT="A continuaci&#xf3;n, un ejemplo de enlace de flecha:"/>
<node COLOR="#cc9900" CREATED="1170402940036" FOLDED="true" ID="Freemind_Link_1315155160" MODIFIED="1170403388133" TEXT="Ejemplo">
<node COLOR="#cc9900" CREATED="1170402940036" ID="Freemind_Link_72153142" MODIFIED="1170403462102" TEXT="Enlace a otra parte">
<arrowlink DESTINATION="Freemind_Link_872294215" ENDARROW="Default" ENDINCLINATION="14;-29;" ID="Freemind_Arrow_Link_514982703" STARTARROW="None" STARTINCLINATION="135;-8;"/>
</node>
<node COLOR="#cc9900" CREATED="1170402940036" FOLDED="true" ID="Freemind_Link_40913042" MODIFIED="1170403419680" TEXT="Nodo con un subnodo replegado">
<node CREATED="1170402940036" ID="Freemind_Link_872294215" MODIFIED="1170403462102" TEXT="Subnodo"/>
</node>
<node COLOR="#cc9900" CREATED="1170402940036" ID="Freemind_Link_1982955440" MODIFIED="1170403474336" TEXT="Otro enlace">
<arrowlink COLOR="#9999ff" DESTINATION="Freemind_Link_72153142" ENDARROW="Default" ENDINCLINATION="169;0;" ID="Freemind_Arrow_Link_1798453197" STARTARROW="None" STARTINCLINATION="174;0;"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_423038022" MODIFIED="1170403490211" POSITION="right" TEXT="Hacer b&#xfa;squedas">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170403492446" ID="Freemind_Link_1193426532" MODIFIED="1170403492446" TEXT="Para encontrar un texto en un nodo y todos los nodos descendientes, presione CTRL+F &#xf3; en el men&#xfa; contextual, opci&#xf3;n Nodo--&gt;Buscar...."/>
<node CREATED="1170403492446" MODIFIED="1170403492446" TEXT="Para seguir buscando m&#xe1;s resultados con un criterio de b&#xfa;squeda, pulse CTRL+G &#xf3; en el men&#xfa; contextual, utilice Nodo-&gt;Buscar Siguiente."/>
<node CREATED="1170403492446" MODIFIED="1170403492446" TEXT="Para buscar en todo el mapa, col&#xf3;quese en el nodo central, pulsando ESCAPE antes de realizar la b&#xfa;squeda."/>
<node CREATED="1170403492446" MODIFIED="1170403492446" TEXT="La b&#xfa;squeda es una b&#xfa;squeda de la primera concurrencia. Esto responde a la idea de que, cuanto m&#xe1;s profundo sea un nodo, m&#xe1;s detalle tendr&#xe1;."/>
<node CREATED="1170403492446" MODIFIED="1170403492446" TEXT="Recuerde que no se busca un &#xe1;rbol entero, sino que s&#xf3;lo en el nodo y todos sus descendientes."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_653540280" MODIFIED="1170403527134" POSITION="right" TEXT="Seleccionar m&#xfa;ltiples nodos">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170403517883" ID="Freemind_Link_507160373" MODIFIED="1170403517883" TEXT="Para seleccionar m&#xfa;ltiples nodos, mantenga pulsado CTRL &#xf3; SHIFT (MAY&#xda;SCULAS) mientras los elige con el rat&#xf3;n."/>
<node CREATED="1170403517883" MODIFIED="1170403517883" TEXT="Para a&#xf1;adir m&#xe1;s nodos a una selecci&#xf3;n m&#xfa;ltiple de nodos, mantenga pulsado CTRL mientras hace click en ellos."/>
<node CREATED="1170403517883" MODIFIED="1170403517883" TEXT="Para seleccionar un rango de nodos consecutivos o seguidos, mantenga pulsado SHIFT (MAY&#xda;SCULAS) mientras los selecciona con el rat&#xf3;n, &#xf3; mantenga pulsado SHIFT (MAY&#xda;SCULAS) mientras se mueve con las flechas de desplazamiento del teclado."/>
<node CREATED="1170403517883" MODIFIED="1170403517883" TEXT="Para seleccionar un sub-&#xe1;rbol completo, mantenga pulsado ALT mientras hace click, &#xf3; mantenga pulsado SHIFT (MAY&#xda;SCULAS) mientras se mueve con las teclas de desplazamiento de un nodo a su nodo padre."/>
<node CREATED="1170403517883" MODIFIED="1170403517883" TEXT="Para cancelar la selecci&#xf3;n de m&#xfa;ltiples nodos, haga click en el fondo del mapa &#xf3; en un nodo no seleccionado."/>
<node CREATED="1170403517883" MODIFIED="1170403517883" TEXT="Para seleccionar todos los nodos visibles, seleccione la opci&#xf3;n en el men&#xfa; principal: Editar--&gt;Select All Visible (Sin traducir)."/>
<node CREATED="1170403517883" MODIFIED="1170403517883" TEXT="Para seleccionar todos los nodos visibles de una rama, seleccione la opci&#xf3;n en el men&#xfa; principal: Editar--&gt;Select Visible Branch (Sin traducir)."/>
<node CREATED="1170405270836" FOLDED="true" ID="Freemind_Link_1196067011" LINK="file:/C:/Archivos de programa/IrfanView/Html/" MODIFIED="1170405270852" TEXT="Html">
<node CREATED="1170405270852" ID="Freemind_Link_566784677" LINK="file:/C:/Archivos de programa/IrfanView/Html/frame.html" MODIFIED="1170405270852" TEXT="frame.html"/>
<node CREATED="1170405270868" ID="Freemind_Link_1122494705" LINK="file:/C:/Archivos de programa/IrfanView/Html/slideshow.html" MODIFIED="1170405270868" TEXT="slideshow.html"/>
<node CREATED="1170405270868" ID="Freemind_Link_364368875" LINK="file:/C:/Archivos de programa/IrfanView/Html/thumbnails.html" MODIFIED="1170405270868" TEXT="thumbnails.html"/>
</node>
<node CREATED="1170405270883" FOLDED="true" ID="Freemind_Link_1203928403" LINK="file:/C:/Archivos de programa/IrfanView/Languages/" MODIFIED="1170405270899" TEXT="Languages">
<node CREATED="1170405270899" ID="Freemind_Link_855733485" LINK="file:/C:/Archivos de programa/IrfanView/Languages/Deutsch.dll" MODIFIED="1170405270899" TEXT="Deutsch.dll"/>
</node>
<node CREATED="1170405270899" FOLDED="true" ID="Freemind_Link_743205228" LINK="file:/C:/Archivos de programa/IrfanView/Plugins/" MODIFIED="1170405270914" TEXT="Plugins">
<node CREATED="1170405270914" ID="Freemind_Link_639338292" LINK="file:/C:/Archivos de programa/IrfanView/Plugins/Effects.dll" MODIFIED="1170405270914" TEXT="Effects.dll"/>
<node CREATED="1170405270914" ID="Freemind_Link_965606582" LINK="file:/C:/Archivos de programa/IrfanView/Plugins/Icons.dll" MODIFIED="1170405270930" TEXT="Icons.dll"/>
<node CREATED="1170405270930" ID="Freemind_Link_1618897390" LINK="file:/C:/Archivos de programa/IrfanView/Plugins/Mpg.dll" MODIFIED="1170405270930" TEXT="Mpg.dll"/>
<node CREATED="1170405270930" ID="Freemind_Link_946430678" LINK="file:/C:/Archivos de programa/IrfanView/Plugins/Plugins.txt" MODIFIED="1170405270946" TEXT="Plugins.txt"/>
<node CREATED="1170405270946" ID="Freemind_Link_756921843" LINK="file:/C:/Archivos de programa/IrfanView/Plugins/Slideshow.exe" MODIFIED="1170405270946" TEXT="Slideshow.exe"/>
<node CREATED="1170405270946" ID="Freemind_Link_913413127" LINK="file:/C:/Archivos de programa/IrfanView/Plugins/Video.dll" MODIFIED="1170405270946" TEXT="Video.dll"/>
</node>
<node CREATED="1170405270961" ID="Freemind_Link_344292187" LINK="file:/C:/Archivos de programa/IrfanView/iv_uninstall.exe" MODIFIED="1170405270961" TEXT="iv_uninstall.exe"/>
<node CREATED="1170405270961" ID="Freemind_Link_331640781" LINK="file:/C:/Archivos de programa/IrfanView/i_about.txt" MODIFIED="1170405270961" TEXT="i_about.txt"/>
<node CREATED="1170405270961" ID="Freemind_Link_823931338" LINK="file:/C:/Archivos de programa/IrfanView/i_changes.txt" MODIFIED="1170405270977" TEXT="i_changes.txt"/>
<node CREATED="1170405270977" ID="Freemind_Link_1434544883" LINK="file:/C:/Archivos de programa/IrfanView/i_languages.txt" MODIFIED="1170405270977" TEXT="i_languages.txt"/>
<node CREATED="1170405270977" ID="Freemind_Link_1464671418" LINK="file:/C:/Archivos de programa/IrfanView/i_options.txt" MODIFIED="1170405270977" TEXT="i_options.txt"/>
<node CREATED="1170405270992" ID="Freemind_Link_1621670439" LINK="file:/C:/Archivos de programa/IrfanView/i_plugins.txt" MODIFIED="1170405270992" TEXT="i_plugins.txt"/>
<node CREATED="1170405270992" ID="Freemind_Link_1732519486" LINK="file:/C:/Archivos de programa/IrfanView/i_view32.chm" MODIFIED="1170405270992" TEXT="i_view32.chm"/>
<node CREATED="1170405270992" ID="Freemind_Link_1243859600" LINK="file:/C:/Archivos de programa/IrfanView/i_view32.exe" MODIFIED="1170405271008" TEXT="i_view32.exe"/>
<node CREATED="1170405271008" ID="Freemind_Link_1386491854" LINK="file:/C:/Archivos de programa/IrfanView/i_view32.exe.manifest" MODIFIED="1170405271008" TEXT="i_view32.exe.manifest"/>
<node CREATED="1170405271008" ID="Freemind_Link_1958400630" LINK="file:/C:/Archivos de programa/IrfanView/i_view32.ini" MODIFIED="1170405271024" TEXT="i_view32.ini"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1024903226" MODIFIED="1170403565009" POSITION="right" TEXT="Arrastrar y soltar">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170403567946" ID="Freemind_Link_803053837" MODIFIED="1170403567946" TEXT="Puede mover nodos usando arrastrar y soltar."/>
<node CREATED="1170403567946" MODIFIED="1170403567946" TEXT="Para soltar un nodo como hijo, coloque el cursor en el extremo de un nodo al soltarlo."/>
<node CREATED="1170403567946" MODIFIED="1170403567946" TEXT="Para soltar un nodo como hermano, coloque el cursor en la parte superior del nodo destino cuando al soltarlo."/>
<node CREATED="1170403567946" MODIFIED="1170403567946" TEXT="Para copiar nodos a la vez que se mueven, presione CTRL mientras lo arrastra, &#xf3; arrastrelo con el bot&#xf3;n central del rat&#xf3;n."/>
<node CREATED="1170403567946" MODIFIED="1170403567946" TEXT="Para editar un mapa existente, arrastre su fichero y su&#xe9;ltelo en el fondo de pantalla de FreeMind; Esto funciona al menos en ordenadores con Microsoft Windows."/>
<node CREATED="1170403567946" MODIFIED="1170403567946" TEXT="Para crear un enlace gr&#xe1;fico o de flechas, arrastre y suelte mientras tiene pulsado el bot&#xf3;n derecho del rat&#xf3;n."/>
<node CREATED="1170403567946" MODIFIED="1170403567946" TEXT="Si ha seleccionado m&#xfa;ltiples nodos, todos se moveran o copiaran.."/>
<node CREATED="1170403567946" MODIFIED="1170403567946" TEXT="Puede arrastrar informaci&#xf3;n de aplicaciones externas, como ficheros en un S.O. Microsoft Windows, &#xf3; piezas de texto seleccionado en Microsoft Internet Explorer."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_958781924" MODIFIED="1170403884683" POSITION="right" TEXT="Copiar y pegar (Edici&#xf3;n)">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="Freemind_Link_1070489177" MODIFIED="1170662211252" TEXT="Puede copiar y pegar (m&#xfa;ltiples) nodos entre mapas mentales. Adem&#xe1;s, puede pegar texto normal &#xf3; HTML desde otras aplicaciones.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1215134438" MODIFIED="1170403616493" TEXT="Si pega texto plano, cada l&#xed;nea se pegar&#xe1; como un nodo, con la profundidad determinada por el n&#xfa;mero de caracteres de cada l&#xed;nea. &#xc9;ste es un ejemplo:"/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1656023763" MODIFIED="1170403649275" TEXT="&#xc1;rbol &#xa;     Roble &#xa;     Haya">
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_326960749" MODIFIED="1170403674025" TEXT="es pegado como">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_639753662" MODIFIED="1170403690306" TEXT="&#xc1;rbol">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_142445650" MODIFIED="1170403694135" TEXT="Roble">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_68949954" MODIFIED="1170403697775" TEXT="Haya">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1804728980" MODIFIED="1170403710088" TEXT="Si pega HTML, &#xe9;ste se pega como texto plano. Adem&#xe1;s, los enlaces que contenga en HTML ser&#xe1;n copiados como hijos de un nodo adicional llamado &#x201c;Links&#x201d; (Enlaces). Ejemplo:"/>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_374077364" MODIFIED="1170403718853" TEXT="Ejemplo resultante tras pegar:">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" MODIFIED="1124560950717" TEXT="Shopping (120236)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" MODIFIED="1124560950717" TEXT="Urban Living (19)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1381653791" MODIFIED="1170403726979" TEXT="Enlaces">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" LINK="http://directory.google.com/Top/Shopping/" MODIFIED="1124560950717" TEXT="Shopping">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" LINK="http://directory.google.com/Top/Home/Urban_Living/" MODIFIED="1124560950717" TEXT="Urban Living">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="Freemind_Link_1772185342" MODIFIED="1170403735744" TEXT="Si pega una lista de ficheros de Explorer en Microsoft Windows, se pegar&#xe1; como un conjunto de enlaces a los ficheros."/>
<node CREATED="1124560950717" ID="Freemind_Link_619498024" MODIFIED="1170403756166" TEXT="Si en FreeMind copia una rama y la pega en un editor de texto plano (p.e.: Bloc de notas), la estructura de &#xe1;rbol se muestra como texto tabulado. Los enlaces se copian entre los simbolos &#x201c;&lt;&gt;&#x201d;. Por ejemplo:"/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1419018130" MODIFIED="1170403770010" TEXT="&#xc1;rbol">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="Freemind_Link_1688306576" MODIFIED="1170403774791" TEXT="Roble">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_838087851" MODIFIED="1170403779760" TEXT="Haya">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_926901432" MODIFIED="1170403787354" TEXT="se pega como">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="Freemind_Link_160461667" MODIFIED="1170403810901" TEXT="&#xc1;rbol&#xa;     Roble &#xa;     Haya&#xa;     Google &lt;http://www.google.com/&gt;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950732" LINK="http://www.google.com/" MODIFIED="1124560950732" TEXT="Google">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" ID="Freemind_Link_847954963" MODIFIED="1170403842589" TEXT="Si en FreeMind usted copia una rama y la pega en un editor de texto que comprenda el formato de texto enriquecido, se mantienes los formatos de color y fuente se incluyen tambi&#xe9;n. Los enlaces tambi&#xe9;n se copian entre &#x201c;&lt;&gt;&#x201d;, igual que en los editores de texto plano. Los editores que soportan texto enriquecido son Microsoft Word, Wordpad &#xf3; Microsoft Outlook, y en Linux, existe algunos (No se mencionan concretos)."/>
<node CREATED="1124560950732" ID="Freemind_Link_314527267" MODIFIED="1170403851432" TEXT="Para copiar un nodo sin sus descendientes, pulse CTRL+Y &#xf3; en el men&#xfa; contextual use &#x201c;Copia Sencilla&#x201d;."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="_Freemind_Link_1540212684" MODIFIED="1170403896261" POSITION="right" TEXT="Moverse en la aplicaci&#xf3;n">
<node CREATED="1170403902527" ID="Freemind_Link_1237405295" MODIFIED="1170403902527" TEXT="Para mover el cursor hacia arriba, abajo, izquierda &#xf3; derecha, utilice las teclas de desplazamiento."/>
<node CREATED="1170403902527" MODIFIED="1170403902527" TEXT="Para moverse a la parte superior del sub-&#xe1;rbol actual, pulse AV. P&#xc1;G."/>
<node CREATED="1170403902527" MODIFIED="1170403902527" TEXT="Para moverse a la parte inferior del sub-&#xe1;rbol actual, pulse RE. P&#xc1;G."/>
<node CREATED="1170403902527" MODIFIED="1170403902527" TEXT="Para moverse al nodo central, pulse ESCAPE."/>
<node CREATED="1170403902527" MODIFIED="1170403902527" TEXT="Para mover un nodo libremente, arr&#xe1;strelo por la parte anterior a la caja del texto del nodo (aparecer&#xe1; una especie de elipse), y en ese momento podr&#xe1; ponerlo donde quiera."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_4727471" MODIFIED="1170403918527" POSITION="right" TEXT="Desplegar y Replegar (Doblar y desdoblar)">
<node CREATED="1170403923714" ID="Freemind_Link_308302871" MODIFIED="1170403923714" TEXT="Para replegar &#xf3; doblar un nodo, pulse ESPACIO, &#xf3; en el men&#xfa; contextual de nodo utilice (Des)Activar Doblez."/>
<node CREATED="1170403923714" MODIFIED="1170403923714" TEXT="Para desplegar &#xf3; desdoblar un nodo, pulse ESPACIO, &#xf3; en el men&#xfa; contextual de nodo utilice (Des)Activar Doblez. Incluso, se puede desdoblar o desplegar con la tecla de desplazamiento en la direcci&#xf3;n de despliegue. (P.e.: Para desplegar un nodo replegado que est&#xe1; a la derecha, con la tecla derecha se despliega."/>
<node CREATED="1170403923714" MODIFIED="1170403923714" TEXT="Para replegar &#xf3; desplegar los nodos por niveles, mantenga pulsado ALT mientras utiliza la rueda del rat&#xf3;n, &#xf3; presione ALT+AV. P&#xc1;G &#xf3; ALT+RE. P&#xc1;G. Con mapas grandes, use esta funci&#xf3;n con cuidado, ya que pueden surgir problemas de memoria."/>
<node CREATED="1170403923714" MODIFIED="1170403923714" TEXT="Para desplegar todo, pulse el bot&#xf3;n gris &#x201c;+&#x201d; en la barra de principal, &#xf3; en el men&#xfa; principal: Navegar--&gt;Desdoblar Todos."/>
<node CREATED="1170403923714" MODIFIED="1170403923714" TEXT="Para replegar &#xf3; doblar todo, pulse el bot&#xf3;n gris &#x201c;-&#x201d; en la barra principal, &#xf3; en el men&#xfa; principal: Navegar--&gt;Doblar Todos."/>
<node CREATED="1170403923714" MODIFIED="1170403923714" TEXT="Los nodos replegados &#xf3; doblados se se&#xf1;alan con un peque&#xf1;o c&#xed;rculo en la direcci&#xf3;n de la doblez."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_516331171" MODIFIED="1170403959449" POSITION="right" TEXT="Cambiar de mapas">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1490034065" MODIFIED="1170662218299" TEXT="Para cambiar a otro mapa mental ya abierto, haga click con el bot&#xf3;n derecho en el fondo del mapa y seleccione un mapa diferente en el men&#xfa; contextual.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_467411537" MODIFIED="1170403980402" POSITION="right" TEXT="Mover un mapa">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170403987433" ID="Freemind_Link_822614761" MODIFIED="1170403987433" TEXT="Para mover el mapa, arrastre el fondo y mu&#xe9;valo, &#xf3; use la rueda del rat&#xf3;n. Para desplazarlo horizontalmente con la rueda, mantega pulsado SHIFT (MAY&#xda;SCULAS) &#xf3; uno de los botones del rat&#xf3;n."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913137192" MODIFIED="1170403999887" POSITION="right" TEXT="Hacer Zoom (Ampliar y reducir)">
<node CREATED="1170404005637" ID="Freemind_Link_1547290575" MODIFIED="1170404005637" TEXT="Para hacer zoom, utilice la rueda del rat&#xf3;n mientras presiona la tecla CTRL, &#xf3; presione ALT+ARRIBA &#xf3; ABAJO. Adem&#xe1;s, puede usar el campo de zoom en la lista desplegable de la barra principal (Al lado del icono de la impresora)."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1318678369" MODIFIED="1170404020480" POSITION="right" TEXT="Deshacer cambios">
<node CREATED="1170404027137" ID="Freemind_Link_613644644" MODIFIED="1170404027137" TEXT="Para deshacer cambios, pulse CTRL+Z, &#xf3; en el men&#xfa; principal, Editar--&gt;Deshacer."/>
<node CREATED="1170404027137" MODIFIED="1170404027137" TEXT="Para rehacer cambios, pulse CTRL+Y, &#xf3; en el men&#xfa; principal, Editar--&gt;Rehacer."/>
<node CREATED="1170404027137" MODIFIED="1170404027137" TEXT="Para establecer el n&#xfa;mero de pasos para poder deshacer, utilice la opci&#xf3;n Herramientas--&gt;Preferencias (Preferences) del men&#xfa; principal."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_22510332" MODIFIED="1170404045621" POSITION="right" TEXT="Exportar a HTML">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170404051465" ID="Freemind_Link_842904736" MODIFIED="1170404051465" TEXT="Para exportar una rama a HTML, pulse CTRL+H. La p&#xe1;gina HTML exportada puede contener soporte de ramificaciones o despliegues, dependiendo de la configuraci&#xf3;n de las preferencias."/>
<node CREATED="1170404051465" MODIFIED="1170404051465" TEXT="Para usar otra funci&#xf3;n de exportaci&#xf3;n, utilice en el men&#xfa; principal la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como XHTML (versi&#xf3;n Javascript)."/>
<node CREATED="1170404051465" MODIFIED="1170404051465" TEXT="Para exportar un mapa como una vista de imagen en HTML, utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como XHTML (versi&#xf3;n mapa seleccionable)."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1908686168" MODIFIED="1170404068871" POSITION="right" TEXT="Exportar a Imagen &#xf3; imagen vectorizada">
<node CREATED="1170404074075" ID="Freemind_Link_696364467" MODIFIED="1170404074075" TEXT="Para exportar el mapa como imagen PNG, utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como PNG."/>
<node CREATED="1170404074075" MODIFIED="1170404074075" TEXT="Para exportar el mapa como imagen JPEG, utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como JPEG."/>
<node CREATED="1170404074075" MODIFIED="1170404074075" TEXT="Para exportar el mapa como SVG, utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como SVG. Esta opci&#xf3;n s&#xf3;lo estar&#xe1; disponible si tiene instalado en su equipo el plugin de SVG."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_329770204" MODIFIED="1170404092059" POSITION="right" TEXT="Exportar a otros formatos XML">
<node CREATED="1170404101012" ID="Freemind_Link_1686469512" MODIFIED="1170404101012" TEXT="Para exportar el mapa a otros XML, de modo que obtenga una hoja de c&#xe1;lculo XSLT, utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;Como XSLT."/>
<node CREATED="1170404101012" MODIFIED="1170404101012" TEXT="Para exportar el mapa a un documento de OpenOffice Writer 1.4,  utilice la opci&#xf3;n Archivo--&gt;Exportar--&gt;As OpenOffice Writer Document (Como un documento de OpenOffice Writer)."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1841136119" MODIFIED="1170404233263" POSITION="right" TEXT="Importar una estructura de carpetas">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_1764451882" MODIFIED="1170404202950" TEXT="Para importar una estructura de carpetas, en el men&#xfa; principal utilice Fichero--&gt;Importar--&gt;Estructura de carpetas. Se le preguntar&#xe1; sobre qu&#xe9; carpeta cuya estructura desea importar. Por estructura se entiende el &#xe1;rbol de todas los subcarpetas, con los enlaces a los ficheros de esas subcarpetas. Este ser&#xed;a un ejemplo."/>
<node COLOR="#cc9900" CREATED="1170405208842" FOLDED="true" ID="Freemind_Link_1904792824" MODIFIED="1170405350619" TEXT="Ejemplo">
<node CREATED="1170405356830" ID="Freemind_Link_973626144" MODIFIED="1170405536101" TEXT="Carpeta seleccionada    --&gt;   file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS">
<arrowlink DESTINATION="Freemind_Link_973626144" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_237820159" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
<node CREATED="1170405329320" FOLDED="true" ID="Freemind_Link_482637031" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/" MODIFIED="1170405329320" TEXT="DBWIZ">
<node CREATED="1170405329320" ID="Freemind_Link_917890101" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/ASSETS.GIF" MODIFIED="1170405329335" TEXT="ASSETS.GIF"/>
<node CREATED="1170405329335" ID="Freemind_Link_1920637750" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/CONTACTS.GIF" MODIFIED="1170405329335" TEXT="CONTACTS.GIF"/>
<node CREATED="1170405329335" ID="Freemind_Link_52335184" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/EVTMGMT.GIF" MODIFIED="1170405329351" TEXT="EVTMGMT.GIF"/>
<node CREATED="1170405329351" ID="Freemind_Link_1267132541" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/EXPENSES.GIF" MODIFIED="1170405329351" TEXT="EXPENSES.GIF"/>
<node CREATED="1170405329367" ID="Freemind_Link_1821713435" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/INVENTRY.GIF" MODIFIED="1170405329367" TEXT="INVENTRY.GIF"/>
<node CREATED="1170405329367" ID="Freemind_Link_576748688" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/LEDGER.GIF" MODIFIED="1170405329367" TEXT="LEDGER.GIF"/>
<node CREATED="1170405329367" ID="Freemind_Link_1213533940" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/ORDPROC.GIF" MODIFIED="1170405329382" TEXT="ORDPROC.GIF"/>
<node CREATED="1170405329382" ID="Freemind_Link_806628245" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/RESOURCE.GIF" MODIFIED="1170405329382" TEXT="RESOURCE.GIF"/>
<node CREATED="1170405329382" ID="Freemind_Link_460118543" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/SERVICE.GIF" MODIFIED="1170405329398" TEXT="SERVICE.GIF"/>
<node CREATED="1170405329398" ID="Freemind_Link_12438217" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/DBWIZ/TIMEBILL.GIF" MODIFIED="1170405329398" TEXT="TIMEBILL.GIF"/>
</node>
<node CREATED="1170405329398" FOLDED="true" ID="Freemind_Link_1899130473" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/STYLES/" MODIFIED="1170405329413" TEXT="STYLES">
<node CREATED="1170405329413" ID="Freemind_Link_592922687" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/STYLES/ACBLENDS.GIF" MODIFIED="1170405329413" TEXT="ACBLENDS.GIF"/>
<node CREATED="1170405329413" ID="Freemind_Link_146113010" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/STYLES/ACBLUPRT.GIF" MODIFIED="1170405329429" TEXT="ACBLUPRT.GIF"/>
<node CREATED="1170405329429" ID="Freemind_Link_1339877706" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/STYLES/ACEXPDTN.GIF" MODIFIED="1170405329429" TEXT="ACEXPDTN.GIF"/>
<node CREATED="1170405329429" ID="Freemind_Link_1772818073" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/STYLES/ACINDSTR.GIF" MODIFIED="1170405329445" TEXT="ACINDSTR.GIF"/>
<node CREATED="1170405329445" ID="Freemind_Link_1143314187" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/STYLES/ACRICEPR.GIF" MODIFIED="1170405329445" TEXT="ACRICEPR.GIF"/>
<node CREATED="1170405329445" ID="Freemind_Link_1692161100" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/STYLES/ACSNDSTN.GIF" MODIFIED="1170405329445" TEXT="ACSNDSTN.GIF"/>
<node CREATED="1170405329460" ID="Freemind_Link_1569128746" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/STYLES/ACSUMIPT.GIF" MODIFIED="1170405329460" TEXT="ACSUMIPT.GIF"/>
<node CREATED="1170405329460" ID="Freemind_Link_569631745" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/STYLES/GLOBE.WMF" MODIFIED="1170405329460" TEXT="GLOBE.WMF"/>
<node CREATED="1170405329476" ID="Freemind_Link_345608504" LINK="file:/C:/Archivos de programa/Microsoft Office 2003/OFFICE11/BITMAPS/STYLES/STONE.BMP" MODIFIED="1170405329476" TEXT="STONE.BMP"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_269203785" MODIFIED="1170658741756" POSITION="right" TEXT="Importar los Favoritos de Internet Explorer">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170658759990" ID="Freemind_Link_1571419416" MODIFIED="1170658759990" TEXT="Para importar la carpeta favoritos de Microsoft Internet Explorer, utilice la siguiente opci&#xf3;n del men&#xfa; principal: Archivo--&gt;Importar--&gt;Favoritos del Explorer. Se le pedir&#xe1; que indique la carpeta d&#xf3;nde est&#xe1;n ubicados en su equipo. La ubicaci&#xf3;n suele ser: &#x201c;c:\documents and settings\&lt;usuario&gt;\Favoritos\&#x201d;"/>
<node COLOR="#999999" CREATED="1170658759990" ID="Freemind_Link_184137676" MODIFIED="1170658849395" TEXT="Palabras clave: Microsoft Internet Explorer, MSIE, MS IE.">
<arrowlink DESTINATION="Freemind_Link_184137676" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_218710848" STARTARROW="None" STARTINCLINATION="0;0;"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1709974530" MODIFIED="1170661959523" POSITION="right" TEXT="Importar mapas mentales de MindManager X5">
<node CREATED="1170658887175" ID="Freemind_Link_281596646" MODIFIED="1170658887175" TEXT="Para importar un mapa de MindManager X5, utilice la opci&#xf3;n del men&#xfa; principal: Archivo--&gt;Importar--&gt;MindManager X5 map."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913645795" MODIFIED="1170658902269" POSITION="right" TEXT="Integraci&#xf3;n con Microsoft Word &#xf3; Outlook">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170658910394" ID="Freemind_Link_1195798098" MODIFIED="1170658910394" TEXT="Puede pegar mapas &#xf3; ramas en Microsoft Word, Wordmap &#xf3; mensajes de Outlook. En general, puede pegarlo en cualquier aplicaci&#xf3;n que soporte el formato de texto enriquecido. De ese modo, los enlaces y el formato del texto se mantendr&#xe1;."/>
<node CREATED="1170658910394" LINK="mailto:(mailto:usuario@correo.com)" MODIFIED="1170658910394" TEXT="Haciendo click en un enlace de correo electr&#xf3;nico (mailto:usuario@correo.com) se abrir&#xe1; Microsoft Outlook para crear un nuevo mensaje, &#xf3; el programa de correo electr&#xf3;nico establecido por defecto."/>
<node CREATED="1170658910394" ID="Freemind_Link_1391168579" MODIFIED="1170658942034" TEXT="Puede poner el asunto en el enlace de correo.">
<icon BUILTIN="Mail"/>
</node>
<node CREATED="1170658910394" ID="Freemind_Link_1826214858" MODIFIED="1170662230814" TEXT="Otra manera de copiar un mapa mental a Microsoft Word es export&#xe1;ndolo a HTML y despu&#xe9;s copiar y pegarlo en Word."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1822195277" MODIFIED="1170658962190" POSITION="right" TEXT="Configurar las preferencias">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170658981392" ID="Freemind_Link_1506877434" MODIFIED="1170658981392" TEXT="Para editar las preferencias, utilice el men&#xfa; principal: Herramientas--&gt;Preferencias. La mayor&#xed;a de los cambios surtir&#xe1;n efecto cuando reinicie FreeMind."/>
<node CREATED="1170658981392" MODIFIED="1170658981392" TEXT="Las preferencias incluyen mapeo de teclas, comportamientos al exportar a HTML, el modo de selecci&#xf3;n de nodos mediante rat&#xf3;n, elegir antialising (mejorar pixelado de los mapas), etc."/>
<node COLOR="#999999" CREATED="1170658981392" ID="Freemind_Link_1861005230" MODIFIED="1170659009079" TEXT="Palabra clave: Customizing.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1528828442" MODIFIED="1170659031313" POSITION="right" TEXT="Imprimir">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170659046235" ID="Freemind_Link_648343751" MODIFIED="1170659046235" TEXT="Puede imprimir un mapa ajust&#xe1;ndolo a una p&#xe1;gina, como imprimi&#xe9;ndolo en varios trozos de papel. Esta opci&#xf3;n se puede establecer en el men&#xfa;: Archivo--&gt;Configurar P&#xe1;gina."/>
<node CREATED="1170659046235" MODIFIED="1170659046235" TEXT="Para hacer mejor uso del espacio, utilice el formato horizontal de p&#xe1;gina &#xf3; apaisado."/>
<node CREATED="1170659046235" MODIFIED="1170659046235" TEXT="La previsualizaci&#xf3;n del mapa impreso no se puede hacer directamente. Si tiene una impresora postscript &#xf3; driver gen&#xe9;rico postscript, puede imprimir el mapa a un fichero y despu&#xe9;s verlo con Ghostview &#xf3; aplicaciones similares (Adobe PDF). Si lo imprime con una empresa no entienda Postscript (PS), posiblemente el formato sea PCL, que no le servir&#xe1; para la previsualizaci&#xf3;n."/>
<node CREATED="1170659046235" MODIFIED="1170659046235" TEXT="Tambi&#xe9;n puede imprimirlo desde su navegador, exportando el mapa a HTML, a Word &#xf3; WordPad despu&#xe9;s de copiarlo y pegarlo all&#xed;. Tambi&#xe9;n lo puede exportar a HTML, copiarlo y pegarlo a Microsoft Word e imprimirlo desde all&#xed;. De ese modo podr&#xe1; hacer tambi&#xe9;n modificaciones de estilos."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_841140408" MODIFIED="1170659084531" POSITION="right" TEXT="Usar texto enriquecido por medio de HTML en los nodos">
<node CREATED="1124560950732" ID="Freemind_Link_229410555" MODIFIED="1170659119233" TEXT="Los nodos que comienzan con &lt;html&gt; son renderizados &#xf3; construidos usando HTML en ellos. Esta caracter&#xed;stica le ser&#xe1; de gran ayuda para personas de perfil t&#xe9;cnico. Ejemplo:"/>
<node CREATED="1124560950732" ID="Freemind_Link_926533297" MODIFIED="1170659293886" TEXT="&lt;html&gt;&#xa;  &lt;head&gt;&#xa;    &#xa;  &lt;/head&gt;&#xa;  &lt;body&gt;&#xa;    &lt;h3&gt;&#xa;      Ejemplo HTML&#xa;    &lt;/h3&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      Hay varios elementos:&#xa;    &lt;/p&gt;&#xa;    &lt;ul type=&quot;disc&quot;&gt;&#xa;      &lt;li class=&quot;msonormal&quot;&gt;&#xa;        Elemento 1&#xa;      &lt;/li&gt;&#xa;      &lt;li class=&quot;msonormal&quot;&gt;&#xa;        Elemento 2&#xa;      &lt;/li&gt;&#xa;    &lt;/ul&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      Y puede tener &lt;b&gt;negrita&lt;/b&gt; &#xf3; &lt;i&gt;cursiva&lt;/i&gt;. &lt;u&gt;Subrayado&lt;/u&gt; &#xf3; &lt;strike&gt;tachado&lt;/strike&gt; &#xa;      tambi&#xe9;n. Puede tener una tabla:&#xa;    &lt;/p&gt;&#xa;    &lt;table cellpadding=&quot;0&quot; style=&quot;border: none&quot; class=&quot;msonormaltable&quot; border=&quot;1&quot; cellspacing=&quot;0&quot;&gt;&#xa;      &lt;tr&gt;&#xa;        &lt;td style=&quot;border: solid windowtext 1.0pt; padding-left: .75pt; padding-right: .75pt; padding-bottom: .75pt; padding-top: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            Celda1&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;        &lt;td style=&quot;border: solid windowtext 1.0pt; border-left: none; padding-left: .75pt; padding-right: .75pt; padding-top: .75pt; padding-bottom: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            Celda2&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;      &lt;/tr&gt;&#xa;      &lt;tr&gt;&#xa;        &lt;td style=&quot;border: solid windowtext 1.0pt; border-top: none; padding-left: .75pt; padding-right: .75pt; padding-top: .75pt; padding-bottom: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            Celda3&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;        &lt;td style=&quot;border-bottom: solid windowtext 1.0pt; border-top: none; border-left: none; padding-left: .75pt; padding-right: .75pt; border-right: solid windowtext 1.0pt; padding-top: .75pt; padding-bottom: .75pt&quot;&gt;&#xa;          &lt;p class=&quot;msonormal&quot;&gt;&#xa;            Celda4.&#xa;          &lt;/p&gt;&#xa;        &lt;/td&gt;&#xa;      &lt;/tr&gt;&#xa;    &lt;/table&gt;&#xa;    &lt;p class=&quot;msonormal&quot;&gt;&#xa;      &#xa0;Puede tener varios colores de &lt;font color=&quot;#999900&quot;&gt;letra&lt;/font&gt; &lt;font color=&quot;#336600&quot;&gt;&lt;/font&gt;.&#xa;    &lt;/p&gt;&#xa;  &lt;/body&gt;&#xa;&lt;/html&gt;&#xa;"/>
<node BACKGROUND_COLOR="#66ff66" CREATED="1170659095078" ID="Freemind_Link_697302079" MODIFIED="1170659349682" TEXT="Podemos tener varios colores de fondo."/>
<node CREATED="1170659095078" ID="Freemind_Link_1287825225" MODIFIED="1170662241845" TEXT="No hay soporte para para nodos HTML e im&#xe1;genes exportando a texto &#xf3; a RTF (Word, Wordpad). Por ello, es conveniente hacer uso del applet para mostrar v&#xed;a web HTML un mapa mental."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1325373651" MODIFIED="1170659376494" POSITION="right" TEXT="Usar im&#xe1;genes en nodos">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1170659386072" ID="Freemind_Link_833228264" MODIFIED="1170659386072" TEXT="Para insertar una imagen en FreeMind, pulse ALT+K, &#xf3; en el men&#xfa; contextual de nodo, use Insertar--&gt;Imagen. Si inserta una imagen en un nodo, perder&#xe1; todo el texto del mismo. Las im&#xe1;genes insertadas de este modo, no podr&#xe1;n f&#xe1;cilmente pegadas fuera de FreeMind y no necesariamente se exportar&#xe1;n correctamente a HTML. Las im&#xe1;genes son una caracter&#xed;stica en versi&#xf3;n beta dentro de esta versi&#xf3;n de FreeMind."/>
<node CREATED="1170659386072" MODIFIED="1170659386072" TEXT="Los formatos de im&#xe1;genes soportados son PNG, JPEG y GIF."/>
<node CREATED="1170659386072" MODIFIED="1170659386072" TEXT="Para convertir enlaces de im&#xe1;genes, a im&#xe1;genes visibles, pulse ALT+K. Podr&#xe1; arrastrar y soltar varios ficheros de im&#xe1;genes a FreeMind, seleccion&#xe1;ndolas como nodos m&#xfa;ltiples, y convirti&#xe9;ndolas en im&#xe1;genes presionando ALT+K."/>
<node CREATED="1170659386072" MODIFIED="1170659386072" TEXT="Existe otro modo de insertar im&#xe1;genes m&#xe1;s t&#xe9;cnico y menos sencillo de hacer. Es posible incluir HTML en nodos, de modo que si se incluyen im&#xe1;genes all&#xed;, comenzando el nodo con la palabra &lt;html&gt;, lo lograr&#xed;amos."/>
<node CREATED="1170659386072" ID="Freemind_Link_1490826264" MODIFIED="1170659481852" TEXT="Por ejemplo&#xa;&lt;html&gt;&lt;img src=&quot;linked/Apple.png&quot;&gt;&#xa;&lt;html&gt;&lt;img src=&quot;file://C://Users/My Documents/Mind Maps/Linked/Apple.png&quot;&gt;"/>
<node CREATED="1170659386072" MODIFIED="1170659386072" TEXT="Puede enlace a im&#xe1;genes con path relativos (Como en el ejemplo 1)."/>
<node COLOR="#996600" CREATED="1170659386072" FOLDED="true" ID="Freemind_Link_760617188" MODIFIED="1170660121542" TEXT="Ejemplo de im&#xe1;genes, funcionando sobre varias distribuciones de Windows">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1170659886641" ID="Freemind_Link_1832742863" MODIFIED="1170659933843" TEXT="&lt;html&gt;&lt;img src=&quot;file:/C:/Archivos de programa/FreeMind/doc/freemind_dragdrop_small.gif&quot;&gt;"/>
<node CREATED="1170659993045" ID="Freemind_Link_1808501808" MODIFIED="1170660033263" TEXT="&lt;html&gt;&lt;img src=&quot;file:/C:/Archivos de programa/FreeMind/doc/MindmapExample.png&quot;&gt;"/>
<node CREATED="1170660129605" ID="Freemind_Link_308307832" LINK="freemind_dragdrop_small.gif" MODIFIED="1170660732421" TEXT="freemind_dragdrop_small.gif"/>
<node CREATED="1170660745374" ID="Freemind_Link_341958438" LINK="MindmapExample.png" MODIFIED="1170660769546" TEXT="MindmapExample.png"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_538720495" MODIFIED="1170660804545" POSITION="right" TEXT="Usar el bloque de ficheros (Experimental)">
<node CREATED="1170660815888" ID="Freemind_Link_765143806" MODIFIED="1170660815888" TEXT="La versi&#xf3;n actual de FreeMind tiene una caracter&#xed;stica experimental, deshabilitada por defecto. Deber&#xed;a funcionar bien, pero no est&#xe1; totalmente depurada."/>
<node CREATED="1170660815888" MODIFIED="1170660815888" TEXT="El bloqueo de ficheros sirve para prevenir problemas de sobreescritura, cuando dos usuarios editan el mismo mapa al mismo tiempo."/>
<node CREATED="1170660815888" MODIFIED="1170660815888" TEXT="Para habilitar el bloque de ficheros experimental, utilice el men&#xfa; principal Herramientas--&gt;Preferences (Preferencias)."/>
</node>
</node>
</map>
