#!/bin/bash
java -cp batik-awt-util.jar:batik-bridge.jar:batik-css.jar:batik-dom.jar:batik-extension.jar:batik-ext.jar:batik-gui-util.jar:batik-gvt.jar:batik-parser.jar:batik-script.jar:batik-squiggle.jar:batik-svg-dom.jar:batik-svggen.jar:batik-swing.jar:batik-transcoder.jar:batik-util.jar:batik-xml.jar:js.jar:pdf-transcoder.jar:xerces_2_5_0.jar:xml-apis.jar org.apache.batik.apps.svgbrowser.Main

