<map version="0.9.0_Beta_8">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<attribute_registry>
<attribute_name NAME="attributeName">
<attribute_value VALUE="attributeValue"/>
</attribute_name>
</attribute_registry>
<node CREATED="1160462630102" ID="Freemind_Link_140245201" MODIFIED="1160462667140">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <b>Test</b>map
    </p>
    <p>
      for automated Tests
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1160462669842" ID="_" MODIFIED="1161587103055" POSITION="right" TEXT="Notetest">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      This linebreak:<br />is a bold: <b>note</b>. italic <i>part </i>underlined <u>part</u> and bold italic: <i><b>bolditalic</b></i>
    </p>
    <ul>
      <li>
        a
      </li>
      <li>
        b
      </li>
      <li>
        c
      </li>
    </ul>
    <ol>
      <li>
        1
      </li>
      <li>
        2
      </li>
      <li>
        3
      </li>
    </ol>
<!--    <table style="border-left-width: 0; border-right-width: 0; border-style: solid; border-top-width: 0; width: 80%; border-bottom-width: 0" border="0">
      <tr>
        <td valign="top" style="border-left-width: 1; border-right-width: 1; border-style: solid; border-top-width: 1; width: 33%; border-bottom-width: 1">
          <p style="margin-bottom: 1; margin-left: 1; margin-top: 1; margin-right: 1">
            t11
          </p>
        </td>
        <td valign="top" style="border-left-width: 1; border-right-width: 1; border-style: solid; border-top-width: 1; width: 33%; border-bottom-width: 1">
          <p style="margin-bottom: 1; margin-left: 1; margin-top: 1; margin-right: 1">
            t21
          </p>
        </td>
        <td valign="top" style="border-left-width: 1; border-right-width: 1; border-style: solid; border-top-width: 1; width: 33%; border-bottom-width: 1">
          <p style="margin-bottom: 1; margin-left: 1; margin-top: 1; margin-right: 1">
            t31
          </p>
        </td>
      </tr>
      <tr>
        <td valign="top" style="border-left-width: 1; border-right-width: 1; border-style: solid; border-top-width: 1; width: 33%; border-bottom-width: 1">
          <p style="margin-bottom: 1; margin-left: 1; margin-top: 1; margin-right: 1">
            t12
          </p>
        </td>
        <td valign="top" style="border-left-width: 1; border-right-width: 1; border-style: solid; border-top-width: 1; width: 33%; border-bottom-width: 1">
          <p style="margin-bottom: 1; margin-left: 1; margin-top: 1; margin-right: 1">
            t22
          </p>
        </td>
        <td valign="top" style="border-left-width: 1; border-right-width: 1; border-style: solid; border-top-width: 1; width: 33%; border-bottom-width: 1">
          <p style="margin-bottom: 1; margin-left: 1; margin-top: 1; margin-right: 1">
            t32
          </p>
        </td>
      </tr>
    </table> -->
  </body>
</html>
</richcontent>
</node>
<node CREATED="1160462699260" ID="Freemind_Link_1057151065" MODIFIED="1160462702810" POSITION="right" TEXT="This is a node">
<node CREATED="1160462703227" ID="Freemind_Link_1312609197" MODIFIED="1160462706665" TEXT="with a linbreak &#xa; subnode"/>
<node CREATED="1160462707747" ID="Freemind_Link_123530478" MODIFIED="1160462712132" TEXT="and another subnode"/>
<node CREATED="1160462712621" FOLDED="true" ID="Freemind_Link_1168263765" MODIFIED="1160462717788" TEXT="and some folded subnodes">
<node CREATED="1160462718297" ID="Freemind_Link_1441123033" MODIFIED="1160462720203" TEXT="fold1"/>
<node CREATED="1160462720606" ID="Freemind_Link_1601858134" MODIFIED="1160462721786" TEXT="fold2"/>
<node CREATED="1160462722166" ID="Freemind_Link_1186464171" MODIFIED="1160462723841" TEXT="fold3"/>
</node>
</node>
<node CREATED="1160462730498" ID="Freemind_Link_1369254551" MODIFIED="1160462754008" POSITION="right" TEXT="Attributes">
<attribute NAME="attributeName" VALUE="attributeValue"/>
</node>
</node>
</map>
