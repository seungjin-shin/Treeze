package com.hansung.treeze.model;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(NaviInfo.class) 
public class NaviInfo_ {
	

	public static volatile SingularAttribute<NaviInfo, Long> classId;
	public static volatile SingularAttribute<NaviInfo, String> nodeID;
	

}
