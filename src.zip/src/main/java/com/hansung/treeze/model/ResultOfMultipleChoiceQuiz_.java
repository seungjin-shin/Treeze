package com.hansung.treeze.model;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(ResultOfMultipleChoiceQuiz.class)
public class ResultOfMultipleChoiceQuiz_ {

	public static volatile SingularAttribute<ResultOfMultipleChoiceQuiz, Long> classId;
	public static volatile SingularAttribute<ResultOfMultipleChoiceQuiz, String> quizId;
	public static volatile SingularAttribute<ResultOfMultipleChoiceQuiz, Integer> countOfexample1;
	public static volatile SingularAttribute<ResultOfMultipleChoiceQuiz, Integer> countOfexample2;
	public static volatile SingularAttribute<ResultOfMultipleChoiceQuiz, Integer> countOfexample3;
	public static volatile SingularAttribute<ResultOfMultipleChoiceQuiz, Integer> countOfexample4;
	public static volatile SingularAttribute<ResultOfMultipleChoiceQuiz, Integer> countOfexample5;
}
